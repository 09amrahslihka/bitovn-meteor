var require = meteorInstall({"lib":{"config.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/config.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Base64;
module.watch(require("meteor/ostrio:base64"), {
  Base64(v) {
    Base64 = v;
  }

}, 0);
let Session;
module.watch(require("meteor/session"), {
  Session(v) {
    Session = v;
  }

}, 1);
Router.route('/profile', function () {
  if (Session.get("userId") != "") {
    this.render('profile');
  } else {
    Router.go('/');
  }
});
Router.route('/view_profile/:user_id', function () {
  var params = this.params; // { _id: "5" }
  // var id = params.user_id; // "5"

  var userId = params.user_id; // "5"

  userId = Base64.decode(userId); // alert("decrypt" + userId);
  // Session.set("makeUserActive","true");
  // Session.setPersistent("show_connection",head[0].user_id);

  Session.set("show_connection", userId); // alert('hi');

  this.render('view_profile');
});
Router.route('/', function () {
  this.render('login');
});
Router.route('/signup', function () {
  if (Session.get("userId") != "") {
    this.render('signup');
  } else {
    Router.go('/');
  }
});
Router.route('/connection', function () {
  this.render('connection');
});
Router.route('/Messaging', function () {
  this.render('messagingpage');
});
Router.route('/grplisting', function () {
  this.render('grplisting');
});
Router.route('/group_discussion', function () {
  this.render('group_discussion');
});
Router.route('/email', function () {
  if (Session.get("userId") != "") {
    this.render('email');
  } else {
    Router.go('/');
  }
});
Router.route('/activate_email/:id', function () {
  var params = this.params; // { _id: "5" }

  var userId = params.id; // "5"

  userId = Base64.decode(userId); // alert("decrypt" + userId);

  Session.set("makeUserActive", "true");
  Session.setPersistent("userId", userId);
  this.render('email');
});
Router.route('/creategroup', function () {
  this.render('creategroup');
});
Router.route('/messaging_page', function () {
  this.render('messaging_page');
});
Router.route('/groupdetail/:grp_id', function () {
  var params = this.params; // { _id: "5" }

  var encrypted = params.grp_id; // "5"
  // decrypted = CryptoJS.AES.decrypt(encrypted, 'Passphrase');
  // var id = decrypted.toString(CryptoJS.enc.Utf8);

  Session.set("show_grp_id", encrypted);
  this.render('groupdetail');
});
Router.route('/editgroup/:grp_id', function () {
  var params = this.params; // { _id: "5" }

  var encrypted = params.grp_id; // "5"
  // decrypted = CryptoJS.AES.decrypt(encrypted, 'Passphrase');
  // var id = decrypted.toString(CryptoJS.enc.Utf8);

  Session.set("show_grp_edit_id", encrypted);
  this.render('editgroup');
});
Router.route('/logout', function () {
  this.render('login');
});
Router.route('/messaging_left', function () {
  this.render('messaging_left');
});
Router.route('/messaging_right', function () {
  this.render('messaging_right');
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"import":{"collections":{"insert.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// import/collections/insert.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  UserInfo: () => UserInfo,
  UserSkill: () => UserSkill,
  UserProfJr: () => UserProfJr,
  UserEdu: () => UserEdu,
  UserAward: () => UserAward,
  UserMedical: () => UserMedical,
  FriendRequest: () => FriendRequest,
  Message: () => Message,
  UserGroup: () => UserGroup,
  GroupRequest: () => GroupRequest,
  Chatroom: () => Chatroom
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const UserInfo = new Mongo.Collection('user_info');
const UserSkill = new Mongo.Collection('user_skill');
const UserProfJr = new Mongo.Collection('user_profjr');
const UserEdu = new Mongo.Collection('user_edu');
const UserAward = new Mongo.Collection('user_award');
const UserMedical = new Mongo.Collection('user_medical');
const FriendRequest = new Mongo.Collection('friend');
const Message = new Mongo.Collection('message');
const UserGroup = new Mongo.Collection('user_group');
const GroupRequest = new Mongo.Collection('group_request');
const Chatroom = new Mongo.Collection('chatroom');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// import/config.js                                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Images: () => Images
});
let FilesCollection;
module.watch(require("meteor/ostrio:files"), {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 0);
const Images = new FilesCollection({
  debug: true,
  collectionName: 'Images',
  allowClientCode: false,
  // Disallow remove files from Client
  storagePath: () => {
    return `${process.env.PWD}/uploads`;
  },
  onBeforeUpload: function (file) {
    // Allow upload files under 10MB, and only in png/jpg/jpeg formats
    if (file.size <= 1024 * 1024 * 10 && /png|jpe?g/i.test(file.extension)) {
      return true;
    }

    return 'Please upload image, with size equal or less than 10MB';
  }
});
module.exportDefault(Images);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
	Meteor(v) {
		Meteor = v;
	}

}, 0);
let UserInfo;
module.watch(require("./../import/collections/insert.js"), {
	UserInfo(v) {
		UserInfo = v;
	}

}, 1);
let UserSkill;
module.watch(require("./../import/collections/insert.js"), {
	UserSkill(v) {
		UserSkill = v;
	}

}, 2);
let UserProfJr;
module.watch(require("./../import/collections/insert.js"), {
	UserProfJr(v) {
		UserProfJr = v;
	}

}, 3);
let UserEdu;
module.watch(require("./../import/collections/insert.js"), {
	UserEdu(v) {
		UserEdu = v;
	}

}, 4);
let UserAward;
module.watch(require("./../import/collections/insert.js"), {
	UserAward(v) {
		UserAward = v;
	}

}, 5);
let UserMedical;
module.watch(require("./../import/collections/insert.js"), {
	UserMedical(v) {
		UserMedical = v;
	}

}, 6);
let FriendRequest;
module.watch(require("./../import/collections/insert.js"), {
	FriendRequest(v) {
		FriendRequest = v;
	}

}, 7);
let Message;
module.watch(require("./../import/collections/insert.js"), {
	Message(v) {
		Message = v;
	}

}, 8);
let UserGroup;
module.watch(require("./../import/collections/insert.js"), {
	UserGroup(v) {
		UserGroup = v;
	}

}, 9);
let Email;
module.watch(require("meteor/email"), {
	Email(v) {
		Email = v;
	}

}, 10);
let GroupRequest;
module.watch(require("./../import/collections/insert.js"), {
	GroupRequest(v) {
		GroupRequest = v;
	}

}, 11);
let Chatroom;
module.watch(require("./../import/collections/insert.js"), {
	Chatroom(v) {
		Chatroom = v;
	}

}, 12);
let ServiceConfiguration;
module.watch(require("meteor/service-configuration"), {
	ServiceConfiguration(v) {
		ServiceConfiguration = v;
	}

}, 13);
Meteor.startup(function () {
	UploadServer.init({
		tmpDir: process.env.PWD + '/.uploads/tmp',
		uploadDir: process.env.PWD + '/uploaded/'
	});
}); //    var t1 = Presence.configure({
//   state: function() {
//     return {
//       online: false
//     }
//     userId: cool;
//   }
// });
//     if(t1 == 0){
//     	alert('i am active');
//     	console.log('active');
//     }
//     else if( t1 == 1 || t1 == 2){
//        alert('i am inactive');
//        console.log('In-active');
//        Session.setPersistent("login_status",0);              
//     }
//     else{
//     	console.log('In-active');
//     }

ServiceConfiguration.configurations.remove({
	service: "google"
});
ServiceConfiguration.configurations.insert({
	service: "google",
	clientId: "448932643096-qqt9pqi7c3ag0rcq1v6e9q2a8rfe65ap.apps.googleusercontent.com",
	secret: "0bTZibxwUduW_NEqf4W0Ngmb"
}); // first, remove configuration entry in case service is already configured

ServiceConfiguration.configurations.remove({
	service: "facebook"
});
ServiceConfiguration.configurations.insert({
	service: "facebook",
	appId: "784566848397487",
	secret: "678712697eae8bdc3cff25938136e2b9"
});
ServiceConfiguration.configurations.remove({
	service: "linkedin"
});
ServiceConfiguration.configurations.insert({
	service: "linkedin",
	clientId: "78eqh4qk0yx7y7",
	secret: "ixPAnSBiCtBq6WPJ"
}); // // first, remove configuration entry in case service is already configured
// Accounts.loginServiceConfiguration.remove({
//   service: "facebook"
// });
// Accounts.loginServiceConfiguration.insert({
//   service: "facebook",
//   appId: "784566848397487",
//   secret: "678712697eae8bdc3cff25938136e2b9"
// });

smtp = {
	username: 'ankit.vayuz@gmail.com',
	password: 'rsklxjzhbthcowko',
	server: 'smtp.gmail.com',
	port: 587
};
process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port;
Meteor.methods({
	logout_google: function (name) {
		var result = Meteor.users.update({
			_id: name
		}, {
			$set: {
				"services.resume.loginTokens": []
			}
		}, {
			multi: true
		});
		return result;
	},
	insert_address: function (userId, address) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"location": address
				}
			});
		} else {
			var result = UserInfo.insert({
				location: address,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	insert_contact_no: function (userId, contactno) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"phone": contactno
				}
			});
		} else {
			var result = UserInfo.insert({
				phone: contactno,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	insert_disabilities: function (userId, hearing, speech, visual, physical, special_note) {
		var newUser = UserMedical.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserMedical.update({
				user_id: userId
			}, {
				$set: {
					"hearing": hearing,
					"speech": speech,
					"visual": visual,
					"physical": physical,
					"special_note": special_note
				}
			});
		} else {
			var result = UserMedical.insert({
				user_id: userId,
				hearing: hearing,
				speech: speech,
				visual: visual,
				physical: physical,
				special_note: special_note,
				createdAt: new Date() // no comma needed here

			});
			var newUser = UserInfo.find({
				"user_id": userId
			}).fetch();

			if (newUser[0]) {
				var result = UserInfo.update({
					_id: newUser[0]._id
				}, {
					$set: {
						"disablities": "true"
					}
				});
			}
		}

		return result;
	},
	upload_user_image: function (userId, profile_pic) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"profile_pic": profile_pic
				}
			});
		} else {
			var result = UserInfo.insert({
				profile_pic: profile_pic,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	update_headline: function (userId, headline) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"headline": headline
				}
			});
		} else {
			var result = UserInfo.insert({
				headline: headline,
				user_id: userId,
				login_status: 1,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	update_summary: function (userId, summary) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"summary": summary
				}
			});
		} else {
			var result = UserInfo.insert({
				summary: summary,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	create_user: function (userID, source, name, email) {
		var result = UserInfo.insert({
			name: name,
			email: email,
			user_id: userID,
			source: source,
			email_status: 0,
			createdAt: new Date() // no comma needed here

		});
		return result;
	},
	con_req_insert: function (sent_to, sent_by, reqID) {
		var result = FriendRequest.insert({
			req_id: reqID,
			sent_to: sent_to,
			sent_by: sent_by,
			req_status: 0,
			requestedAt: new Date(),
			updatedAt: new Date()
		});
		return result;
	},
	con_req_update: function (sent_by, sent_to, request_type) {
		var result = FriendRequest.update({
			sent_by: sent_by,
			sent_to: sent_to
		}, {
			$set: {
				"req_status": request_type,
				"updatedAt": new Date()
			}
		});
		return result;
	},
	pers_info_update: function (name, gender, marital_status, phone, datepicker, autocomplete, user_id) {
		var result = UserInfo.update({
			'user_id': user_id
		}, {
			$set: {
				'name': name,
				'gender': gender,
				'marital_status': marital_status,
				'phone': phone,
				'dob': datepicker,
				'location': autocomplete
			}
		});
		return result;
	},
	insert_education: function (user_id, course, board, school, score, edu_start_month, edu_start_year, edu_end_month, edu_end_year, edu_location) {
		var result = UserEdu.insert({
			'user_id': user_id,
			'course': course,
			'board': board,
			'school': school,
			'score': score,
			'edu_start_month': edu_start_month,
			'edu_start_year': edu_start_year,
			'edu_end_month': edu_end_month,
			'edu_end_year': edu_end_year,
			'edu_location': edu_location
		});
		return result;
	},
	insert_profjr: function (company_name, job_title, start_month, start_year, end_month, end_year, Job_location, skill_used, key_responsibilities, job_type, user_id) {
		var result = UserProfJr.insert({
			user_id: user_id,
			company: company_name,
			title: job_title,
			start_month: start_month,
			start_year: start_year,
			end_month: end_month,
			end_year: end_year,
			location: Job_location,
			skill: skill_used,
			key_responsibilities: key_responsibilities,
			job_type: job_type,
			createdAt: new Date()
		});
		return result;
	},
	insert_awd: function (userId, awd_type, description, awd_month, awd_year, awd_location) {
		var result = UserAward.insert({
			user_id: userId,
			type: awd_type,
			description: description,
			awd_month: awd_month,
			awd_year: awd_year,
			location: awd_location,
			createdAt: new Date()
		});
		return result;
	},
	update_awd: function (userId, edit_id, awd_type, description, awd_month, awd_year, awd_location) {
		var result = UserAward.update({
			_id: edit_id
		}, {
			$set: {
				"type": awd_type,
				"description": description,
				"awd_month": awd_month,
				"awd_year": awd_year,
				"location": awd_location,
				"createdAt": new Date()
			}
		});
		return result;
	},
	insert_skill: function (userId, awd_expert, last_used, skill_name) {
		var result = UserSkill.insert({
			user_id: userId,
			awd_expert: awd_expert,
			last_used: last_used,
			skill_name: skill_name,
			createdAt: new Date()
		});
		return true;
	},
	update_skill: function (edit_id, awd_expert, last_used, skill_name) {
		var result = UserSkill.update({
			_id: edit_id
		}, {
			$set: {
				awd_expert: awd_expert,
				last_used: last_used,
				skill_name: skill_name,
				createdAt: new Date()
			}
		});
		return true;
	},
	update_profjr: function (edit_id, company_name, job_title, start_month, start_year, end_month, end_year, Job_location, skill_used, key_responsibilities, job_type) {
		var result = UserProfJr.update({
			_id: edit_id
		}, {
			$set: {
				company: company_name,
				title: job_title,
				start_month: start_month,
				start_year: start_year,
				end_month: end_month,
				end_year: end_year,
				location: Job_location,
				skill: skill_used,
				job_type: job_type,
				key_responsibilities: key_responsibilities,
				updatedAt: new Date()
			}
		});
		return true;
	},
	update_profjr_2: function (edit_id, company_name, job_title, start_month, end_month, Job_location, skill_used, key_responsibilities, job_type) {
		var result = UserProfJr.update({
			_id: edit_id
		}, {
			$set: {
				company: company_name,
				title: job_title,
				start_month: start_month,
				start_year: start_year,
				location: Job_location,
				skill: skill_used,
				job_type: job_type,
				key_responsibilities: key_responsibilities,
				updatedAt: new Date()
			}
		});
		return true;
	},
	update_education: function (edit_id, course, board, school, score, edu_start_month, edu_start_year, edu_end_month, edu_end_year, edu_location) {
		var result = UserEdu.update({
			_id: edit_id
		}, {
			$set: {
				'course': course,
				'board': board,
				'school': school,
				'score': score,
				'edu_start_month': edu_start_month,
				'edu_start_year': edu_start_year,
				'edu_end_month': edu_end_month,
				'edu_end_year': edu_end_year,
				'edu_location': edu_location
			}
		});
		return true;
	},
	upload_cover_image: function (user_id, imagePath) {
		var result = UserInfo.update({
			user_id: user_id
		}, {
			$set: {
				"cover_image": imagePath,
				"lastUpdateAt": new Date()
			}
		});
		return result;
	},
	upload_profile_image: function (user_id, imagePath) {
		var result = UserInfo.update({
			user_id: user_id
		}, {
			$set: {
				"profile_pic": imagePath,
				"lastUpdateAt": new Date()
			}
		});
		return result;
	},
	insert_message: function (sent_by, sent_to, msg_text, msg_id, chatroom_id, msg_img_id) {
		var result = Message.insert({
			msg_id: msg_id,
			sent_by: sent_by,
			sent_to: sent_to,
			chatroom_id: chatroom_id,
			msg_text: msg_text,
			image_attach: msg_img_id,
			sentAt: new Date()
		});
		return true;
	},
	insert_message_With_img: function (sent_by, sent_to, msg_img_id, msg_id) {
		var result = Message.insert({
			msg_id: msg_id,
			sent_by: sent_by,
			sent_to: sent_to,
			msg_text: 0,
			image_attach: msg_img_id,
			sentAt: new Date()
		});
		return true;
	},
	insert_message_With_attachment: function (msg_id, sent_to, sent_by, attach_name, attach_path, format) {
		var result = Message.insert({
			msg_id: msg_id,
			sent_by: sent_by,
			sent_to: sent_to,
			msg_text: 0,
			image_attach: 0,
			attachment_name: attach_name,
			attachment_path: attach_path,
			format: format,
			sentAt: new Date()
		});
		return true;
	},
	insert_Group_details: function (user_id, grp_image, grp_title, grp_type, grp_discription, grp_visibility, grp_id) {
		var result = UserGroup.insert({
			grp_id: grp_id,
			grp_title: grp_title,
			admin: user_id,
			grp_type: grp_type,
			grp_discription: grp_discription,
			grp_visibility: grp_visibility,
			grp_image: grp_image,
			activity_status: 1,
			createdAt: new Date()
		});
		return true;
	},
	update_Group_details: function (user_id, grp_image, grp_title, grp_type, grp_discription, grp_visibility, grp_id, activity_status) {
		var result = UserGroup.update({
			grp_id: grp_id
		}, {
			$set: {
				grp_title: grp_title,
				admin: user_id,
				grp_type: grp_type,
				grp_discription: grp_discription,
				grp_visibility: grp_visibility,
				grp_image: grp_image,
				activity_status: activity_status,
				UpdatedAt: new Date()
			}
		});
		return true;
	},
	sendEmail: function (userId, email) {
		Email.send(email);
	},
	update_Group_activity: function (grp_id, activity_status) {
		var result = UserGroup.update({
			grp_id: grp_id
		}, {
			$set: {
				"activity_status": activity_status,
				"lastUpdateAt": new Date()
			}
		});
		return result;
	},
	update_email_status: function (userId, email_status) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"email_status": 1
				}
			});
		}

		return result;
	},
	set_default_cover: function (userId, set_default) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"cover_image": set_default
				}
			});
		}

		return result;
	},
	set_default_profile_pic: function (userId, set_default) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"profile_pic": set_default
				}
			});
		}

		return result;
	},
	update_login_status: function (login_status, userId) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"login_status": login_status
				}
			});
		}

		return result;
	},
	update_passion: function (userId, passion) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"passion": passion
				}
			});
		}

		return result;
	},
	remove_skill: function (skill_id) {
		var result = UserSkill.remove({
			_id: skill_id
		});
		return result;
	},
	remove_award: function (awd_id) {
		var result = UserAward.remove({
			_id: awd_id
		});
		return result;
	},
	remove_profjr: function (profjr_id) {
		var result = UserProfJr.remove({
			_id: profjr_id
		});
		return result;
	},
	remove_education: function (edu_id) {
		var result = UserEdu.remove({
			_id: edu_id
		});
		return result;
	},
	remove_group_request: function (sent_by, grp_id) {
		var result = GroupRequest.remove({
			sent_by: sent_by,
			grp_id: grp_id
		});
		return result;
	},
	insert_group_request: function (req_id, sent_by, grp_id, status) {
		var result = GroupRequest.insert({
			req_id: req_id,
			sent_by: sent_by,
			grp_id: grp_id,
			status: status,
			sentAt: new Date()
		});
		return result;
	},
	Update_Chatroom: function (chatroom_id, user1, user2, last_msg, last_msg_id, last_msg_sent_by, connect_status, currently_typing) {
		var newUser = Chatroom.find({
			chatroom_id: chatroom_id
		}).fetch();
		var total_messages = Message.find({
			"chatroom_id": chatroom_id
		}).count();

		if (newUser[0]) {
			var result = Chatroom.update({
				_id: newUser[0]._id
			}, {
				$set: {
					total_messages: total_messages + 1,
					last_msg: last_msg,
					last_msg_id: last_msg_id,
					last_msg_time: Date.now(),
					last_msg_sent_by: last_msg_sent_by,
					connect_status: connect_status,
					currently_typing: currently_typing
				}
			});
		} else {
			var result = Chatroom.insert({
				chatroom_id: chatroom_id,
				user1: user1,
				user2: user2,
				last_msg_id: last_msg_id,
				last_msg: last_msg,
				last_msg_time: Date.now(),
				last_msg_sent_by: last_msg_sent_by,
				connect_status: connect_status,
				currently_typing: currently_typing
			});
		}

		return result;
	},
	Update_currently_typing: function (chatroom_id, currently_typing) {
		var newUser = Chatroom.find({
			chatroom_id: chatroom_id
		}).fetch();

		if (newUser[0]) {
			var result = Chatroom.update({
				_id: newUser[0]._id
			}, {
				$set: {
					currently_typing: currently_typing
				}
			});
		}

		return result;
	},
	change_user_online_status: function (userId, status) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"online_status": status
				}
			});
		}

		return result;
	},
	update_chatroom_count: function (chatroom_id, count) {
		var newUser = Chatroom.find({
			chatroom_id: chatroom_id
		}).fetch();
		var updatedCount = 0;

		if (newUser[0].unread_msg_count) {
			updatedCount = newUser[0].unread_msg_count + 1;
		} else {
			updatedCount = 1;
		}

		if (count == 0) {
			updatedCount = 0;
		}

		if (newUser[0]) {
			var result = Chatroom.update({
				_id: newUser[0]._id
			}, {
				$set: {
					last_msg_time: Date.now(),
					unread_msg_count: updatedCount
				}
			});
		}

		return result;
	},
	update_last_msg_status: function (message_id, status) {
		var newUser = Message.find({
			"msg_id": message_id
		}).fetch();

		if (status == "read") {
			var newUser = Message.find({
				"chatroom_id": newUser[0].chatroom_id
			}).fetch();

			for (var i = 0; i < newUser.length; i++) {
				var result = Message.update({
					_id: newUser[i]._id
				}, {
					$set: {
						"delivery_status": "read"
					}
				});
			}
		} else {
			if (newUser[0]) {
				var result = Message.update({
					_id: newUser[0]._id
				}, {
					$set: {
						"delivery_status": status
					}
				});
			}
		}

		return result;
	}
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/config.js");
require("./import/collections/insert.js");
require("./import/config.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0L2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiQmFzZTY0IiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIlNlc3Npb24iLCJSb3V0ZXIiLCJyb3V0ZSIsImdldCIsInJlbmRlciIsImdvIiwicGFyYW1zIiwidXNlcklkIiwidXNlcl9pZCIsImRlY29kZSIsInNldCIsImlkIiwic2V0UGVyc2lzdGVudCIsImVuY3J5cHRlZCIsImdycF9pZCIsImV4cG9ydCIsIlVzZXJJbmZvIiwiVXNlclNraWxsIiwiVXNlclByb2ZKciIsIlVzZXJFZHUiLCJVc2VyQXdhcmQiLCJVc2VyTWVkaWNhbCIsIkZyaWVuZFJlcXVlc3QiLCJNZXNzYWdlIiwiVXNlckdyb3VwIiwiR3JvdXBSZXF1ZXN0IiwiQ2hhdHJvb20iLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJJbWFnZXMiLCJGaWxlc0NvbGxlY3Rpb24iLCJkZWJ1ZyIsImNvbGxlY3Rpb25OYW1lIiwiYWxsb3dDbGllbnRDb2RlIiwic3RvcmFnZVBhdGgiLCJwcm9jZXNzIiwiZW52IiwiUFdEIiwib25CZWZvcmVVcGxvYWQiLCJmaWxlIiwic2l6ZSIsInRlc3QiLCJleHRlbnNpb24iLCJleHBvcnREZWZhdWx0IiwiTWV0ZW9yIiwiRW1haWwiLCJTZXJ2aWNlQ29uZmlndXJhdGlvbiIsInN0YXJ0dXAiLCJVcGxvYWRTZXJ2ZXIiLCJpbml0IiwidG1wRGlyIiwidXBsb2FkRGlyIiwiY29uZmlndXJhdGlvbnMiLCJyZW1vdmUiLCJzZXJ2aWNlIiwiaW5zZXJ0IiwiY2xpZW50SWQiLCJzZWNyZXQiLCJhcHBJZCIsInNtdHAiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwic2VydmVyIiwicG9ydCIsIk1BSUxfVVJMIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwibWV0aG9kcyIsImxvZ291dF9nb29nbGUiLCJuYW1lIiwicmVzdWx0IiwidXNlcnMiLCJ1cGRhdGUiLCJfaWQiLCIkc2V0IiwibXVsdGkiLCJpbnNlcnRfYWRkcmVzcyIsImFkZHJlc3MiLCJuZXdVc2VyIiwiZmluZCIsImZldGNoIiwibG9jYXRpb24iLCJjcmVhdGVkQXQiLCJEYXRlIiwiaW5zZXJ0X2NvbnRhY3Rfbm8iLCJjb250YWN0bm8iLCJwaG9uZSIsImluc2VydF9kaXNhYmlsaXRpZXMiLCJoZWFyaW5nIiwic3BlZWNoIiwidmlzdWFsIiwicGh5c2ljYWwiLCJzcGVjaWFsX25vdGUiLCJ1cGxvYWRfdXNlcl9pbWFnZSIsInByb2ZpbGVfcGljIiwidXBkYXRlX2hlYWRsaW5lIiwiaGVhZGxpbmUiLCJsb2dpbl9zdGF0dXMiLCJ1cGRhdGVfc3VtbWFyeSIsInN1bW1hcnkiLCJjcmVhdGVfdXNlciIsInVzZXJJRCIsInNvdXJjZSIsImVtYWlsIiwiZW1haWxfc3RhdHVzIiwiY29uX3JlcV9pbnNlcnQiLCJzZW50X3RvIiwic2VudF9ieSIsInJlcUlEIiwicmVxX2lkIiwicmVxX3N0YXR1cyIsInJlcXVlc3RlZEF0IiwidXBkYXRlZEF0IiwiY29uX3JlcV91cGRhdGUiLCJyZXF1ZXN0X3R5cGUiLCJwZXJzX2luZm9fdXBkYXRlIiwiZ2VuZGVyIiwibWFyaXRhbF9zdGF0dXMiLCJkYXRlcGlja2VyIiwiYXV0b2NvbXBsZXRlIiwiaW5zZXJ0X2VkdWNhdGlvbiIsImNvdXJzZSIsImJvYXJkIiwic2Nob29sIiwic2NvcmUiLCJlZHVfc3RhcnRfbW9udGgiLCJlZHVfc3RhcnRfeWVhciIsImVkdV9lbmRfbW9udGgiLCJlZHVfZW5kX3llYXIiLCJlZHVfbG9jYXRpb24iLCJpbnNlcnRfcHJvZmpyIiwiY29tcGFueV9uYW1lIiwiam9iX3RpdGxlIiwic3RhcnRfbW9udGgiLCJzdGFydF95ZWFyIiwiZW5kX21vbnRoIiwiZW5kX3llYXIiLCJKb2JfbG9jYXRpb24iLCJza2lsbF91c2VkIiwia2V5X3Jlc3BvbnNpYmlsaXRpZXMiLCJqb2JfdHlwZSIsImNvbXBhbnkiLCJ0aXRsZSIsInNraWxsIiwiaW5zZXJ0X2F3ZCIsImF3ZF90eXBlIiwiZGVzY3JpcHRpb24iLCJhd2RfbW9udGgiLCJhd2RfeWVhciIsImF3ZF9sb2NhdGlvbiIsInR5cGUiLCJ1cGRhdGVfYXdkIiwiZWRpdF9pZCIsImluc2VydF9za2lsbCIsImF3ZF9leHBlcnQiLCJsYXN0X3VzZWQiLCJza2lsbF9uYW1lIiwidXBkYXRlX3NraWxsIiwidXBkYXRlX3Byb2ZqciIsInVwZGF0ZV9wcm9manJfMiIsInVwZGF0ZV9lZHVjYXRpb24iLCJ1cGxvYWRfY292ZXJfaW1hZ2UiLCJpbWFnZVBhdGgiLCJ1cGxvYWRfcHJvZmlsZV9pbWFnZSIsImluc2VydF9tZXNzYWdlIiwibXNnX3RleHQiLCJtc2dfaWQiLCJjaGF0cm9vbV9pZCIsIm1zZ19pbWdfaWQiLCJpbWFnZV9hdHRhY2giLCJzZW50QXQiLCJpbnNlcnRfbWVzc2FnZV9XaXRoX2ltZyIsImluc2VydF9tZXNzYWdlX1dpdGhfYXR0YWNobWVudCIsImF0dGFjaF9uYW1lIiwiYXR0YWNoX3BhdGgiLCJmb3JtYXQiLCJhdHRhY2htZW50X25hbWUiLCJhdHRhY2htZW50X3BhdGgiLCJpbnNlcnRfR3JvdXBfZGV0YWlscyIsImdycF9pbWFnZSIsImdycF90aXRsZSIsImdycF90eXBlIiwiZ3JwX2Rpc2NyaXB0aW9uIiwiZ3JwX3Zpc2liaWxpdHkiLCJhZG1pbiIsImFjdGl2aXR5X3N0YXR1cyIsInVwZGF0ZV9Hcm91cF9kZXRhaWxzIiwiVXBkYXRlZEF0Iiwic2VuZEVtYWlsIiwic2VuZCIsInVwZGF0ZV9Hcm91cF9hY3Rpdml0eSIsInVwZGF0ZV9lbWFpbF9zdGF0dXMiLCJzZXRfZGVmYXVsdF9jb3ZlciIsInNldF9kZWZhdWx0Iiwic2V0X2RlZmF1bHRfcHJvZmlsZV9waWMiLCJ1cGRhdGVfbG9naW5fc3RhdHVzIiwidXBkYXRlX3Bhc3Npb24iLCJwYXNzaW9uIiwicmVtb3ZlX3NraWxsIiwic2tpbGxfaWQiLCJyZW1vdmVfYXdhcmQiLCJhd2RfaWQiLCJyZW1vdmVfcHJvZmpyIiwicHJvZmpyX2lkIiwicmVtb3ZlX2VkdWNhdGlvbiIsImVkdV9pZCIsInJlbW92ZV9ncm91cF9yZXF1ZXN0IiwiaW5zZXJ0X2dyb3VwX3JlcXVlc3QiLCJzdGF0dXMiLCJVcGRhdGVfQ2hhdHJvb20iLCJ1c2VyMSIsInVzZXIyIiwibGFzdF9tc2ciLCJsYXN0X21zZ19pZCIsImxhc3RfbXNnX3NlbnRfYnkiLCJjb25uZWN0X3N0YXR1cyIsImN1cnJlbnRseV90eXBpbmciLCJ0b3RhbF9tZXNzYWdlcyIsImNvdW50IiwibGFzdF9tc2dfdGltZSIsIm5vdyIsIlVwZGF0ZV9jdXJyZW50bHlfdHlwaW5nIiwiY2hhbmdlX3VzZXJfb25saW5lX3N0YXR1cyIsInVwZGF0ZV9jaGF0cm9vbV9jb3VudCIsInVwZGF0ZWRDb3VudCIsInVucmVhZF9tc2dfY291bnQiLCJ1cGRhdGVfbGFzdF9tc2dfc3RhdHVzIiwibWVzc2FnZV9pZCIsImkiLCJsZW5ndGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUE3QyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJQyxPQUFKO0FBQVlKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNFLFVBQVFELENBQVIsRUFBVTtBQUFDQyxjQUFRRCxDQUFSO0FBQVU7O0FBQXRCLENBQXZDLEVBQStELENBQS9EO0FBSzdGRSxPQUFPQyxLQUFQLENBQWEsVUFBYixFQUF5QixZQUFZO0FBQ25DLE1BQUdGLFFBQVFHLEdBQVIsQ0FBWSxRQUFaLEtBQXVCLEVBQTFCLEVBQTZCO0FBQzdCLFNBQUtDLE1BQUwsQ0FBWSxTQUFaO0FBQ0QsR0FGQyxNQUVHO0FBQ0hILFdBQU9JLEVBQVAsQ0FBVSxHQUFWO0FBQ0Q7QUFDQSxDQU5EO0FBUUFKLE9BQU9DLEtBQVAsQ0FBYSx3QkFBYixFQUF1QyxZQUFZO0FBQ2hELE1BQUtJLFNBQVMsS0FBS0EsTUFBbkIsQ0FEZ0QsQ0FDckI7QUFDNUI7O0FBRUUsTUFBSUMsU0FBU0QsT0FBT0UsT0FBcEIsQ0FKK0MsQ0FJbEI7O0FBQzdCRCxXQUFTWixPQUFPYyxNQUFQLENBQWNGLE1BQWQsQ0FBVCxDQUwrQyxDQU03QztBQUNKO0FBQ0E7O0FBQ0FQLFVBQVFVLEdBQVIsQ0FBWSxpQkFBWixFQUE4QkgsTUFBOUIsRUFUaUQsQ0FVakQ7O0FBQ0EsT0FBS0gsTUFBTCxDQUFZLGNBQVo7QUFDRCxDQVpEO0FBY0FILE9BQU9DLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLFlBQVk7QUFDNUIsT0FBS0UsTUFBTCxDQUFZLE9BQVo7QUFDRCxDQUZEO0FBSUFILE9BQU9DLEtBQVAsQ0FBYSxTQUFiLEVBQXdCLFlBQVk7QUFDakMsTUFBR0YsUUFBUUcsR0FBUixDQUFZLFFBQVosS0FBdUIsRUFBMUIsRUFBNkI7QUFDL0IsU0FBS0MsTUFBTCxDQUFZLFFBQVo7QUFDQSxHQUZFLE1BRUU7QUFDSEgsV0FBT0ksRUFBUCxDQUFVLEdBQVY7QUFDRDtBQUdBLENBUkQ7QUFVQUosT0FBT0MsS0FBUCxDQUFhLGFBQWIsRUFBNEIsWUFBWTtBQUN0QyxPQUFLRSxNQUFMLENBQVksWUFBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLFlBQWIsRUFBMkIsWUFBWTtBQUNyQyxPQUFLRSxNQUFMLENBQVksZUFBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLGFBQWIsRUFBNEIsWUFBWTtBQUN0QyxPQUFLRSxNQUFMLENBQVksWUFBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLG1CQUFiLEVBQWtDLFlBQVk7QUFDNUMsT0FBS0UsTUFBTCxDQUFZLGtCQUFaO0FBQ0QsQ0FGRDtBQUlBSCxPQUFPQyxLQUFQLENBQWEsUUFBYixFQUF1QixZQUN2QjtBQUFHLE1BQUdGLFFBQVFHLEdBQVIsQ0FBWSxRQUFaLEtBQXVCLEVBQTFCLEVBQTZCO0FBQzlCLFNBQUtDLE1BQUwsQ0FBWSxPQUFaO0FBQ0QsR0FGRSxNQUVFO0FBQ0hILFdBQU9JLEVBQVAsQ0FBVSxHQUFWO0FBQ0Q7QUFFQSxDQVBEO0FBU0FKLE9BQU9DLEtBQVAsQ0FBYSxxQkFBYixFQUFvQyxZQUFZO0FBQzlDLE1BQUtJLFNBQVMsS0FBS0EsTUFBbkIsQ0FEOEMsQ0FDbkI7O0FBQzNCLE1BQUlDLFNBQVNELE9BQU9LLEVBQXBCLENBRjhDLENBRXRCOztBQUN0QkosV0FBU1osT0FBT2MsTUFBUCxDQUFjRixNQUFkLENBQVQsQ0FINEMsQ0FJMUM7O0FBQ0pQLFVBQVFVLEdBQVIsQ0FBWSxnQkFBWixFQUE2QixNQUE3QjtBQUNBVixVQUFRWSxhQUFSLENBQXNCLFFBQXRCLEVBQStCTCxNQUEvQjtBQUNBLE9BQUtILE1BQUwsQ0FBWSxPQUFaO0FBR0QsQ0FWRDtBQWNBSCxPQUFPQyxLQUFQLENBQWEsY0FBYixFQUE2QixZQUFZO0FBQ3ZDLE9BQUtFLE1BQUwsQ0FBWSxhQUFaO0FBQ0QsQ0FGRDtBQUlBSCxPQUFPQyxLQUFQLENBQWEsaUJBQWIsRUFBZ0MsWUFBWTtBQUMxQyxPQUFLRSxNQUFMLENBQVksZ0JBQVo7QUFDRCxDQUZEO0FBSUFILE9BQU9DLEtBQVAsQ0FBYSxzQkFBYixFQUFxQyxZQUFZO0FBQy9DLE1BQUtJLFNBQVMsS0FBS0EsTUFBbkIsQ0FEK0MsQ0FDcEI7O0FBQzNCLE1BQUlPLFlBQVlQLE9BQU9RLE1BQXZCLENBRitDLENBRWhCO0FBRWpDO0FBQ0E7O0FBRUFkLFVBQVFVLEdBQVIsQ0FBWSxhQUFaLEVBQTBCRyxTQUExQjtBQUNDLE9BQUtULE1BQUwsQ0FBWSxhQUFaO0FBQ0EsQ0FURDtBQVdBSCxPQUFPQyxLQUFQLENBQWEsb0JBQWIsRUFBbUMsWUFBWTtBQUM3QyxNQUFLSSxTQUFTLEtBQUtBLE1BQW5CLENBRDZDLENBQ2xCOztBQUMzQixNQUFJTyxZQUFZUCxPQUFPUSxNQUF2QixDQUY2QyxDQUVkO0FBRWpDO0FBQ0E7O0FBRUFkLFVBQVFVLEdBQVIsQ0FBWSxrQkFBWixFQUErQkcsU0FBL0I7QUFDRSxPQUFLVCxNQUFMLENBQVksV0FBWjtBQUNELENBVEQ7QUFXQUgsT0FBT0MsS0FBUCxDQUFhLFNBQWIsRUFBd0IsWUFBWTtBQUNsQyxPQUFLRSxNQUFMLENBQVksT0FBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLGlCQUFiLEVBQWdDLFlBQVk7QUFDMUMsT0FBS0UsTUFBTCxDQUFZLGdCQUFaO0FBQ0QsQ0FGRDtBQUlBSCxPQUFPQyxLQUFQLENBQWEsa0JBQWIsRUFBaUMsWUFBWTtBQUMzQyxPQUFLRSxNQUFMLENBQVksaUJBQVo7QUFDRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDdEhBUixPQUFPbUIsTUFBUCxDQUFjO0FBQUNDLFlBQVMsTUFBSUEsUUFBZDtBQUF1QkMsYUFBVSxNQUFJQSxTQUFyQztBQUErQ0MsY0FBVyxNQUFJQSxVQUE5RDtBQUF5RUMsV0FBUSxNQUFJQSxPQUFyRjtBQUE2RkMsYUFBVSxNQUFJQSxTQUEzRztBQUFxSEMsZUFBWSxNQUFJQSxXQUFySTtBQUFpSkMsaUJBQWMsTUFBSUEsYUFBbks7QUFBaUxDLFdBQVEsTUFBSUEsT0FBN0w7QUFBcU1DLGFBQVUsTUFBSUEsU0FBbk47QUFBNk5DLGdCQUFhLE1BQUlBLFlBQTlPO0FBQTJQQyxZQUFTLE1BQUlBO0FBQXhRLENBQWQ7QUFBaVMsSUFBSUMsS0FBSjtBQUFVL0IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNkIsUUFBTTVCLENBQU4sRUFBUTtBQUFDNEIsWUFBTTVCLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFcFMsTUFBTWlCLFdBQVcsSUFBSVcsTUFBTUMsVUFBVixDQUFxQixXQUFyQixDQUFqQjtBQUNBLE1BQU1YLFlBQVksSUFBSVUsTUFBTUMsVUFBVixDQUFxQixZQUFyQixDQUFsQjtBQUNBLE1BQU1WLGFBQWEsSUFBSVMsTUFBTUMsVUFBVixDQUFxQixhQUFyQixDQUFuQjtBQUNBLE1BQU1ULFVBQVUsSUFBSVEsTUFBTUMsVUFBVixDQUFxQixVQUFyQixDQUFoQjtBQUNBLE1BQU1SLFlBQVksSUFBSU8sTUFBTUMsVUFBVixDQUFxQixZQUFyQixDQUFsQjtBQUNBLE1BQU1QLGNBQWMsSUFBSU0sTUFBTUMsVUFBVixDQUFxQixjQUFyQixDQUFwQjtBQUVBLE1BQU1OLGdCQUFnQixJQUFJSyxNQUFNQyxVQUFWLENBQXFCLFFBQXJCLENBQXRCO0FBQ0EsTUFBTUwsVUFBVSxJQUFJSSxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLENBQWhCO0FBQ0EsTUFBTUosWUFBWSxJQUFJRyxNQUFNQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCO0FBQ0EsTUFBTUgsZUFBZSxJQUFJRSxNQUFNQyxVQUFWLENBQXFCLGVBQXJCLENBQXJCO0FBQ0EsTUFBTUYsV0FBVyxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFVBQXJCLENBQWpCLEM7Ozs7Ozs7Ozs7O0FDYlBoQyxPQUFPbUIsTUFBUCxDQUFjO0FBQUNjLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUlDLGVBQUo7QUFBb0JsQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYixFQUE0QztBQUFDZ0Msa0JBQWdCL0IsQ0FBaEIsRUFBa0I7QUFBQytCLHNCQUFnQi9CLENBQWhCO0FBQWtCOztBQUF0QyxDQUE1QyxFQUFvRixDQUFwRjtBQUVoRCxNQUFNOEIsU0FBUyxJQUFJQyxlQUFKLENBQW9CO0FBQ3hDQyxTQUFPLElBRGlDO0FBRXhDQyxrQkFBZ0IsUUFGd0I7QUFHeENDLG1CQUFpQixLQUh1QjtBQUdoQjtBQUN4QkMsZUFBYSxNQUFNO0FBQ2IsV0FBUSxHQUFFQyxRQUFRQyxHQUFSLENBQVlDLEdBQUksVUFBMUI7QUFDTCxHQU51QztBQU1uQ0Msa0JBQWdCLFVBQVVDLElBQVYsRUFBZ0I7QUFDbkM7QUFDQSxRQUFJQSxLQUFLQyxJQUFMLElBQWEsT0FBTyxJQUFQLEdBQWMsRUFBM0IsSUFBaUMsYUFBYUMsSUFBYixDQUFrQkYsS0FBS0csU0FBdkIsQ0FBckMsRUFBd0U7QUFDdEUsYUFBTyxJQUFQO0FBQ0Q7O0FBQ0QsV0FBTyx3REFBUDtBQUNEO0FBWnVDLENBQXBCLENBQWY7QUFGUDlDLE9BQU8rQyxhQUFQLENBaUJlZCxNQWpCZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUllLE1BQUo7QUFBV2hELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQzhDLFFBQU83QyxDQUFQLEVBQVM7QUFBQzZDLFdBQU83QyxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlpQixRQUFKO0FBQWFwQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDa0IsVUFBU2pCLENBQVQsRUFBVztBQUFDaUIsYUFBU2pCLENBQVQ7QUFBVzs7QUFBeEIsQ0FBMUQsRUFBb0YsQ0FBcEY7QUFBdUYsSUFBSWtCLFNBQUo7QUFBY3JCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUNtQixXQUFVbEIsQ0FBVixFQUFZO0FBQUNrQixjQUFVbEIsQ0FBVjtBQUFZOztBQUExQixDQUExRCxFQUFzRixDQUF0RjtBQUF5RixJQUFJbUIsVUFBSjtBQUFldEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ29CLFlBQVduQixDQUFYLEVBQWE7QUFBQ21CLGVBQVduQixDQUFYO0FBQWE7O0FBQTVCLENBQTFELEVBQXdGLENBQXhGO0FBQTJGLElBQUlvQixPQUFKO0FBQVl2QixPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDcUIsU0FBUXBCLENBQVIsRUFBVTtBQUFDb0IsWUFBUXBCLENBQVI7QUFBVTs7QUFBdEIsQ0FBMUQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSXFCLFNBQUo7QUFBY3hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUNzQixXQUFVckIsQ0FBVixFQUFZO0FBQUNxQixjQUFVckIsQ0FBVjtBQUFZOztBQUExQixDQUExRCxFQUFzRixDQUF0RjtBQUF5RixJQUFJc0IsV0FBSjtBQUFnQnpCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUN1QixhQUFZdEIsQ0FBWixFQUFjO0FBQUNzQixnQkFBWXRCLENBQVo7QUFBYzs7QUFBOUIsQ0FBMUQsRUFBMEYsQ0FBMUY7QUFBNkYsSUFBSXVCLGFBQUo7QUFBa0IxQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDd0IsZUFBY3ZCLENBQWQsRUFBZ0I7QUFBQ3VCLGtCQUFjdkIsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBMUQsRUFBOEYsQ0FBOUY7QUFBaUcsSUFBSXdCLE9BQUo7QUFBWTNCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUN5QixTQUFReEIsQ0FBUixFQUFVO0FBQUN3QixZQUFReEIsQ0FBUjtBQUFVOztBQUF0QixDQUExRCxFQUFrRixDQUFsRjtBQUFxRixJQUFJeUIsU0FBSjtBQUFjNUIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQzBCLFdBQVV6QixDQUFWLEVBQVk7QUFBQ3lCLGNBQVV6QixDQUFWO0FBQVk7O0FBQTFCLENBQTFELEVBQXNGLENBQXRGO0FBQXlGLElBQUk4QyxLQUFKO0FBQVVqRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMrQyxPQUFNOUMsQ0FBTixFQUFRO0FBQUM4QyxVQUFNOUMsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxFQUF6RDtBQUE2RCxJQUFJMEIsWUFBSjtBQUFpQjdCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUMyQixjQUFhMUIsQ0FBYixFQUFlO0FBQUMwQixpQkFBYTFCLENBQWI7QUFBZTs7QUFBaEMsQ0FBMUQsRUFBNEYsRUFBNUY7QUFBZ0csSUFBSTJCLFFBQUo7QUFBYTlCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUM0QixVQUFTM0IsQ0FBVCxFQUFXO0FBQUMyQixhQUFTM0IsQ0FBVDtBQUFXOztBQUF4QixDQUExRCxFQUFvRixFQUFwRjtBQUF3RixJQUFJK0Msb0JBQUo7QUFBeUJsRCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsOEJBQVIsQ0FBYixFQUFxRDtBQUFDZ0Qsc0JBQXFCL0MsQ0FBckIsRUFBdUI7QUFBQytDLHlCQUFxQi9DLENBQXJCO0FBQXVCOztBQUFoRCxDQUFyRCxFQUF1RyxFQUF2RztBQW1CcnlDNkMsT0FBT0csT0FBUCxDQUFlLFlBQVk7QUFDekJDLGNBQWFDLElBQWIsQ0FBa0I7QUFDaEJDLFVBQVFmLFFBQVFDLEdBQVIsQ0FBWUMsR0FBWixHQUFrQixlQURWO0FBRWhCYyxhQUFXaEIsUUFBUUMsR0FBUixDQUFZQyxHQUFaLEdBQWtCO0FBRmIsRUFBbEI7QUFJRCxDQUxELEUsQ0FVQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBOztBQUdBUyxxQkFBcUJNLGNBQXJCLENBQW9DQyxNQUFwQyxDQUEyQztBQUN6Q0MsVUFBUztBQURnQyxDQUEzQztBQUlBUixxQkFBcUJNLGNBQXJCLENBQW9DRyxNQUFwQyxDQUEyQztBQUN6Q0QsVUFBUyxRQURnQztBQUV6Q0UsV0FBVSwwRUFGK0I7QUFHekNDLFNBQVE7QUFIaUMsQ0FBM0MsRSxDQU1BOztBQUNBWCxxQkFBcUJNLGNBQXJCLENBQW9DQyxNQUFwQyxDQUEyQztBQUN6Q0MsVUFBUztBQURnQyxDQUEzQztBQUlBUixxQkFBcUJNLGNBQXJCLENBQW9DRyxNQUFwQyxDQUEyQztBQUN6Q0QsVUFBUyxVQURnQztBQUV6Q0ksUUFBTyxpQkFGa0M7QUFHekNELFNBQVE7QUFIaUMsQ0FBM0M7QUFNQVgscUJBQXFCTSxjQUFyQixDQUFvQ0MsTUFBcEMsQ0FBMkM7QUFDekNDLFVBQVM7QUFEZ0MsQ0FBM0M7QUFJQVIscUJBQXFCTSxjQUFyQixDQUFvQ0csTUFBcEMsQ0FBMkM7QUFDekNELFVBQVMsVUFEZ0M7QUFFekNFLFdBQVUsZ0JBRitCO0FBR3pDQyxTQUFRO0FBSGlDLENBQTNDLEUsQ0FLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUNFLE9BQU87QUFDSkMsV0FBVSx1QkFETjtBQUVKQyxXQUFVLGtCQUZOO0FBR0pDLFNBQVEsZ0JBSEo7QUFJSkMsT0FBTTtBQUpGLENBQVA7QUFNQzVCLFFBQVFDLEdBQVIsQ0FBWTRCLFFBQVosR0FBdUIsWUFBWUMsbUJBQW1CTixLQUFLQyxRQUF4QixDQUFaLEdBQWdELEdBQWhELEdBQXNESyxtQkFBbUJOLEtBQUtFLFFBQXhCLENBQXRELEdBQTBGLEdBQTFGLEdBQWdHSSxtQkFBbUJOLEtBQUtHLE1BQXhCLENBQWhHLEdBQWtJLEdBQWxJLEdBQXdJSCxLQUFLSSxJQUFwSztBQUVGbkIsT0FBT3NCLE9BQVAsQ0FBZTtBQUVmQyxnQkFBZSxVQUFTQyxJQUFULEVBQWM7QUFDN0IsTUFBSUMsU0FBU3pCLE9BQU8wQixLQUFQLENBQWFDLE1BQWIsQ0FBb0I7QUFDOUJDLFFBQUtKO0FBRHlCLEdBQXBCLEVBRVY7QUFDQUssU0FBTTtBQUNGLG1DQUErQjtBQUQ3QjtBQUROLEdBRlUsRUFNVjtBQUNBQyxVQUFPO0FBRFAsR0FOVSxDQUFiO0FBU0EsU0FBT0wsTUFBUDtBQUNDLEVBYmM7QUFlYk0saUJBQWdCLFVBQVVwRSxNQUFWLEVBQWlCcUUsT0FBakIsRUFBMEI7QUFDekMsTUFBSUMsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDQSxNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxpQkFBWUc7QUFBYjtBQURMLElBRlMsQ0FBYjtBQUtFLEdBTkQsTUFNSztBQUNMLE9BQUlQLFNBQVFyRCxTQUFTdUMsTUFBVCxDQUFnQjtBQUMxQnlCLGNBQVNKLE9BRGlCO0FBRXBCcEUsYUFBUUQsTUFGWTtBQUdwQjBFLGVBQVcsSUFBSUMsSUFBSixFQUhTLENBR0M7O0FBSEQsSUFBaEIsQ0FBWjtBQUtDOztBQUNBLFNBQU9iLE1BQVA7QUFDRCxFQS9CWTtBQWlDYmMsb0JBQW1CLFVBQVU1RSxNQUFWLEVBQWlCNkUsU0FBakIsRUFBNEI7QUFDOUMsTUFBSVAsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDQSxNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxjQUFTVztBQUFWO0FBREwsSUFGUyxDQUFiO0FBS0UsR0FORCxNQU1LO0FBQ0wsT0FBSWYsU0FBUXJELFNBQVN1QyxNQUFULENBQWdCO0FBQzFCOEIsV0FBTUQsU0FEb0I7QUFFcEI1RSxhQUFRRCxNQUZZO0FBR3BCMEUsZUFBVSxJQUFJQyxJQUFKLEVBSFUsQ0FHQzs7QUFIRCxJQUFoQixDQUFaO0FBS0M7O0FBQ0EsU0FBT2IsTUFBUDtBQUNELEVBakRZO0FBa0RaaUIsc0JBQXFCLFVBQVUvRSxNQUFWLEVBQWlCZ0YsT0FBakIsRUFBMEJDLE1BQTFCLEVBQWtDQyxNQUFsQyxFQUEwQ0MsUUFBMUMsRUFBb0RDLFlBQXBELEVBQWtFO0FBQ3ZGLE1BQUlkLFVBQVV4RCxZQUFZeUQsSUFBWixDQUFpQjtBQUFDLGNBQVV2RTtBQUFYLEdBQWpCLEVBQXFDd0UsS0FBckMsRUFBZDs7QUFDQSxNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBUWhELFlBQVlrRCxNQUFaLENBQW1CO0FBQzVCL0QsYUFBU0Q7QUFEbUIsSUFBbkIsRUFFUjtBQUNEa0UsVUFBTTtBQUNMLGdCQUFXYyxPQUROO0FBRUwsZUFBVUMsTUFGTDtBQUdMLGVBQVVDLE1BSEw7QUFJTCxpQkFBWUMsUUFKUDtBQUtMLHFCQUFnQkM7QUFMWDtBQURMLElBRlEsQ0FBWjtBQVlFLEdBYkQsTUFhSztBQUVOLE9BQUl0QixTQUFRaEQsWUFBWWtDLE1BQVosQ0FBbUI7QUFDdEIvQyxhQUFTRCxNQURhO0FBRXRCZ0YsYUFBU0EsT0FGYTtBQUcxQkMsWUFBUUEsTUFIa0I7QUFJMUJDLFlBQVFBLE1BSmtCO0FBSzFCQyxjQUFVQSxRQUxnQjtBQU0xQkMsa0JBQWNBLFlBTlk7QUFPdEJWLGVBQVcsSUFBSUMsSUFBSixFQVBXLENBT0E7O0FBUEEsSUFBbkIsQ0FBWjtBQVdBLE9BQUlMLFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsZUFBVXZFO0FBQVgsSUFBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0csT0FBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLFFBQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsVUFBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsS0FBaEIsRUFFVDtBQUNEQyxXQUFNO0FBQUMscUJBQWU7QUFBaEI7QUFETCxLQUZTLENBQWI7QUFLRTtBQUlGOztBQUVBLFNBQU9KLE1BQVA7QUFDRCxFQTVGWTtBQTZGYnVCLG9CQUFrQixVQUFTckYsTUFBVCxFQUFnQnNGLFdBQWhCLEVBQTRCO0FBQzlDLE1BQUloQixVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNDLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLG9CQUFlb0I7QUFBaEI7QUFETCxJQUZTLENBQWI7QUFLRSxHQU5ELE1BTUs7QUFFTCxPQUFJeEIsU0FBUXJELFNBQVN1QyxNQUFULENBQWdCO0FBQzFCc0MsaUJBQVlBLFdBRGM7QUFFcEJyRixhQUFRRCxNQUZZO0FBR3BCMEUsZUFBVSxJQUFJQyxJQUFKLEVBSFUsQ0FHQzs7QUFIRCxJQUFoQixDQUFaO0FBTUM7O0FBQ0QsU0FBT2IsTUFBUDtBQUNBLEVBL0dZO0FBaUhieUIsa0JBQWdCLFVBQVN2RixNQUFULEVBQWdCd0YsUUFBaEIsRUFBeUI7QUFDekMsTUFBSWxCLFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsY0FBVXZFO0FBQVgsR0FBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0MsTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQUMsaUJBQVlzQjtBQUFiO0FBREwsSUFGUyxDQUFiO0FBS0UsR0FORCxNQU1LO0FBQ0wsT0FBSTFCLFNBQVFyRCxTQUFTdUMsTUFBVCxDQUFnQjtBQUMxQndDLGNBQVNBLFFBRGlCO0FBRXBCdkYsYUFBUUQsTUFGWTtBQUdwQnlGLGtCQUFjLENBSE07QUFJcEJmLGVBQVUsSUFBSUMsSUFBSixFQUpVLENBSUM7O0FBSkQsSUFBaEIsQ0FBWjtBQU9DOztBQUNELFNBQU9iLE1BQVA7QUFDQSxFQW5JWTtBQXFJYjRCLGlCQUFlLFVBQVMxRixNQUFULEVBQWdCMkYsT0FBaEIsRUFBd0I7QUFDdkMsTUFBSXJCLFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsY0FBVXZFO0FBQVgsR0FBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0MsTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQUMsZ0JBQVd5QjtBQUFaO0FBREwsSUFGUyxDQUFiO0FBS0UsR0FORCxNQU1LO0FBQ0wsT0FBSTdCLFNBQVFyRCxTQUFTdUMsTUFBVCxDQUFnQjtBQUMxQjJDLGFBQVFBLE9BRGtCO0FBRXBCMUYsYUFBUUQsTUFGWTtBQUdwQjBFLGVBQVUsSUFBSUMsSUFBSixFQUhVLENBR0M7O0FBSEQsSUFBaEIsQ0FBWjtBQUtDOztBQUNELFNBQU9iLE1BQVA7QUFDQSxFQXJKWTtBQXVKYjhCLGNBQVksVUFBU0MsTUFBVCxFQUFnQkMsTUFBaEIsRUFBdUJqQyxJQUF2QixFQUE0QmtDLEtBQTVCLEVBQWtDO0FBQzdDLE1BQUlqQyxTQUFRckQsU0FBU3VDLE1BQVQsQ0FBZ0I7QUFDMUJhLFNBQU1BLElBRG9CO0FBRXBCa0MsVUFBT0EsS0FGYTtBQUdwQjlGLFlBQVM0RixNQUhXO0FBSXBCQyxXQUFRQSxNQUpZO0FBS3BCRSxpQkFBYyxDQUxNO0FBTXBCdEIsY0FBVSxJQUFJQyxJQUFKLEVBTlUsQ0FNQzs7QUFORCxHQUFoQixDQUFaO0FBU0EsU0FBT2IsTUFBUDtBQUNBLEVBbEtZO0FBb0tQbUMsaUJBQWdCLFVBQVNDLE9BQVQsRUFBaUJDLE9BQWpCLEVBQXlCQyxLQUF6QixFQUErQjtBQUNuRCxNQUFJdEMsU0FBUy9DLGNBQWNpQyxNQUFkLENBQXFCO0FBQ2pDcUQsV0FBUUQsS0FEeUI7QUFFakNGLFlBQVNBLE9BRndCO0FBR2pDQyxZQUFTQSxPQUh3QjtBQUlqQ0csZUFBWSxDQUpxQjtBQUtqQ0MsZ0JBQWEsSUFBSTVCLElBQUosRUFMb0I7QUFNakM2QixjQUFXLElBQUk3QixJQUFKO0FBTnNCLEdBQXJCLENBQWI7QUFRRSxTQUFPYixNQUFQO0FBQ0UsRUE5S087QUFnTFIyQyxpQkFBZ0IsVUFBU04sT0FBVCxFQUFpQkQsT0FBakIsRUFBeUJRLFlBQXpCLEVBQXNDO0FBQ3pELE1BQUk1QyxTQUFTL0MsY0FBY2lELE1BQWQsQ0FBcUI7QUFDakNtQyxZQUFTQSxPQUR3QjtBQUVqQ0QsWUFBU0E7QUFGd0IsR0FBckIsRUFHWDtBQUNEaEMsU0FBTTtBQUFDLGtCQUFjd0MsWUFBZjtBQUE0QixpQkFBYSxJQUFJL0IsSUFBSjtBQUF6QztBQURMLEdBSFcsQ0FBYjtBQU1BLFNBQU9iLE1BQVA7QUFDQSxFQXhMVztBQTBMVjZDLG1CQUFrQixVQUFTOUMsSUFBVCxFQUFjK0MsTUFBZCxFQUFxQkMsY0FBckIsRUFBb0MvQixLQUFwQyxFQUEwQ2dDLFVBQTFDLEVBQXFEQyxZQUFyRCxFQUFrRTlHLE9BQWxFLEVBQ2xCO0FBQ0QsTUFBSTZELFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUFDLGNBQVcvRDtBQUFaLEdBQWhCLEVBQXFDO0FBQUNpRSxTQUFNO0FBQUMsWUFBUUwsSUFBVDtBQUFjLGNBQVUrQyxNQUF4QjtBQUNuRCxzQkFBa0JDLGNBRGlDO0FBQ2xCLGFBQVMvQixLQURTO0FBQ0gsV0FBT2dDLFVBREo7QUFFbkQsZ0JBQVlDO0FBRnVDO0FBQVAsR0FBckMsQ0FBYjtBQUdGLFNBQU9qRCxNQUFQO0FBQ0MsRUFoTVk7QUFrTVZrRCxtQkFBa0IsVUFBUy9HLE9BQVQsRUFBaUJnSCxNQUFqQixFQUF3QkMsS0FBeEIsRUFBOEJDLE1BQTlCLEVBQXFDQyxLQUFyQyxFQUEyQ0MsZUFBM0MsRUFBMkRDLGNBQTNELEVBQTBFQyxhQUExRSxFQUF3RkMsWUFBeEYsRUFBcUdDLFlBQXJHLEVBQ2xCO0FBQ0QsTUFBSTNELFNBQVNsRCxRQUFRb0MsTUFBUixDQUFlO0FBQUMsY0FBVy9DLE9BQVo7QUFBb0IsYUFBVWdILE1BQTlCO0FBQXFDLFlBQVNDLEtBQTlDO0FBQ3RCLGFBQVVDLE1BRFk7QUFDTCxZQUFTQyxLQURKO0FBQ1Usc0JBQW1CQyxlQUQ3QjtBQUV0QixxQkFBa0JDLGNBRkk7QUFFVyxvQkFBaUJDLGFBRjVCO0FBRTBDLG1CQUFnQkMsWUFGMUQ7QUFFdUUsbUJBQWdCQztBQUZ2RixHQUFmLENBQWI7QUFHRixTQUFPM0QsTUFBUDtBQUNDLEVBeE1ZO0FBME1WNEQsZ0JBQWUsVUFBU0MsWUFBVCxFQUFzQkMsU0FBdEIsRUFBZ0NDLFdBQWhDLEVBQTRDQyxVQUE1QyxFQUF1REMsU0FBdkQsRUFBaUVDLFFBQWpFLEVBQTBFQyxZQUExRSxFQUF1RkMsVUFBdkYsRUFBa0dDLG9CQUFsRyxFQUF1SEMsUUFBdkgsRUFBZ0luSSxPQUFoSSxFQUNmO0FBQ0QsTUFBSTZELFNBQVNuRCxXQUFXcUMsTUFBWCxDQUFrQjtBQUMxQi9DLFlBQVNBLE9BRGlCO0FBRTFCb0ksWUFBU1YsWUFGaUI7QUFHMUJXLFVBQU9WLFNBSG1CO0FBSTFCQyxnQkFBYUEsV0FKYTtBQUsxQkMsZUFBWUEsVUFMYztBQU0xQkMsY0FBV0EsU0FOZTtBQU8xQkMsYUFBVUEsUUFQZ0I7QUFRMUJ2RCxhQUFVd0QsWUFSZ0I7QUFTMUJNLFVBQU9MLFVBVG1CO0FBVTFCQyx5QkFBc0JBLG9CQVZJO0FBVzFCQyxhQUFVQSxRQVhnQjtBQVkxQjFELGNBQVcsSUFBSUMsSUFBSjtBQVplLEdBQWxCLENBQWI7QUFjRixTQUFPYixNQUFQO0FBQ0MsRUEzTlk7QUE2TlowRSxhQUFZLFVBQVN4SSxNQUFULEVBQWdCeUksUUFBaEIsRUFBMEJDLFdBQTFCLEVBQXNDQyxTQUF0QyxFQUFnREMsUUFBaEQsRUFBeURDLFlBQXpELEVBQ1Y7QUFDRCxNQUFJL0UsU0FBU2pELFVBQVVtQyxNQUFWLENBQWlCO0FBQ3pCL0MsWUFBU0QsTUFEZ0I7QUFFekI4SSxTQUFNTCxRQUZtQjtBQUd6QkMsZ0JBQWFBLFdBSFk7QUFJekJDLGNBQVdBLFNBSmM7QUFLekJDLGFBQVVBLFFBTGU7QUFNekJuRSxhQUFVb0UsWUFOZTtBQU96Qm5FLGNBQVcsSUFBSUMsSUFBSjtBQVBjLEdBQWpCLENBQWI7QUFTRixTQUFPYixNQUFQO0FBQ0MsRUF6T1k7QUEyT1ppRixhQUFZLFVBQVMvSSxNQUFULEVBQWdCZ0osT0FBaEIsRUFBd0JQLFFBQXhCLEVBQWtDQyxXQUFsQyxFQUE4Q0MsU0FBOUMsRUFBd0RDLFFBQXhELEVBQWlFQyxZQUFqRSxFQUNWO0FBQ0gsTUFBSS9FLFNBQVNqRCxVQUFVbUQsTUFBVixDQUFpQjtBQUMzQkMsUUFBSytFO0FBRHNCLEdBQWpCLEVBRVQ7QUFDRDlFLFNBQU07QUFDQSxZQUFRdUUsUUFEUjtBQUVDLG1CQUFlQyxXQUZoQjtBQUdDLGlCQUFhQyxTQUhkO0FBSUMsZ0JBQVlDLFFBSmI7QUFLQyxnQkFBWUMsWUFMYjtBQU1DLGlCQUFhLElBQUlsRSxJQUFKO0FBTmQ7QUFETCxHQUZTLENBQWI7QUFZQSxTQUFPYixNQUFQO0FBQ0MsRUExUFk7QUE0UFhtRixlQUFjLFVBQVNqSixNQUFULEVBQWdCa0osVUFBaEIsRUFBMkJDLFNBQTNCLEVBQXFDQyxVQUFyQyxFQUNiO0FBQ0gsTUFBSXRGLFNBQVNwRCxVQUFVc0MsTUFBVixDQUFpQjtBQUN2Qi9DLFlBQVNELE1BRGM7QUFFdkJrSixlQUFZQSxVQUZXO0FBR3ZCQyxjQUFXQSxTQUhZO0FBSXZCQyxlQUFZQSxVQUpXO0FBS3ZCMUUsY0FBVyxJQUFJQyxJQUFKO0FBTFksR0FBakIsQ0FBYjtBQU9BLFNBQU8sSUFBUDtBQUNDLEVBdFFZO0FBd1FYMEUsZUFBYyxVQUFTTCxPQUFULEVBQWlCRSxVQUFqQixFQUE0QkMsU0FBNUIsRUFBc0NDLFVBQXRDLEVBQ2I7QUFDSCxNQUFJdEYsU0FBU3BELFVBQVVzRCxNQUFWLENBQWlCO0FBQzNCQyxRQUFLK0U7QUFEc0IsR0FBakIsRUFFVDtBQUNEOUUsU0FBTTtBQUNEZ0YsZ0JBQVlBLFVBRFg7QUFFREMsZUFBV0EsU0FGVjtBQUdEQyxnQkFBWUEsVUFIWDtBQUlEMUUsZUFBVyxJQUFJQyxJQUFKO0FBSlY7QUFETCxHQUZTLENBQWI7QUFVQSxTQUFPLElBQVA7QUFDQyxFQXJSWTtBQXNSYjJFLGdCQUFlLFVBQVNOLE9BQVQsRUFBaUJyQixZQUFqQixFQUE4QkMsU0FBOUIsRUFBd0NDLFdBQXhDLEVBQW9EQyxVQUFwRCxFQUErREMsU0FBL0QsRUFBeUVDLFFBQXpFLEVBQWtGQyxZQUFsRixFQUNQQyxVQURPLEVBQ0lDLG9CQURKLEVBQ3lCQyxRQUR6QixFQUVaO0FBQ0gsTUFBSXRFLFNBQVNuRCxXQUFXcUQsTUFBWCxDQUFrQjtBQUNyQkMsUUFBSytFO0FBRGdCLEdBQWxCLEVBR0g7QUFDSjlFLFNBQU07QUFDTG1FLGFBQVNWLFlBREo7QUFFTFcsV0FBT1YsU0FGRjtBQUdMQyxpQkFBYUEsV0FIUjtBQUlMQyxnQkFBWUEsVUFKUDtBQU1MQyxlQUFXQSxTQU5OO0FBT0xDLGNBQVVBLFFBUEw7QUFRTHZELGNBQVV3RCxZQVJMO0FBU0xNLFdBQU9MLFVBVEY7QUFVTEUsY0FBVUEsUUFWTDtBQVdMRCwwQkFBc0JBLG9CQVhqQjtBQVlMM0IsZUFBVyxJQUFJN0IsSUFBSjtBQVpOO0FBREYsR0FIRyxDQUFiO0FBa0JBLFNBQU8sSUFBUDtBQUNDLEVBNVNZO0FBOFNiNEUsa0JBQWlCLFVBQVNQLE9BQVQsRUFBaUJyQixZQUFqQixFQUE4QkMsU0FBOUIsRUFBd0NDLFdBQXhDLEVBQW9ERSxTQUFwRCxFQUE4REUsWUFBOUQsRUFDVEMsVUFEUyxFQUNFQyxvQkFERixFQUN1QkMsUUFEdkIsRUFFZDtBQUNILE1BQUl0RSxTQUFTbkQsV0FBV3FELE1BQVgsQ0FBa0I7QUFDckJDLFFBQUsrRTtBQURnQixHQUFsQixFQUdIO0FBQ0o5RSxTQUFNO0FBQ0xtRSxhQUFTVixZQURKO0FBRUxXLFdBQU9WLFNBRkY7QUFHTEMsaUJBQWFBLFdBSFI7QUFJTEMsZ0JBQVlBLFVBSlA7QUFNTHJELGNBQVV3RCxZQU5MO0FBT0xNLFdBQU9MLFVBUEY7QUFRTEUsY0FBVUEsUUFSTDtBQVNMRCwwQkFBc0JBLG9CQVRqQjtBQVVMM0IsZUFBVyxJQUFJN0IsSUFBSjtBQVZOO0FBREYsR0FIRyxDQUFiO0FBZ0JBLFNBQU8sSUFBUDtBQUNDLEVBbFVZO0FBcVViNkUsbUJBQWtCLFVBQVNSLE9BQVQsRUFBaUIvQixNQUFqQixFQUF3QkMsS0FBeEIsRUFBOEJDLE1BQTlCLEVBQXFDQyxLQUFyQyxFQUEyQ0MsZUFBM0MsRUFBMkRDLGNBQTNELEVBQTBFQyxhQUExRSxFQUF3RkMsWUFBeEYsRUFBcUdDLFlBQXJHLEVBQ2Y7QUFFSCxNQUFJM0QsU0FBU2xELFFBQVFvRCxNQUFSLENBQWU7QUFDbEJDLFFBQUsrRTtBQURhLEdBQWYsRUFJSDtBQUNKOUUsU0FBTTtBQUFDLGNBQVUrQyxNQUFYO0FBQWtCLGFBQVNDLEtBQTNCO0FBQ0osY0FBVUMsTUFETjtBQUNhLGFBQVNDLEtBRHRCO0FBQzRCLHVCQUFtQkMsZUFEL0M7QUFFSixzQkFBa0JDLGNBRmQ7QUFFNkIscUJBQWlCQyxhQUY5QztBQUU0RCxvQkFBZ0JDLFlBRjVFO0FBRXlGLG9CQUFnQkM7QUFGekc7QUFERixHQUpHLENBQWI7QUFTQSxTQUFPLElBQVA7QUFDQyxFQWxWWTtBQW1WUGdDLHFCQUFvQixVQUFTeEosT0FBVCxFQUFpQnlKLFNBQWpCLEVBQ3ZCO0FBQ0gsTUFBSTVGLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQi9ELFlBQVNBO0FBRGlCLEdBQWhCLEVBRVQ7QUFDRGlFLFNBQU07QUFDQSxtQkFBZXdGLFNBRGY7QUFFQyxvQkFBZ0IsSUFBSS9FLElBQUo7QUFGakI7QUFETCxHQUZTLENBQWI7QUFRQSxTQUFPYixNQUFQO0FBQ0MsRUE5Vlk7QUFnV2I2Rix1QkFBc0IsVUFBUzFKLE9BQVQsRUFBaUJ5SixTQUFqQixFQUNuQjtBQUNILE1BQUk1RixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUIvRCxZQUFTQTtBQURpQixHQUFoQixFQUVUO0FBQ0RpRSxTQUFNO0FBQ0EsbUJBQWV3RixTQURmO0FBRUMsb0JBQWdCLElBQUkvRSxJQUFKO0FBRmpCO0FBREwsR0FGUyxDQUFiO0FBUUEsU0FBT2IsTUFBUDtBQUNDLEVBM1dZO0FBNldQOEYsaUJBQWdCLFVBQVN6RCxPQUFULEVBQWlCRCxPQUFqQixFQUF5QjJELFFBQXpCLEVBQWtDQyxNQUFsQyxFQUF5Q0MsV0FBekMsRUFBcURDLFVBQXJELEVBQ25CO0FBQ0gsTUFBSWxHLFNBQVM5QyxRQUFRZ0MsTUFBUixDQUFlO0FBQzNCOEcsV0FBUUEsTUFEbUI7QUFFckIzRCxZQUFTQSxPQUZZO0FBR3JCRCxZQUFTQSxPQUhZO0FBSXJCNkQsZ0JBQVlBLFdBSlM7QUFLckJGLGFBQVVBLFFBTFc7QUFNckJJLGlCQUFjRCxVQU5PO0FBT3JCRSxXQUFRLElBQUl2RixJQUFKO0FBUGEsR0FBZixDQUFiO0FBU0EsU0FBTyxJQUFQO0FBQ0MsRUF6WFk7QUE0WFB3RiwwQkFBeUIsVUFBU2hFLE9BQVQsRUFBaUJELE9BQWpCLEVBQXlCOEQsVUFBekIsRUFBb0NGLE1BQXBDLEVBQzVCO0FBQ0gsTUFBSWhHLFNBQVM5QyxRQUFRZ0MsTUFBUixDQUFlO0FBQzNCOEcsV0FBUUEsTUFEbUI7QUFFckIzRCxZQUFTQSxPQUZZO0FBR3JCRCxZQUFTQSxPQUhZO0FBSXJCMkQsYUFBVSxDQUpXO0FBS3JCSSxpQkFBY0QsVUFMTztBQU1yQkUsV0FBUSxJQUFJdkYsSUFBSjtBQU5hLEdBQWYsQ0FBYjtBQVFBLFNBQU8sSUFBUDtBQUNDLEVBdllZO0FBeVlieUYsaUNBQWdDLFVBQVNOLE1BQVQsRUFBZ0I1RCxPQUFoQixFQUF3QkMsT0FBeEIsRUFBZ0NrRSxXQUFoQyxFQUE0Q0MsV0FBNUMsRUFBd0RDLE1BQXhELEVBQzdCO0FBQ0gsTUFBSXpHLFNBQVM5QyxRQUFRZ0MsTUFBUixDQUFlO0FBQzNCOEcsV0FBUUEsTUFEbUI7QUFFckIzRCxZQUFTQSxPQUZZO0FBR3JCRCxZQUFTQSxPQUhZO0FBSXJCMkQsYUFBVSxDQUpXO0FBS3JCSSxpQkFBYyxDQUxPO0FBTXJCTyxvQkFBaUJILFdBTkk7QUFPckJJLG9CQUFpQkgsV0FQSTtBQVFyQkMsV0FBUUEsTUFSYTtBQVNyQkwsV0FBUSxJQUFJdkYsSUFBSjtBQVRhLEdBQWYsQ0FBYjtBQVdBLFNBQU8sSUFBUDtBQUNDLEVBdlpZO0FBeVpiK0YsdUJBQXNCLFVBQVN6SyxPQUFULEVBQWlCMEssU0FBakIsRUFBMkJDLFNBQTNCLEVBQXFDQyxRQUFyQyxFQUE4Q0MsZUFBOUMsRUFBOERDLGNBQTlELEVBQTZFeEssTUFBN0UsRUFDbkI7QUFDSCxNQUFJdUQsU0FBUzdDLFVBQVUrQixNQUFWLENBQWlCO0FBQzdCekMsV0FBUUEsTUFEcUI7QUFFN0JxSyxjQUFXQSxTQUZrQjtBQUc3QkksVUFBTy9LLE9BSHNCO0FBSXZCNEssYUFBVUEsUUFKYTtBQUt2QkMsb0JBQWlCQSxlQUxNO0FBTXZCQyxtQkFBZ0JBLGNBTk87QUFPdkJKLGNBQVdBLFNBUFk7QUFRdkJNLG9CQUFpQixDQVJNO0FBU3ZCdkcsY0FBVyxJQUFJQyxJQUFKO0FBVFksR0FBakIsQ0FBYjtBQVdBLFNBQU8sSUFBUDtBQUNDLEVBdmFZO0FBeWFidUcsdUJBQXNCLFVBQVNqTCxPQUFULEVBQWlCMEssU0FBakIsRUFBMkJDLFNBQTNCLEVBQXFDQyxRQUFyQyxFQUE4Q0MsZUFBOUMsRUFDckJDLGNBRHFCLEVBQ054SyxNQURNLEVBQ0MwSyxlQURELEVBRW5CO0FBQ0gsTUFBSW5ILFNBQVM3QyxVQUFVK0MsTUFBVixDQUFpQjtBQUMzQnpELFdBQVFBO0FBRG1CLEdBQWpCLEVBRVQ7QUFDRDJELFNBQU07QUFDSTBHLGVBQVdBLFNBRGY7QUFFTEksV0FBTy9LLE9BRkY7QUFHQzRLLGNBQVVBLFFBSFg7QUFJQ0MscUJBQWlCQSxlQUpsQjtBQUtDQyxvQkFBZ0JBLGNBTGpCO0FBTUNKLGVBQVdBLFNBTlo7QUFPQ00scUJBQWlCQSxlQVBsQjtBQVFDRSxlQUFXLElBQUl4RyxJQUFKO0FBUlo7QUFETCxHQUZTLENBQWI7QUFjQSxTQUFPLElBQVA7QUFDQyxFQTNiWTtBQTZiVHlHLFlBQVcsVUFBVXBMLE1BQVYsRUFBa0IrRixLQUFsQixFQUF5QjtBQUM5QnpELFFBQU0rSSxJQUFOLENBQVd0RixLQUFYO0FBQ0gsRUEvYk07QUFpY1B1Rix3QkFBdUIsVUFBUy9LLE1BQVQsRUFBZ0IwSyxlQUFoQixFQUMxQjtBQUNILE1BQUluSCxTQUFTN0MsVUFBVStDLE1BQVYsQ0FBaUI7QUFDM0J6RCxXQUFRQTtBQURtQixHQUFqQixFQUVUO0FBQ0QyRCxTQUFNO0FBQ0EsdUJBQW1CK0csZUFEbkI7QUFFQyxvQkFBZ0IsSUFBSXRHLElBQUo7QUFGakI7QUFETCxHQUZTLENBQWI7QUFRQSxTQUFPYixNQUFQO0FBQ0MsRUE1Y1k7QUE2Y2J5SCxzQkFBb0IsVUFBU3ZMLE1BQVQsRUFBZ0JnRyxZQUFoQixFQUE2QjtBQUN6QyxNQUFJMUIsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDSixNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxxQkFBZ0I7QUFBakI7QUFETCxJQUZTLENBQWI7QUFLRTs7QUFDQSxTQUFPSixNQUFQO0FBQ0UsRUF2ZE07QUF3ZGIwSCxvQkFBa0IsVUFBU3hMLE1BQVQsRUFBZ0J5TCxXQUFoQixFQUE0QjtBQUN0QyxNQUFJbkgsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDSixNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxvQkFBZXVIO0FBQWhCO0FBREwsSUFGUyxDQUFiO0FBS0U7O0FBQ0EsU0FBTzNILE1BQVA7QUFDRSxFQWxlTTtBQW1lYjRILDBCQUF3QixVQUFTMUwsTUFBVCxFQUFnQnlMLFdBQWhCLEVBQTRCO0FBQzVDLE1BQUluSCxVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNKLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLG9CQUFldUg7QUFBaEI7QUFETCxJQUZTLENBQWI7QUFLRTs7QUFDQSxTQUFPM0gsTUFBUDtBQUNFLEVBN2VNO0FBK2ViNkgsc0JBQW9CLFVBQVNsRyxZQUFULEVBQXNCekYsTUFBdEIsRUFBNkI7QUFDekMsTUFBSXNFLFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsY0FBVXZFO0FBQVgsR0FBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0osTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQUMscUJBQWdCdUI7QUFBakI7QUFETCxJQUZTLENBQWI7QUFLRTs7QUFDQSxTQUFPM0IsTUFBUDtBQUNFLEVBemZNO0FBMmZiOEgsaUJBQWUsVUFBUzVMLE1BQVQsRUFBZ0I2TCxPQUFoQixFQUF3QjtBQUMvQixNQUFJdkgsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDSixNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxnQkFBVzJIO0FBQVo7QUFETCxJQUZTLENBQWI7QUFLRTs7QUFDQSxTQUFPL0gsTUFBUDtBQUNFLEVBcmdCTTtBQXVnQlBnSSxlQUFhLFVBQVNDLFFBQVQsRUFBa0I7QUFDMUIsTUFBSWpJLFNBQVNwRCxVQUFVb0MsTUFBVixDQUFpQjtBQUFDbUIsUUFBSzhIO0FBQU4sR0FBakIsQ0FBYjtBQUNOLFNBQU9qSSxNQUFQO0FBQ0UsRUExZ0JNO0FBMmdCUGtJLGVBQWEsVUFBU0MsTUFBVCxFQUFnQjtBQUN4QixNQUFJbkksU0FBU2pELFVBQVVpQyxNQUFWLENBQWlCO0FBQUNtQixRQUFLZ0k7QUFBTixHQUFqQixDQUFiO0FBQ04sU0FBT25JLE1BQVA7QUFDRSxFQTlnQk07QUErZ0JQb0ksZ0JBQWMsVUFBU0MsU0FBVCxFQUFtQjtBQUM1QixNQUFJckksU0FBU25ELFdBQVdtQyxNQUFYLENBQWtCO0FBQUNtQixRQUFLa0k7QUFBTixHQUFsQixDQUFiO0FBQ04sU0FBT3JJLE1BQVA7QUFDRSxFQWxoQk07QUFtaEJQc0ksbUJBQWlCLFVBQVNDLE1BQVQsRUFBZ0I7QUFDNUIsTUFBSXZJLFNBQVNsRCxRQUFRa0MsTUFBUixDQUFlO0FBQUNtQixRQUFLb0k7QUFBTixHQUFmLENBQWI7QUFDTixTQUFPdkksTUFBUDtBQUNFLEVBdGhCTTtBQXdoQlB3SSx1QkFBcUIsVUFBU25HLE9BQVQsRUFBaUI1RixNQUFqQixFQUF3QjtBQUN4QyxNQUFJdUQsU0FBUzVDLGFBQWE0QixNQUFiLENBQW9CO0FBQUNxRCxZQUFTQSxPQUFWO0FBQW1CNUYsV0FBUUE7QUFBM0IsR0FBcEIsQ0FBYjtBQUNOLFNBQU91RCxNQUFQO0FBQ0UsRUEzaEJNO0FBNmhCUHlJLHVCQUFxQixVQUFTbEcsTUFBVCxFQUFnQkYsT0FBaEIsRUFBd0I1RixNQUF4QixFQUErQmlNLE1BQS9CLEVBQXNDO0FBQ3pELE1BQUkxSSxTQUFTNUMsYUFBYThCLE1BQWIsQ0FBb0I7QUFDL0JxRCxXQUFRQSxNQUR1QjtBQUUvQkYsWUFBU0EsT0FGc0I7QUFHL0I1RixXQUFRQSxNQUh1QjtBQUkvQmlNLFdBQVFBLE1BSnVCO0FBSy9CdEMsV0FBUSxJQUFJdkYsSUFBSjtBQUx1QixHQUFwQixDQUFiO0FBT0gsU0FBT2IsTUFBUDtBQUNFLEVBdGlCTTtBQXdpQlAySSxrQkFBZ0IsVUFBUzFDLFdBQVQsRUFBcUIyQyxLQUFyQixFQUEyQkMsS0FBM0IsRUFBaUNDLFFBQWpDLEVBQTBDQyxXQUExQyxFQUFzREMsZ0JBQXRELEVBQXVFQyxjQUF2RSxFQUN4QkMsZ0JBRHdCLEVBQ1A7QUFDUCxNQUFJMUksVUFBVW5ELFNBQVNvRCxJQUFULENBQWM7QUFBQ3dGLGdCQUFhQTtBQUFkLEdBQWQsRUFBMEN2RixLQUExQyxFQUFkO0FBQ0osTUFBSXlJLGlCQUFpQmpNLFFBQVF1RCxJQUFSLENBQWE7QUFBQyxrQkFBY3dGO0FBQWYsR0FBYixFQUEwQ21ELEtBQTFDLEVBQXJCOztBQUNBLE1BQUc1SSxRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBUzNDLFNBQVM2QyxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFDRitJLHFCQUFlQSxpQkFBZSxDQUQ1QjtBQUVRTCxlQUFVQSxRQUZsQjtBQUdRQyxrQkFBWUEsV0FIcEI7QUFJUU0sb0JBQWV4SSxLQUFLeUksR0FBTCxFQUp2QjtBQUtFTix1QkFBa0JBLGdCQUxwQjtBQU1FQyxxQkFBZ0JBLGNBTmxCO0FBT0VDLHVCQUFrQkE7QUFQcEI7QUFETCxJQUZTLENBQWI7QUFjRSxHQWZELE1BZ0JJO0FBQ0gsT0FBSWxKLFNBQVMzQyxTQUFTNkIsTUFBVCxDQUFnQjtBQUNwQitHLGlCQUFhQSxXQURPO0FBRXBCMkMsV0FBY0EsS0FGTTtBQUdwQkMsV0FBY0EsS0FITTtBQUlwQkUsaUJBQWFBLFdBSk87QUFLcEJELGNBQVVBLFFBTFU7QUFNcEJPLG1CQUFleEksS0FBS3lJLEdBQUwsRUFOSztBQU9wQk4sc0JBQWtCQSxnQkFQRTtBQVFwQkMsb0JBQWdCQSxjQVJJO0FBU3BCQyxzQkFBa0JBO0FBVEUsSUFBaEIsQ0FBYjtBQVdBOztBQUNBLFNBQU9sSixNQUFQO0FBQ0UsRUExa0JNO0FBNmtCUHVKLDBCQUF3QixVQUFTdEQsV0FBVCxFQUFxQmlELGdCQUFyQixFQUFzQztBQUM1RCxNQUFJMUksVUFBVW5ELFNBQVNvRCxJQUFULENBQWM7QUFBQ3dGLGdCQUFhQTtBQUFkLEdBQWQsRUFBMEN2RixLQUExQyxFQUFkOztBQUNKLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTM0MsU0FBUzZDLE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUNZOEksdUJBQWtCQTtBQUQ5QjtBQURMLElBRlMsQ0FBYjtBQU9FOztBQUNBLFNBQU9sSixNQUFQO0FBQ0UsRUF6bEJNO0FBMGxCUHdKLDRCQUEwQixVQUFTdE4sTUFBVCxFQUFnQndNLE1BQWhCLEVBQXVCO0FBQ2hELE1BQUlsSSxVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNGLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLHNCQUFpQnNJO0FBQWxCO0FBREwsSUFGUyxDQUFiO0FBS0U7O0FBQ0QsU0FBTzFJLE1BQVA7QUFDRSxFQXBtQk07QUFxbUJQeUosd0JBQXNCLFVBQVN4RCxXQUFULEVBQXFCbUQsS0FBckIsRUFBMkI7QUFDaEQsTUFBSTVJLFVBQVVuRCxTQUFTb0QsSUFBVCxDQUFjO0FBQUN3RixnQkFBYUE7QUFBZCxHQUFkLEVBQTBDdkYsS0FBMUMsRUFBZDtBQUNDLE1BQUlnSixlQUFhLENBQWpCOztBQUNELE1BQUdsSixRQUFRLENBQVIsRUFBV21KLGdCQUFkLEVBQStCO0FBQ3BDRCxrQkFBZ0JsSixRQUFRLENBQVIsRUFBV21KLGdCQUFYLEdBQTRCLENBQTVDO0FBQ00sR0FGRCxNQUVLO0FBQ1ZELGtCQUFlLENBQWY7QUFDTTs7QUFDRCxNQUFHTixTQUFTLENBQVosRUFBYztBQUNwQk0sa0JBQWUsQ0FBZjtBQUNPOztBQUNKLE1BQUdsSixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBUzNDLFNBQVM2QyxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFDRmlKLG9CQUFleEksS0FBS3lJLEdBQUwsRUFEYjtBQUVZSyx1QkFBa0JEO0FBRjlCO0FBREwsSUFGUyxDQUFiO0FBUUU7O0FBQ0QsU0FBTzFKLE1BQVA7QUFDRyxFQTNuQk07QUE0bkJQNEoseUJBQXVCLFVBQVNDLFVBQVQsRUFBb0JuQixNQUFwQixFQUEyQjtBQUVqRCxNQUFJbEksVUFBVXRELFFBQVF1RCxJQUFSLENBQWE7QUFBQyxhQUFTb0o7QUFBVixHQUFiLEVBQW9DbkosS0FBcEMsRUFBZDs7QUFDQSxNQUFHZ0ksVUFBVSxNQUFiLEVBQW9CO0FBQ3pCLE9BQUlsSSxVQUFVdEQsUUFBUXVELElBQVIsQ0FBYTtBQUFDLG1CQUFjRCxRQUFRLENBQVIsRUFBV3lGO0FBQTFCLElBQWIsRUFBcUR2RixLQUFyRCxFQUFkOztBQUNBLFFBQUksSUFBSW9KLElBQUUsQ0FBVixFQUFZQSxJQUFFdEosUUFBUXVKLE1BQXRCLEVBQTZCRCxHQUE3QixFQUFpQztBQUNqQyxRQUFJOUosU0FBUzlDLFFBQVFnRCxNQUFSLENBQWU7QUFDM0JDLFVBQUtLLFFBQVFzSixDQUFSLEVBQVczSjtBQURXLEtBQWYsRUFFUjtBQUNKQyxXQUFNO0FBQUMseUJBQW1CO0FBQXBCO0FBREYsS0FGUSxDQUFiO0FBS0M7QUFHSyxHQVhELE1BV0s7QUFDTCxPQUFHSSxRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ3BCLFFBQUlSLFNBQVM5QyxRQUFRZ0QsTUFBUixDQUFlO0FBQzFCQyxVQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxLQUFmLEVBRVQ7QUFDRkMsV0FBTTtBQUFDLHlCQUFtQnNJO0FBQXBCO0FBREosS0FGUyxDQUFiO0FBS0M7QUFDTTs7QUFFSCxTQUFPMUksTUFBUDtBQUNFO0FBcnBCTSxDQUFmLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5pbXBvcnQgeyBCYXNlNjQgfSBmcm9tICdtZXRlb3Ivb3N0cmlvOmJhc2U2NCc7XG5pbXBvcnQgeyBTZXNzaW9uIH0gZnJvbSAnbWV0ZW9yL3Nlc3Npb24nO1xuXG5Sb3V0ZXIucm91dGUoJy9wcm9maWxlJywgZnVuY3Rpb24gKCkge1xuICBpZihTZXNzaW9uLmdldChcInVzZXJJZFwiKSE9XCJcIil7XG4gIHRoaXMucmVuZGVyKCdwcm9maWxlJyk7ICBcbn1lbHNle1xuICBSb3V0ZXIuZ28oJy8nKTsgIFxufVxufSk7XG5cblJvdXRlci5yb3V0ZSgnL3ZpZXdfcHJvZmlsZS86dXNlcl9pZCcsIGZ1bmN0aW9uICgpIHtcbiAgIHZhciAgcGFyYW1zID0gdGhpcy5wYXJhbXM7IC8vIHsgX2lkOiBcIjVcIiB9XG4gIC8vIHZhciBpZCA9IHBhcmFtcy51c2VyX2lkOyAvLyBcIjVcIlxuXG4gICAgdmFyIHVzZXJJZCA9IHBhcmFtcy51c2VyX2lkOyAvLyBcIjVcIlxuICAgIHVzZXJJZCA9IEJhc2U2NC5kZWNvZGUodXNlcklkKTsgXG4gICAgICAvLyBhbGVydChcImRlY3J5cHRcIiArIHVzZXJJZCk7XG4gIC8vIFNlc3Npb24uc2V0KFwibWFrZVVzZXJBY3RpdmVcIixcInRydWVcIik7XG4gIC8vIFNlc3Npb24uc2V0UGVyc2lzdGVudChcInNob3dfY29ubmVjdGlvblwiLGhlYWRbMF0udXNlcl9pZCk7XG4gIFNlc3Npb24uc2V0KFwic2hvd19jb25uZWN0aW9uXCIsdXNlcklkKTtcdFxuICAvLyBhbGVydCgnaGknKTtcbiAgdGhpcy5yZW5kZXIoJ3ZpZXdfcHJvZmlsZScpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnLycsIGZ1bmN0aW9uICgpIHtcbiAgdGhpcy5yZW5kZXIoJ2xvZ2luJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvc2lnbnVwJywgZnVuY3Rpb24gKCkge1xuICAgaWYoU2Vzc2lvbi5nZXQoXCJ1c2VySWRcIikhPVwiXCIpe1xuIHRoaXMucmVuZGVyKCdzaWdudXAnKTtcbn1lbHNle1xuICBSb3V0ZXIuZ28oJy8nKTsgIFxufVxuXG5cbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9jb25uZWN0aW9uJywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignY29ubmVjdGlvbicpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL01lc3NhZ2luZycsIGZ1bmN0aW9uICgpIHtcbiAgdGhpcy5yZW5kZXIoJ21lc3NhZ2luZ3BhZ2UnKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9ncnBsaXN0aW5nJywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignZ3JwbGlzdGluZycpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL2dyb3VwX2Rpc2N1c3Npb24nLCBmdW5jdGlvbiAoKSB7XG4gIHRoaXMucmVuZGVyKCdncm91cF9kaXNjdXNzaW9uJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvZW1haWwnLCBmdW5jdGlvbiAoKSBcbnsgIGlmKFNlc3Npb24uZ2V0KFwidXNlcklkXCIpIT1cIlwiKXtcbiAgdGhpcy5yZW5kZXIoJ2VtYWlsJyk7XG59ZWxzZXtcbiAgUm91dGVyLmdvKCcvJyk7ICBcbn1cblxufSk7XG5cblJvdXRlci5yb3V0ZSgnL2FjdGl2YXRlX2VtYWlsLzppZCcsIGZ1bmN0aW9uICgpIHtcbiAgdmFyICBwYXJhbXMgPSB0aGlzLnBhcmFtczsgLy8geyBfaWQ6IFwiNVwiIH1cbiAgdmFyIHVzZXJJZCA9IHBhcmFtcy5pZDsgLy8gXCI1XCJcbiAgICB1c2VySWQgPSBCYXNlNjQuZGVjb2RlKHVzZXJJZCk7IFxuICAgICAgLy8gYWxlcnQoXCJkZWNyeXB0XCIgKyB1c2VySWQpO1xuICBTZXNzaW9uLnNldChcIm1ha2VVc2VyQWN0aXZlXCIsXCJ0cnVlXCIpO1xuICBTZXNzaW9uLnNldFBlcnNpc3RlbnQoXCJ1c2VySWRcIix1c2VySWQpO1xuICB0aGlzLnJlbmRlcignZW1haWwnKTtcblxuXG59KTtcblxuXG5cblJvdXRlci5yb3V0ZSgnL2NyZWF0ZWdyb3VwJywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignY3JlYXRlZ3JvdXAnKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9tZXNzYWdpbmdfcGFnZScsIGZ1bmN0aW9uICgpIHtcbiAgdGhpcy5yZW5kZXIoJ21lc3NhZ2luZ19wYWdlJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvZ3JvdXBkZXRhaWwvOmdycF9pZCcsIGZ1bmN0aW9uICgpIHtcbiAgdmFyICBwYXJhbXMgPSB0aGlzLnBhcmFtczsgLy8geyBfaWQ6IFwiNVwiIH1cbiAgdmFyIGVuY3J5cHRlZCA9IHBhcmFtcy5ncnBfaWQ7IC8vIFwiNVwiXG4gIFxuLy8gZGVjcnlwdGVkID0gQ3J5cHRvSlMuQUVTLmRlY3J5cHQoZW5jcnlwdGVkLCAnUGFzc3BocmFzZScpO1xuLy8gdmFyIGlkID0gZGVjcnlwdGVkLnRvU3RyaW5nKENyeXB0b0pTLmVuYy5VdGY4KTtcblxuU2Vzc2lvbi5zZXQoXCJzaG93X2dycF9pZFwiLGVuY3J5cHRlZCk7ICBcbiB0aGlzLnJlbmRlcignZ3JvdXBkZXRhaWwnKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9lZGl0Z3JvdXAvOmdycF9pZCcsIGZ1bmN0aW9uICgpIHtcbiAgdmFyICBwYXJhbXMgPSB0aGlzLnBhcmFtczsgLy8geyBfaWQ6IFwiNVwiIH1cbiAgdmFyIGVuY3J5cHRlZCA9IHBhcmFtcy5ncnBfaWQ7IC8vIFwiNVwiXG4gIFxuLy8gZGVjcnlwdGVkID0gQ3J5cHRvSlMuQUVTLmRlY3J5cHQoZW5jcnlwdGVkLCAnUGFzc3BocmFzZScpO1xuLy8gdmFyIGlkID0gZGVjcnlwdGVkLnRvU3RyaW5nKENyeXB0b0pTLmVuYy5VdGY4KTtcblxuU2Vzc2lvbi5zZXQoXCJzaG93X2dycF9lZGl0X2lkXCIsZW5jcnlwdGVkKTsgIFxuICB0aGlzLnJlbmRlcignZWRpdGdyb3VwJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvbG9nb3V0JywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignbG9naW4nKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9tZXNzYWdpbmdfbGVmdCcsIGZ1bmN0aW9uICgpIHtcbiAgdGhpcy5yZW5kZXIoJ21lc3NhZ2luZ19sZWZ0Jyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvbWVzc2FnaW5nX3JpZ2h0JywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignbWVzc2FnaW5nX3JpZ2h0Jyk7XG59KTtcblxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuIFxuZXhwb3J0IGNvbnN0IFVzZXJJbmZvID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJfaW5mbycpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBVc2VyU2tpbGwgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcl9za2lsbCcpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5leHBvcnQgY29uc3QgVXNlclByb2ZKciA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1c2VyX3Byb2ZqcicpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5leHBvcnQgY29uc3QgVXNlckVkdSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1c2VyX2VkdScpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IFVzZXJBd2FyZCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1c2VyX2F3YXJkJyk7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5leHBvcnQgY29uc3QgVXNlck1lZGljYWwgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcl9tZWRpY2FsJyk7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IEZyaWVuZFJlcXVlc3QgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZnJpZW5kJyk7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IE1lc3NhZ2UgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWVzc2FnZScpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBVc2VyR3JvdXAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcl9ncm91cCcpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IEdyb3VwUmVxdWVzdCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cF9yZXF1ZXN0Jyk7ICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBDaGF0cm9vbSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjaGF0cm9vbScpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5cblxuIiwiaW1wb3J0IHsgRmlsZXNDb2xsZWN0aW9uIH0gZnJvbSAnbWV0ZW9yL29zdHJpbzpmaWxlcyc7XG5cbmV4cG9ydCBjb25zdCBJbWFnZXMgPSBuZXcgRmlsZXNDb2xsZWN0aW9uKHtcbiAgZGVidWc6IHRydWUsXG4gIGNvbGxlY3Rpb25OYW1lOiAnSW1hZ2VzJyxcbiAgYWxsb3dDbGllbnRDb2RlOiBmYWxzZSwgLy8gRGlzYWxsb3cgcmVtb3ZlIGZpbGVzIGZyb20gQ2xpZW50XG4gXHRzdG9yYWdlUGF0aDogKCkgPT4ge1xuICAgICAgICByZXR1cm4gYCR7cHJvY2Vzcy5lbnYuUFdEfS91cGxvYWRzYDtcbiAgfSwgICBvbkJlZm9yZVVwbG9hZDogZnVuY3Rpb24gKGZpbGUpIHtcbiAgICAvLyBBbGxvdyB1cGxvYWQgZmlsZXMgdW5kZXIgMTBNQiwgYW5kIG9ubHkgaW4gcG5nL2pwZy9qcGVnIGZvcm1hdHNcbiAgICBpZiAoZmlsZS5zaXplIDw9IDEwMjQgKiAxMDI0ICogMTAgJiYgL3BuZ3xqcGU/Zy9pLnRlc3QoZmlsZS5leHRlbnNpb24pKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuICdQbGVhc2UgdXBsb2FkIGltYWdlLCB3aXRoIHNpemUgZXF1YWwgb3IgbGVzcyB0aGFuIDEwTUInO1xuICB9XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSW1hZ2VzO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBVc2VySW5mbyB9ICBmcm9tICcuLy4uL2ltcG9ydC9jb2xsZWN0aW9ucy9pbnNlcnQuanMnO1xuaW1wb3J0IHsgVXNlclNraWxsIH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcblxuaW1wb3J0IHsgVXNlclByb2ZKciB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5pbXBvcnQgeyBVc2VyRWR1IH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcblxuaW1wb3J0IHsgVXNlckF3YXJkIH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcbmltcG9ydCB7IFVzZXJNZWRpY2FsIH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcbmltcG9ydCB7IEZyaWVuZFJlcXVlc3QgfSBmcm9tICcuLy4uL2ltcG9ydC9jb2xsZWN0aW9ucy9pbnNlcnQuanMnO1xuXG5pbXBvcnQgeyBNZXNzYWdlIH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcbmltcG9ydCB7IFVzZXJHcm91cCB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5pbXBvcnQgeyBFbWFpbCB9IGZyb20gJ21ldGVvci9lbWFpbCc7XG5pbXBvcnQgeyBHcm91cFJlcXVlc3QgfSBmcm9tICcuLy4uL2ltcG9ydC9jb2xsZWN0aW9ucy9pbnNlcnQuanMnO1xuaW1wb3J0IHsgQ2hhdHJvb20gfSBmcm9tICcuLy4uL2ltcG9ydC9jb2xsZWN0aW9ucy9pbnNlcnQuanMnO1xuXG5pbXBvcnQgeyBTZXJ2aWNlQ29uZmlndXJhdGlvbiB9IGZyb20gJ21ldGVvci9zZXJ2aWNlLWNvbmZpZ3VyYXRpb24nO1xuXG5NZXRlb3Iuc3RhcnR1cChmdW5jdGlvbiAoKSB7XG4gIFVwbG9hZFNlcnZlci5pbml0KHtcbiAgICB0bXBEaXI6IHByb2Nlc3MuZW52LlBXRCArICcvLnVwbG9hZHMvdG1wJyxcbiAgICB1cGxvYWREaXI6IHByb2Nlc3MuZW52LlBXRCArICcvdXBsb2FkZWQvJ1xuICB9KVxufSk7XG5cblxuXG5cbi8vICAgIHZhciB0MSA9IFByZXNlbmNlLmNvbmZpZ3VyZSh7XG4vLyAgIHN0YXRlOiBmdW5jdGlvbigpIHtcbi8vICAgICByZXR1cm4ge1xuLy8gICAgICAgb25saW5lOiBmYWxzZVxuLy8gICAgIH1cbi8vICAgICB1c2VySWQ6IGNvb2w7XG4vLyAgIH1cbi8vIH0pO1xuXG4vLyAgICAgaWYodDEgPT0gMCl7XG4vLyAgICAgXHRhbGVydCgnaSBhbSBhY3RpdmUnKTtcbi8vICAgICBcdGNvbnNvbGUubG9nKCdhY3RpdmUnKTtcbi8vICAgICB9XG5cbi8vICAgICBlbHNlIGlmKCB0MSA9PSAxIHx8IHQxID09IDIpe1xuLy8gICAgICAgIGFsZXJ0KCdpIGFtIGluYWN0aXZlJyk7XG4vLyAgICAgICAgY29uc29sZS5sb2coJ0luLWFjdGl2ZScpO1xuLy8gICAgICAgIFNlc3Npb24uc2V0UGVyc2lzdGVudChcImxvZ2luX3N0YXR1c1wiLDApOyAgICAgICAgICAgICAgXG4vLyAgICAgfVxuXG4vLyAgICAgZWxzZXtcbi8vICAgICBcdGNvbnNvbGUubG9nKCdJbi1hY3RpdmUnKTtcbi8vICAgICB9XG5cblxuU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMucmVtb3ZlKHtcbiAgc2VydmljZTogXCJnb29nbGVcIlxufSk7XG5cblNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLmluc2VydCh7XG4gIHNlcnZpY2U6IFwiZ29vZ2xlXCIsXG4gIGNsaWVudElkOiBcIjQ0ODkzMjY0MzA5Ni1xcXQ5cHFpN2MzYWcwcmNxMXY2ZTlxMmE4cmZlNjVhcC5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbVwiLFxuICBzZWNyZXQ6IFwiMGJUWmlieHdVZHVXX05FcWY0VzBOZ21iXCIsXG59KTtcblxuLy8gZmlyc3QsIHJlbW92ZSBjb25maWd1cmF0aW9uIGVudHJ5IGluIGNhc2Ugc2VydmljZSBpcyBhbHJlYWR5IGNvbmZpZ3VyZWRcblNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLnJlbW92ZSh7XG4gIHNlcnZpY2U6IFwiZmFjZWJvb2tcIlxufSk7XG5cblNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLmluc2VydCh7XG4gIHNlcnZpY2U6IFwiZmFjZWJvb2tcIixcbiAgYXBwSWQ6IFwiNzg0NTY2ODQ4Mzk3NDg3XCIsXG4gIHNlY3JldDogXCI2Nzg3MTI2OTdlYWU4YmRjM2NmZjI1OTM4MTM2ZTJiOVwiXG59KTtcblxuU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMucmVtb3ZlKHtcbiAgc2VydmljZTogXCJsaW5rZWRpblwiXG59KTtcblxuU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMuaW5zZXJ0KHtcbiAgc2VydmljZTogXCJsaW5rZWRpblwiLFxuICBjbGllbnRJZDogXCI3OGVxaDRxazB5eDd5N1wiLFxuICBzZWNyZXQ6IFwiaXhQQW5TQmlDdEJxNldQSlwiXG59KTtcbi8vIC8vIGZpcnN0LCByZW1vdmUgY29uZmlndXJhdGlvbiBlbnRyeSBpbiBjYXNlIHNlcnZpY2UgaXMgYWxyZWFkeSBjb25maWd1cmVkXG4vLyBBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLnJlbW92ZSh7XG4vLyAgIHNlcnZpY2U6IFwiZmFjZWJvb2tcIlxuLy8gfSk7XG4vLyBBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLmluc2VydCh7XG4vLyAgIHNlcnZpY2U6IFwiZmFjZWJvb2tcIixcbi8vICAgYXBwSWQ6IFwiNzg0NTY2ODQ4Mzk3NDg3XCIsXG4vLyAgIHNlY3JldDogXCI2Nzg3MTI2OTdlYWU4YmRjM2NmZjI1OTM4MTM2ZTJiOVwiXG4vLyB9KTtcblxuIHNtdHAgPSB7XG4gICAgdXNlcm5hbWU6ICdhbmtpdC52YXl1ekBnbWFpbC5jb20nLFxuICAgIHBhc3N3b3JkOiAncnNrbHhqemhidGhjb3drbycsXG4gICAgc2VydmVyOiAnc210cC5nbWFpbC5jb20nLFxuICAgIHBvcnQ6IDU4N1xuICB9XG4gIHByb2Nlc3MuZW52Lk1BSUxfVVJMID0gJ3NtdHA6Ly8nICsgZW5jb2RlVVJJQ29tcG9uZW50KHNtdHAudXNlcm5hbWUpICsgJzonICsgZW5jb2RlVVJJQ29tcG9uZW50KHNtdHAucGFzc3dvcmQpICsgJ0AnICsgZW5jb2RlVVJJQ29tcG9uZW50KHNtdHAuc2VydmVyKSArICc6JyArIHNtdHAucG9ydDtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBcbmxvZ291dF9nb29nbGU6IGZ1bmN0aW9uKG5hbWUpe1xudmFyIHJlc3VsdCA9IE1ldGVvci51c2Vycy51cGRhdGUoe1xuICAgX2lkOiBuYW1lXG59LCB7XG4gICAkc2V0OiB7XG4gICAgICAgXCJzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnNcIjogW11cbiAgIH1cbn0sIHtcbiAgIG11bHRpOiB0cnVlXG59KTtcbnJldHVybiByZXN1bHQ7XG59LFxuXG4gIGluc2VydF9hZGRyZXNzOiBmdW5jdGlvbiAodXNlcklkLGFkZHJlc3MpIHtcbiAgXHR2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG4gIFx0aWYobmV3VXNlclswXSl7XG5cdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XCJsb2NhdGlvblwiOiBhZGRyZXNzfVxuXHRcdFx0fSk7XG4gIFx0fWVsc2V7XG5cdFx0XHR2YXIgcmVzdWx0ID1Vc2VySW5mby5pbnNlcnQoe1xuXHRcdFx0XHRcdGxvY2F0aW9uOmFkZHJlc3MsXG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6dXNlcklkLFxuXHRcdFx0ICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkvLyBubyBjb21tYSBuZWVkZWQgaGVyZVxuXHRcdFx0ICAgfSk7XG4gIFx0fVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH0sXG5cdCAgXHRcbiAgaW5zZXJ0X2NvbnRhY3Rfbm86IGZ1bmN0aW9uICh1c2VySWQsY29udGFjdG5vKSB7XG4gIFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1wicGhvbmVcIjogY29udGFjdG5vfVxuXHRcdFx0fSk7XG4gIFx0fWVsc2V7XG5cdFx0XHR2YXIgcmVzdWx0ID1Vc2VySW5mby5pbnNlcnQoe1xuXHRcdFx0XHRcdHBob25lOmNvbnRhY3Rubyxcblx0XHRcdCAgICAgICAgdXNlcl9pZDp1c2VySWQsXG5cdFx0XHQgICAgICAgIGNyZWF0ZWRBdDpuZXcgRGF0ZSgpIC8vIG5vIGNvbW1hIG5lZWRlZCBoZXJlXG5cdFx0XHQgICB9KTtcbiAgXHR9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfSxcbiAgIGluc2VydF9kaXNhYmlsaXRpZXM6IGZ1bmN0aW9uICh1c2VySWQsaGVhcmluZywgc3BlZWNoLCB2aXN1YWwsIHBoeXNpY2FsLCBzcGVjaWFsX25vdGUpIHtcbiAgXHR2YXIgbmV3VXNlciA9IFVzZXJNZWRpY2FsLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG4gIFx0aWYobmV3VXNlclswXSl7XG5cdFx0dmFyIHJlc3VsdCA9VXNlck1lZGljYWwudXBkYXRlKHtcblx0XHRcdCAgdXNlcl9pZDogdXNlcklkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdFx0XHQgIFx0XCJoZWFyaW5nXCI6IGhlYXJpbmcsXG5cdFx0XHQgIFx0XCJzcGVlY2hcIjogc3BlZWNoLFxuXHRcdFx0ICBcdFwidmlzdWFsXCI6IHZpc3VhbCxcblx0XHRcdCAgXHRcInBoeXNpY2FsXCI6IHBoeXNpY2FsLFxuXHRcdFx0ICBcdFwic3BlY2lhbF9ub3RlXCI6IHNwZWNpYWxfbm90ZSxcblx0XHRcdCAgfVxuXHRcdFx0fSk7XG5cbiAgXHR9ZWxzZXtcblxuXHRcdHZhciByZXN1bHQgPVVzZXJNZWRpY2FsLmluc2VydCh7XG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcblx0XHRcdCAgICAgICAgaGVhcmluZzogaGVhcmluZyxcblx0XHRcdCAgXHRcdHNwZWVjaDogc3BlZWNoLFxuXHRcdFx0ICBcdFx0dmlzdWFsOiB2aXN1YWwsXG5cdFx0XHQgIFx0XHRwaHlzaWNhbDogcGh5c2ljYWwsXG5cdFx0XHQgIFx0XHRzcGVjaWFsX25vdGU6IHNwZWNpYWxfbm90ZSxcblx0XHRcdCAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpIC8vIG5vIGNvbW1hIG5lZWRlZCBoZXJlXG5cdFx0XHQgICB9KTtcblxuXG5cdFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuXHRcdCAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHRcdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0ICAkc2V0OiB7XCJkaXNhYmxpdGllc1wiOiBcInRydWVcIn1cblx0XHRcdFx0XHR9KTtcblx0XHQgIFx0fVxuXG5cblxuICBcdH1cblxuICAgIHJldHVybiByZXN1bHQ7XG4gIH0sXG4gIHVwbG9hZF91c2VyX2ltYWdlOmZ1bmN0aW9uKHVzZXJJZCxwcm9maWxlX3BpYyl7XG4gIHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcbiAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHR2YXIgcmVzdWx0ID1cdFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcInByb2ZpbGVfcGljXCI6IHByb2ZpbGVfcGljfVxuXHRcdFx0fSk7XG4gIFx0fWVsc2V7XG5cblx0XHRcdHZhciByZXN1bHQgPVVzZXJJbmZvLmluc2VydCh7XG5cdFx0XHRcdFx0cHJvZmlsZV9waWM6cHJvZmlsZV9waWMsXG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6dXNlcklkLFxuXHRcdFx0ICAgICAgICBjcmVhdGVkQXQ6bmV3IERhdGUoKSAvLyBubyBjb21tYSBuZWVkZWQgaGVyZVxuXHRcdFx0ICAgfSk7XG5cbiAgXHR9XG4gIFx0cmV0dXJuIHJlc3VsdDtcdFxuICB9LCBcblxuICB1cGRhdGVfaGVhZGxpbmU6ZnVuY3Rpb24odXNlcklkLGhlYWRsaW5lKXtcbiAgdmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1wiaGVhZGxpbmVcIjogaGVhZGxpbmV9XG5cdFx0XHR9KTtcbiAgXHR9ZWxzZXtcblx0XHRcdHZhciByZXN1bHQgPVVzZXJJbmZvLmluc2VydCh7XG5cdFx0XHRcdFx0aGVhZGxpbmU6aGVhZGxpbmUsXG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6dXNlcklkLFxuXHRcdFx0ICAgICAgICBsb2dpbl9zdGF0dXM6IDEsXG5cdFx0XHQgICAgICAgIGNyZWF0ZWRBdDpuZXcgRGF0ZSgpIC8vIG5vIGNvbW1hIG5lZWRlZCBoZXJlXG5cdFx0XHQgICB9KTtcblxuICBcdH1cbiAgXHRyZXR1cm4gcmVzdWx0O1x0XG4gIH0sXG5cbiAgdXBkYXRlX3N1bW1hcnk6ZnVuY3Rpb24odXNlcklkLHN1bW1hcnkpe1xuICB2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG4gIFx0aWYobmV3VXNlclswXSl7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcInN1bW1hcnlcIjogc3VtbWFyeX1cblx0XHRcdH0pO1xuICBcdH1lbHNle1xuXHRcdFx0dmFyIHJlc3VsdCA9VXNlckluZm8uaW5zZXJ0KHtcblx0XHRcdFx0XHRzdW1tYXJ5OnN1bW1hcnksXG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6dXNlcklkLFxuXHRcdFx0ICAgICAgICBjcmVhdGVkQXQ6bmV3IERhdGUoKSAvLyBubyBjb21tYSBuZWVkZWQgaGVyZVxuXHRcdFx0ICAgfSk7XG4gIFx0fVxuICBcdHJldHVybiByZXN1bHQ7XHRcbiAgfSxcblxuICBjcmVhdGVfdXNlcjpmdW5jdGlvbih1c2VySUQsc291cmNlLG5hbWUsZW1haWwpe1xuXHRcdFx0dmFyIHJlc3VsdCA9VXNlckluZm8uaW5zZXJ0KHtcblx0XHRcdFx0XHRuYW1lOiBuYW1lLFxuXHRcdFx0ICAgICAgICBlbWFpbDogZW1haWwsXG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6IHVzZXJJRCxcblx0XHRcdCAgICAgICAgc291cmNlOiBzb3VyY2UsXG5cdFx0XHQgICAgICAgIGVtYWlsX3N0YXR1czogMCxcblx0XHRcdCAgICAgICAgY3JlYXRlZEF0Om5ldyBEYXRlKCkgLy8gbm8gY29tbWEgbmVlZGVkIGhlcmVcblx0XHRcdCAgIH0pO1xuXG4gIFx0cmV0dXJuIHJlc3VsdDtcdFxuICB9LFxuXG4gICAgICAgIGNvbl9yZXFfaW5zZXJ0OiBmdW5jdGlvbihzZW50X3RvLHNlbnRfYnkscmVxSUQpe1xuICBcdFx0dmFyIHJlc3VsdCA9IEZyaWVuZFJlcXVlc3QuaW5zZXJ0KHtcbiAgXHRcdFx0cmVxX2lkOiByZXFJRCxcbiAgXHRcdFx0c2VudF90bzogc2VudF90byxcbiAgXHRcdFx0c2VudF9ieTogc2VudF9ieSxcbiAgXHRcdFx0cmVxX3N0YXR1czogMCxcbiAgXHRcdFx0cmVxdWVzdGVkQXQ6IG5ldyBEYXRlKCksXG4gIFx0XHRcdHVwZGF0ZWRBdDogbmV3IERhdGUoKVxuICBcdFx0ICB9KTtcbiAgXHRcdCAgcmV0dXJuIHJlc3VsdDtcbiAgXHQgICAgfSxcblxuICBcdCAgICBjb25fcmVxX3VwZGF0ZTogZnVuY3Rpb24oc2VudF9ieSxzZW50X3RvLHJlcXVlc3RfdHlwZSl7XG4gIFx0XHR2YXIgcmVzdWx0ID0gRnJpZW5kUmVxdWVzdC51cGRhdGUoe1xuXHRcdFx0ICBzZW50X2J5OiBzZW50X2J5LFxuXHRcdFx0ICBzZW50X3RvOiBzZW50X3RvLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XCJyZXFfc3RhdHVzXCI6IHJlcXVlc3RfdHlwZSxcInVwZGF0ZWRBdFwiOiBuZXcgRGF0ZSgpfVxuXHRcdFx0fSk7XG5cdFx0ICByZXR1cm4gcmVzdWx0O1xuXHRcdFx0fSxcbiAgICAgICAgXG5cdCAgICBwZXJzX2luZm9fdXBkYXRlOiBmdW5jdGlvbihuYW1lLGdlbmRlcixtYXJpdGFsX3N0YXR1cyxwaG9uZSxkYXRlcGlja2VyLGF1dG9jb21wbGV0ZSx1c2VyX2lkKVxuXHQgICAge1xuICBcdFx0dmFyIHJlc3VsdCA9IFVzZXJJbmZvLnVwZGF0ZSh7J3VzZXJfaWQnOiB1c2VyX2lkfSx7JHNldDogeyduYW1lJzogbmFtZSwnZ2VuZGVyJzogZ2VuZGVyLFxuICAgICAgICAgICdtYXJpdGFsX3N0YXR1cyc6IG1hcml0YWxfc3RhdHVzLCdwaG9uZSc6IHBob25lLCdkb2InOiBkYXRlcGlja2VyLFxuICAgICAgICAgICdsb2NhdGlvbic6IGF1dG9jb21wbGV0ZX19KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH0sXG4gICAgICBcblx0ICAgIGluc2VydF9lZHVjYXRpb246IGZ1bmN0aW9uKHVzZXJfaWQsY291cnNlLGJvYXJkLHNjaG9vbCxzY29yZSxlZHVfc3RhcnRfbW9udGgsZWR1X3N0YXJ0X3llYXIsZWR1X2VuZF9tb250aCxlZHVfZW5kX3llYXIsZWR1X2xvY2F0aW9uKVxuXHQgICAge1xuICBcdFx0dmFyIHJlc3VsdCA9IFVzZXJFZHUuaW5zZXJ0KHsndXNlcl9pZCc6IHVzZXJfaWQsJ2NvdXJzZSc6IGNvdXJzZSwnYm9hcmQnOiBib2FyZCxcbiAgICAgICAgICAnc2Nob29sJzogc2Nob29sLCdzY29yZSc6IHNjb3JlLCdlZHVfc3RhcnRfbW9udGgnOiBlZHVfc3RhcnRfbW9udGgsXG4gICAgICAgICAgJ2VkdV9zdGFydF95ZWFyJzogZWR1X3N0YXJ0X3llYXIsJ2VkdV9lbmRfbW9udGgnOiBlZHVfZW5kX21vbnRoLCdlZHVfZW5kX3llYXInOiBlZHVfZW5kX3llYXIsJ2VkdV9sb2NhdGlvbic6IGVkdV9sb2NhdGlvbiB9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH0sXG4gICAgICBcblx0ICAgIGluc2VydF9wcm9manI6IGZ1bmN0aW9uKGNvbXBhbnlfbmFtZSxqb2JfdGl0bGUsc3RhcnRfbW9udGgsc3RhcnRfeWVhcixlbmRfbW9udGgsZW5kX3llYXIsSm9iX2xvY2F0aW9uLHNraWxsX3VzZWQsa2V5X3Jlc3BvbnNpYmlsaXRpZXMsam9iX3R5cGUsdXNlcl9pZClcblx0ICAgIHtcbiAgXHRcdHZhciByZXN1bHQgPSBVc2VyUHJvZkpyLmluc2VydCh7XG4gICAgICAgICB1c2VyX2lkOiB1c2VyX2lkLFxuICAgICAgICAgY29tcGFueTogY29tcGFueV9uYW1lLFxuICAgICAgICAgdGl0bGU6IGpvYl90aXRsZSxcbiAgICAgICAgIHN0YXJ0X21vbnRoOiBzdGFydF9tb250aCwgICBcbiAgICAgICAgIHN0YXJ0X3llYXI6IHN0YXJ0X3llYXIsICAgXG4gICAgICAgICBlbmRfbW9udGg6IGVuZF9tb250aCwgICBcbiAgICAgICAgIGVuZF95ZWFyOiBlbmRfeWVhciwgXG4gICAgICAgICBsb2NhdGlvbjogSm9iX2xvY2F0aW9uLFxuICAgICAgICAgc2tpbGw6IHNraWxsX3VzZWQsXG4gICAgICAgICBrZXlfcmVzcG9uc2liaWxpdGllczoga2V5X3Jlc3BvbnNpYmlsaXRpZXMsXG4gICAgICAgICBqb2JfdHlwZTogam9iX3R5cGUsXG4gICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksICBcbiAgICAgICAgfSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuICAgICAgXG5cdCAgaW5zZXJ0X2F3ZDogZnVuY3Rpb24odXNlcklkLGF3ZF90eXBlICxkZXNjcmlwdGlvbixhd2RfbW9udGgsYXdkX3llYXIsYXdkX2xvY2F0aW9uKVxuXHQgICAge1xuICBcdFx0dmFyIHJlc3VsdCA9IFVzZXJBd2FyZC5pbnNlcnQoe1xuICAgICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgICAgdHlwZTogYXdkX3R5cGUsXG4gICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24sXG4gICAgICAgICBhd2RfbW9udGg6IGF3ZF9tb250aCwgICBcbiAgICAgICAgIGF3ZF95ZWFyOiBhd2RfeWVhciwgICBcbiAgICAgICAgIGxvY2F0aW9uOiBhd2RfbG9jYXRpb24sXG4gICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksICBcbiAgICAgICAgfSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuICAgICAgXG5cdCAgdXBkYXRlX2F3ZDogZnVuY3Rpb24odXNlcklkLGVkaXRfaWQsYXdkX3R5cGUgLGRlc2NyaXB0aW9uLGF3ZF9tb250aCxhd2RfeWVhcixhd2RfbG9jYXRpb24pXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJBd2FyZC51cGRhdGUoe1xuXHRcdFx0ICBfaWQ6IGVkaXRfaWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcblx0XHRcdCAgXHQgICAgIFwidHlwZVwiOiBhd2RfdHlwZSxcblx0XHRcdCAgICAgICAgIFwiZGVzY3JpcHRpb25cIjogZGVzY3JpcHRpb24sXG5cdFx0XHQgICAgICAgICBcImF3ZF9tb250aFwiOiBhd2RfbW9udGgsICAgXG5cdFx0XHQgICAgICAgICBcImF3ZF95ZWFyXCI6IGF3ZF95ZWFyLCAgIFxuXHRcdFx0ICAgICAgICAgXCJsb2NhdGlvblwiOiBhd2RfbG9jYXRpb24sXG5cdFx0XHQgICAgICAgICBcImNyZWF0ZWRBdFwiOiBuZXcgRGF0ZSgpLCAgXHRcblx0XHRcdCAgfVxuXHRcdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuICAgICAgXG5cdCAgXHRpbnNlcnRfc2tpbGw6IGZ1bmN0aW9uKHVzZXJJZCxhd2RfZXhwZXJ0LGxhc3RfdXNlZCxza2lsbF9uYW1lKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyU2tpbGwuaW5zZXJ0KHtcbiAgICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcbiAgICAgICAgIGF3ZF9leHBlcnQ6IGF3ZF9leHBlcnQsXG4gICAgICAgICBsYXN0X3VzZWQ6IGxhc3RfdXNlZCxcbiAgICAgICAgIHNraWxsX25hbWU6IHNraWxsX25hbWUsIFxuICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLCAgXG4gICAgICAgIH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG4gICAgICBcblx0ICBcdHVwZGF0ZV9za2lsbDogZnVuY3Rpb24oZWRpdF9pZCxhd2RfZXhwZXJ0LGxhc3RfdXNlZCxza2lsbF9uYW1lKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyU2tpbGwudXBkYXRlKHtcblx0XHRcdCAgX2lkOiBlZGl0X2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdCAgICAgICAgIGF3ZF9leHBlcnQ6IGF3ZF9leHBlcnQsXG5cdCAgICAgICAgIGxhc3RfdXNlZDogbGFzdF91c2VkLFxuXHQgICAgICAgICBza2lsbF9uYW1lOiBza2lsbF9uYW1lLCBcblx0ICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLCAgIFx0XG5cdFx0XHQgIH1cblx0XHRcdH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG5cdFx0dXBkYXRlX3Byb2ZqcjogZnVuY3Rpb24oZWRpdF9pZCxjb21wYW55X25hbWUsam9iX3RpdGxlLHN0YXJ0X21vbnRoLHN0YXJ0X3llYXIsZW5kX21vbnRoLGVuZF95ZWFyLEpvYl9sb2NhdGlvbixcbiAgICAgICAgICBza2lsbF91c2VkLGtleV9yZXNwb25zaWJpbGl0aWVzLGpvYl90eXBlKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyUHJvZkpyLnVwZGF0ZSh7XG4gICAgICAgICAgICBfaWQ6IGVkaXRfaWRcbiAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICBjb21wYW55OiBjb21wYW55X25hbWUsXG4gICAgICAgICB0aXRsZTogam9iX3RpdGxlLFxuICAgICAgICAgc3RhcnRfbW9udGg6IHN0YXJ0X21vbnRoLCAgIFxuICAgICAgICAgc3RhcnRfeWVhcjogc3RhcnRfeWVhciwgICBcbiAgICAgICAgICAgXG4gICAgICAgICBlbmRfbW9udGg6IGVuZF9tb250aCwgICBcbiAgICAgICAgIGVuZF95ZWFyOiBlbmRfeWVhciwgXG4gICAgICAgICBsb2NhdGlvbjogSm9iX2xvY2F0aW9uLFxuICAgICAgICAgc2tpbGw6IHNraWxsX3VzZWQsXG4gICAgICAgICBqb2JfdHlwZTogam9iX3R5cGUsXG4gICAgICAgICBrZXlfcmVzcG9uc2liaWxpdGllczoga2V5X3Jlc3BvbnNpYmlsaXRpZXMsXG4gICAgICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkgLFxuICAgICAgICAgfX0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG5cblx0XHR1cGRhdGVfcHJvZmpyXzI6IGZ1bmN0aW9uKGVkaXRfaWQsY29tcGFueV9uYW1lLGpvYl90aXRsZSxzdGFydF9tb250aCxlbmRfbW9udGgsSm9iX2xvY2F0aW9uLFxuICAgICAgICAgIHNraWxsX3VzZWQsa2V5X3Jlc3BvbnNpYmlsaXRpZXMsam9iX3R5cGUpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJQcm9mSnIudXBkYXRlKHtcbiAgICAgICAgICAgIF9pZDogZWRpdF9pZFxuICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgIGNvbXBhbnk6IGNvbXBhbnlfbmFtZSxcbiAgICAgICAgIHRpdGxlOiBqb2JfdGl0bGUsXG4gICAgICAgICBzdGFydF9tb250aDogc3RhcnRfbW9udGgsICAgXG4gICAgICAgICBzdGFydF95ZWFyOiBzdGFydF95ZWFyLCAgIFxuICAgICAgICAgICBcbiAgICAgICAgIGxvY2F0aW9uOiBKb2JfbG9jYXRpb24sXG4gICAgICAgICBza2lsbDogc2tpbGxfdXNlZCxcbiAgICAgICAgIGpvYl90eXBlOiBqb2JfdHlwZSxcbiAgICAgICAgIGtleV9yZXNwb25zaWJpbGl0aWVzOiBrZXlfcmVzcG9uc2liaWxpdGllcyxcbiAgICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKSAsXG4gICAgICAgICB9fSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdFx0fSxcblxuXG5cdFx0dXBkYXRlX2VkdWNhdGlvbjogZnVuY3Rpb24oZWRpdF9pZCxjb3Vyc2UsYm9hcmQsc2Nob29sLHNjb3JlLGVkdV9zdGFydF9tb250aCxlZHVfc3RhcnRfeWVhcixlZHVfZW5kX21vbnRoLGVkdV9lbmRfeWVhcixlZHVfbG9jYXRpb24pXG5cdCAgICB7XG5cdFx0XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJFZHUudXBkYXRlKHtcbiAgICAgICAgICAgIF9pZDogZWRpdF9pZFxuICAgICAgICBcbiAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAkc2V0OiB7J2NvdXJzZSc6IGNvdXJzZSwnYm9hcmQnOiBib2FyZCxcbiAgICAgICAgICAnc2Nob29sJzogc2Nob29sLCdzY29yZSc6IHNjb3JlLCdlZHVfc3RhcnRfbW9udGgnOiBlZHVfc3RhcnRfbW9udGgsXG4gICAgICAgICAgJ2VkdV9zdGFydF95ZWFyJzogZWR1X3N0YXJ0X3llYXIsJ2VkdV9lbmRfbW9udGgnOiBlZHVfZW5kX21vbnRoLCdlZHVfZW5kX3llYXInOiBlZHVfZW5kX3llYXIsJ2VkdV9sb2NhdGlvbic6IGVkdV9sb2NhdGlvbiB9XG4gICAgIH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG4gICAgICAgIHVwbG9hZF9jb3Zlcl9pbWFnZTogZnVuY3Rpb24odXNlcl9pZCxpbWFnZVBhdGgpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHQgIHVzZXJfaWQ6IHVzZXJfaWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcblx0XHRcdCAgXHQgICAgIFwiY292ZXJfaW1hZ2VcIjogaW1hZ2VQYXRoLFxuXHRcdFx0ICAgICAgICAgXCJsYXN0VXBkYXRlQXRcIjogbmV3IERhdGUoKVxuXHRcdFx0ICB9XG5cdFx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH0sXG5cblx0XHR1cGxvYWRfcHJvZmlsZV9pbWFnZTogZnVuY3Rpb24odXNlcl9pZCxpbWFnZVBhdGgpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHQgIHVzZXJfaWQ6IHVzZXJfaWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcblx0XHRcdCAgXHQgICAgIFwicHJvZmlsZV9waWNcIjogaW1hZ2VQYXRoLFxuXHRcdFx0ICAgICAgICAgXCJsYXN0VXBkYXRlQXRcIjogbmV3IERhdGUoKVxuXHRcdFx0ICB9XG5cdFx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH0sXG5cbiAgICAgICAgaW5zZXJ0X21lc3NhZ2U6IGZ1bmN0aW9uKHNlbnRfYnksc2VudF90byxtc2dfdGV4dCxtc2dfaWQsY2hhdHJvb21faWQsbXNnX2ltZ19pZClcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gTWVzc2FnZS5pbnNlcnQoe1x0XG5cdFx0IG1zZ19pZDogbXNnX2lkLFxuICAgICAgICAgc2VudF9ieTogc2VudF9ieSxcbiAgICAgICAgIHNlbnRfdG86IHNlbnRfdG8sXG4gICAgICAgICBjaGF0cm9vbV9pZDpjaGF0cm9vbV9pZCxcbiAgICAgICAgIG1zZ190ZXh0OiBtc2dfdGV4dCxcbiAgICAgICAgIGltYWdlX2F0dGFjaDogbXNnX2ltZ19pZCxcbiAgICAgICAgIHNlbnRBdDogbmV3IERhdGUoKSwgIFxuICAgICAgICB9KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LCBcblxuICAgICAgICBcbiAgICAgICAgaW5zZXJ0X21lc3NhZ2VfV2l0aF9pbWc6IGZ1bmN0aW9uKHNlbnRfYnksc2VudF90byxtc2dfaW1nX2lkLG1zZ19pZClcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gTWVzc2FnZS5pbnNlcnQoe1xuXHRcdCBtc2dfaWQ6IG1zZ19pZCxcbiAgICAgICAgIHNlbnRfYnk6IHNlbnRfYnksXG4gICAgICAgICBzZW50X3RvOiBzZW50X3RvLFxuICAgICAgICAgbXNnX3RleHQ6IDAsXG4gICAgICAgICBpbWFnZV9hdHRhY2g6IG1zZ19pbWdfaWQsXG4gICAgICAgICBzZW50QXQ6IG5ldyBEYXRlKCksICBcbiAgICAgICAgfSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdFx0fSwgXG5cblx0XHRpbnNlcnRfbWVzc2FnZV9XaXRoX2F0dGFjaG1lbnQ6IGZ1bmN0aW9uKG1zZ19pZCxzZW50X3RvLHNlbnRfYnksYXR0YWNoX25hbWUsYXR0YWNoX3BhdGgsZm9ybWF0KVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBNZXNzYWdlLmluc2VydCh7XG5cdFx0IG1zZ19pZDogbXNnX2lkLFxuICAgICAgICAgc2VudF9ieTogc2VudF9ieSxcbiAgICAgICAgIHNlbnRfdG86IHNlbnRfdG8sXG4gICAgICAgICBtc2dfdGV4dDogMCxcbiAgICAgICAgIGltYWdlX2F0dGFjaDogMCxcbiAgICAgICAgIGF0dGFjaG1lbnRfbmFtZTogYXR0YWNoX25hbWUsXG4gICAgICAgICBhdHRhY2htZW50X3BhdGg6IGF0dGFjaF9wYXRoLFxuICAgICAgICAgZm9ybWF0OiBmb3JtYXQsXG4gICAgICAgICBzZW50QXQ6IG5ldyBEYXRlKCksICBcbiAgICAgICAgfSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdFx0fSwgXG5cblx0XHRpbnNlcnRfR3JvdXBfZGV0YWlsczogZnVuY3Rpb24odXNlcl9pZCxncnBfaW1hZ2UsZ3JwX3RpdGxlLGdycF90eXBlLGdycF9kaXNjcmlwdGlvbixncnBfdmlzaWJpbGl0eSxncnBfaWQpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJHcm91cC5pbnNlcnQoe1xuXHRcdCBncnBfaWQ6IGdycF9pZCxcblx0XHQgZ3JwX3RpdGxlOiBncnBfdGl0bGUsXG5cdFx0IGFkbWluOiB1c2VyX2lkLFxuICAgICAgICAgZ3JwX3R5cGU6IGdycF90eXBlLFxuICAgICAgICAgZ3JwX2Rpc2NyaXB0aW9uOiBncnBfZGlzY3JpcHRpb24sXG4gICAgICAgICBncnBfdmlzaWJpbGl0eTogZ3JwX3Zpc2liaWxpdHksXG4gICAgICAgICBncnBfaW1hZ2U6IGdycF9pbWFnZSxcbiAgICAgICAgIGFjdGl2aXR5X3N0YXR1czogMSxcbiAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSBcbiAgICAgICAgfSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdFx0fSxcblxuXHRcdHVwZGF0ZV9Hcm91cF9kZXRhaWxzOiBmdW5jdGlvbih1c2VyX2lkLGdycF9pbWFnZSxncnBfdGl0bGUsZ3JwX3R5cGUsZ3JwX2Rpc2NyaXB0aW9uLFxuXHRcdFx0Z3JwX3Zpc2liaWxpdHksZ3JwX2lkLGFjdGl2aXR5X3N0YXR1cylcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gVXNlckdyb3VwLnVwZGF0ZSh7XG5cdFx0XHQgIGdycF9pZDogZ3JwX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdFx0ICAgICAgICAgICAgIGdycF90aXRsZTogZ3JwX3RpdGxlLFxuXHRcdFx0XHRcdCBhZG1pbjogdXNlcl9pZCxcblx0XHRcdCAgICAgICAgIGdycF90eXBlOiBncnBfdHlwZSxcblx0XHRcdCAgICAgICAgIGdycF9kaXNjcmlwdGlvbjogZ3JwX2Rpc2NyaXB0aW9uLFxuXHRcdFx0ICAgICAgICAgZ3JwX3Zpc2liaWxpdHk6IGdycF92aXNpYmlsaXR5LFxuXHRcdFx0ICAgICAgICAgZ3JwX2ltYWdlOiBncnBfaW1hZ2UsXG5cdFx0XHQgICAgICAgICBhY3Rpdml0eV9zdGF0dXM6IGFjdGl2aXR5X3N0YXR1cyxcblx0XHRcdCAgICAgICAgIFVwZGF0ZWRBdDogbmV3IERhdGUoKSwgXG5cdFx0XHQgIH1cblx0XHRcdH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG4gICBcbiAgIFx0IFx0c2VuZEVtYWlsOiBmdW5jdGlvbiAodXNlcklkLCBlbWFpbCkge1xuICAgICAgICAgICAgRW1haWwuc2VuZChlbWFpbCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgdXBkYXRlX0dyb3VwX2FjdGl2aXR5OiBmdW5jdGlvbihncnBfaWQsYWN0aXZpdHlfc3RhdHVzKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyR3JvdXAudXBkYXRlKHtcblx0XHRcdCAgZ3JwX2lkOiBncnBfaWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcblx0XHRcdCAgXHQgICAgIFwiYWN0aXZpdHlfc3RhdHVzXCI6IGFjdGl2aXR5X3N0YXR1cyxcblx0XHRcdCAgICAgICAgIFwibGFzdFVwZGF0ZUF0XCI6IG5ldyBEYXRlKClcblx0XHRcdCAgfVxuXHRcdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LCAgICAgIFxuXHRcdHVwZGF0ZV9lbWFpbF9zdGF0dXM6ZnVuY3Rpb24odXNlcklkLGVtYWlsX3N0YXR1cyl7XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XCJlbWFpbF9zdGF0dXNcIjogMX1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LCAgICAgIFxuXHRcdHNldF9kZWZhdWx0X2NvdmVyOmZ1bmN0aW9uKHVzZXJJZCxzZXRfZGVmYXVsdCl7XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XCJjb3Zlcl9pbWFnZVwiOiBzZXRfZGVmYXVsdH1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LCAgICAgIFxuXHRcdHNldF9kZWZhdWx0X3Byb2ZpbGVfcGljOmZ1bmN0aW9uKHVzZXJJZCxzZXRfZGVmYXVsdCl7XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XCJwcm9maWxlX3BpY1wiOiBzZXRfZGVmYXVsdH1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuXG5cdFx0dXBkYXRlX2xvZ2luX3N0YXR1czpmdW5jdGlvbihsb2dpbl9zdGF0dXMsdXNlcklkKXtcbiAgICAgICAgXHRcdHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcblx0XHRcdCAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHRcdFx0XHR2YXIgcmVzdWx0ID1cdFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHRcdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0XHQgICRzZXQ6IHtcImxvZ2luX3N0YXR1c1wiOiBsb2dpbl9zdGF0dXN9XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcblxuXHRcdHVwZGF0ZV9wYXNzaW9uOmZ1bmN0aW9uKHVzZXJJZCxwYXNzaW9uKXtcbiAgICAgICAgXHRcdHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcblx0XHRcdCAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHRcdFx0XHR2YXIgcmVzdWx0ID1cdFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHRcdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0XHQgICRzZXQ6IHtcInBhc3Npb25cIjogcGFzc2lvbn1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuICAgICAgICBcbiAgICAgICAgcmVtb3ZlX3NraWxsOmZ1bmN0aW9uKHNraWxsX2lkKXtcbiAgICAgICAgXHQgICAgdmFyIHJlc3VsdCA9XHRVc2VyU2tpbGwucmVtb3ZlKHtfaWQ6IHNraWxsX2lkIH0pO1xuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZV9hd2FyZDpmdW5jdGlvbihhd2RfaWQpe1xuICAgICAgICBcdCAgICB2YXIgcmVzdWx0ID1cdFVzZXJBd2FyZC5yZW1vdmUoe19pZDogYXdkX2lkIH0pO1xuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZV9wcm9manI6ZnVuY3Rpb24ocHJvZmpyX2lkKXtcbiAgICAgICAgXHQgICAgdmFyIHJlc3VsdCA9XHRVc2VyUHJvZkpyLnJlbW92ZSh7X2lkOiBwcm9manJfaWQgfSk7XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcbiAgICAgICAgcmVtb3ZlX2VkdWNhdGlvbjpmdW5jdGlvbihlZHVfaWQpe1xuICAgICAgICBcdCAgICB2YXIgcmVzdWx0ID1cdFVzZXJFZHUucmVtb3ZlKHtfaWQ6IGVkdV9pZCB9KTtcblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbW92ZV9ncm91cF9yZXF1ZXN0OmZ1bmN0aW9uKHNlbnRfYnksZ3JwX2lkKXtcbiAgICAgICAgXHQgICAgdmFyIHJlc3VsdCA9XHRHcm91cFJlcXVlc3QucmVtb3ZlKHtzZW50X2J5OiBzZW50X2J5LCBncnBfaWQ6IGdycF9pZH0pO1xuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgaW5zZXJ0X2dyb3VwX3JlcXVlc3Q6ZnVuY3Rpb24ocmVxX2lkLHNlbnRfYnksZ3JwX2lkLHN0YXR1cyl7XG4gICAgICAgIFx0XHR2YXIgcmVzdWx0ID0gR3JvdXBSZXF1ZXN0Lmluc2VydCh7XG5cdFx0XHQgICAgICAgICByZXFfaWQ6IHJlcV9pZCxcblx0XHRcdCAgICAgICAgIHNlbnRfYnk6IHNlbnRfYnksXG5cdFx0XHQgICAgICAgICBncnBfaWQ6IGdycF9pZCxcblx0XHRcdCAgICAgICAgIHN0YXR1czogc3RhdHVzLFxuXHRcdFx0ICAgICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLCAgXG5cdFx0XHQgICAgICAgIH0pO1xuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG5cbiAgICAgICAgVXBkYXRlX0NoYXRyb29tOmZ1bmN0aW9uKGNoYXRyb29tX2lkLHVzZXIxLHVzZXIyLGxhc3RfbXNnLGxhc3RfbXNnX2lkLGxhc3RfbXNnX3NlbnRfYnksY29ubmVjdF9zdGF0dXMsXG5jdXJyZW50bHlfdHlwaW5nKXtcbiAgICAgICAgXHRcdHZhciBuZXdVc2VyID0gQ2hhdHJvb20uZmluZCh7Y2hhdHJvb21faWQ6IGNoYXRyb29tX2lkfSkuZmV0Y2goKTtcblx0XHRcdCAgXHR2YXIgdG90YWxfbWVzc2FnZXMgPSBNZXNzYWdlLmZpbmQoe1wiY2hhdHJvb21faWRcIjpjaGF0cm9vbV9pZH0pLmNvdW50KCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9IENoYXRyb29tLnVwZGF0ZSh7XG5cdFx0XHRcdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0XHQgICRzZXQ6IHtcblx0XHRcdFx0XHRcdCAgXHRcdFx0XHR0b3RhbF9tZXNzYWdlczp0b3RhbF9tZXNzYWdlcysxLFxuXHRcdFx0XHRcdFx0ICAgICAgICAgICAgICAgIGxhc3RfbXNnOiBsYXN0X21zZyxcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICBsYXN0X21zZ19pZDpsYXN0X21zZ19pZCxcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICBsYXN0X21zZ190aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0bGFzdF9tc2dfc2VudF9ieTogbGFzdF9tc2dfc2VudF9ieSwgXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHRjb25uZWN0X3N0YXR1czogY29ubmVjdF9zdGF0dXMsIFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0Y3VycmVudGx5X3R5cGluZzogY3VycmVudGx5X3R5cGluZ1xuXG5cdFx0XHRcdFx0XHQgIH1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgXHRlbHNle1xuXHRcdFx0ICBcdFx0dmFyIHJlc3VsdCA9XHRDaGF0cm9vbS5pbnNlcnQoe1xuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0Y2hhdHJvb21faWQ6IGNoYXRyb29tX2lkLCBcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdHVzZXIxOiAgICAgICAgdXNlcjEgLCBcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdHVzZXIyOiAgICAgICAgdXNlcjIgLCBcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGxhc3RfbXNnX2lkOiBsYXN0X21zZ19pZCxcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGxhc3RfbXNnOiBsYXN0X21zZywgXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHRsYXN0X21zZ190aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0bGFzdF9tc2dfc2VudF9ieTogbGFzdF9tc2dfc2VudF9ieSwgXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHRjb25uZWN0X3N0YXR1czogY29ubmVjdF9zdGF0dXMsIFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0Y3VycmVudGx5X3R5cGluZzogY3VycmVudGx5X3R5cGluZyBcblx0XHRcdFx0XHRcdFx0XHRcdFx0fSk7XG5cdFx0XHQgIFx0fVxuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG5cblxuICAgICAgICBVcGRhdGVfY3VycmVudGx5X3R5cGluZzpmdW5jdGlvbihjaGF0cm9vbV9pZCxjdXJyZW50bHlfdHlwaW5nKXsgICAgICAgIFx0XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IENoYXRyb29tLmZpbmQoe2NoYXRyb29tX2lkOiBjaGF0cm9vbV9pZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9IENoYXRyb29tLnVwZGF0ZSh7XG5cdFx0XHRcdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0XHQgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICBcdFx0XHRcdGN1cnJlbnRseV90eXBpbmc6IGN1cnJlbnRseV90eXBpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgXHRcdCAgfVxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHQgIFx0fVxuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG4gICAgICAgIGNoYW5nZV91c2VyX29ubGluZV9zdGF0dXM6ZnVuY3Rpb24odXNlcklkLHN0YXR1cyl7XG4gICAgICAgIFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuXHRcdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0XHR2YXIgcmVzdWx0ID0gVXNlckluZm8udXBkYXRlKHtcblx0XHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0XHRcdCAgJHNldDoge1wib25saW5lX3N0YXR1c1wiOiBzdGF0dXN9XG5cdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHQgIFx0fVxuXHRcdFx0XHQgIFx0cmV0dXJuIHJlc3VsdDtcdFxuICAgICAgICB9LFxuICAgICAgICB1cGRhdGVfY2hhdHJvb21fY291bnQ6ZnVuY3Rpb24oY2hhdHJvb21faWQsY291bnQpe1xuICAgICAgICBcdHZhciBuZXdVc2VyID0gQ2hhdHJvb20uZmluZCh7Y2hhdHJvb21faWQ6IGNoYXRyb29tX2lkfSkuZmV0Y2goKTtcbiAgICAgICAgXHRcdHZhciB1cGRhdGVkQ291bnQ9MDtcbiAgICAgICAgXHRpZihuZXdVc2VyWzBdLnVucmVhZF9tc2dfY291bnQpe1xuXHRcdFx0XHR1cGRhdGVkQ291bnQgID0gbmV3VXNlclswXS51bnJlYWRfbXNnX2NvdW50KzE7XG4gICAgICAgIFx0fWVsc2V7XG5cdFx0XHRcdHVwZGF0ZWRDb3VudCAgPTE7IFxuICAgICAgICBcdH1cbiAgICAgICAgXHRpZihjb3VudCA9PSAwKXtcblx0XHRcdHVwZGF0ZWRDb3VudCA9IDA7XG4gICAgICAgIFx0fVxuXHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdHZhciByZXN1bHQgPSBDaGF0cm9vbS51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XG5cdFx0XHRcdFx0XHQgIFx0XHRcdCBsYXN0X21zZ190aW1lOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgICAgICAgIFx0XHRcdFx0dW5yZWFkX21zZ19jb3VudDogdXBkYXRlZENvdW50XG4gICAgICAgICAgICAgICAgICAgICAgIFx0XHQgIH1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgXHRyZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuICAgICAgICB1cGRhdGVfbGFzdF9tc2dfc3RhdHVzOmZ1bmN0aW9uKG1lc3NhZ2VfaWQsc3RhdHVzKXtcblxuICAgICAgICBcdHZhciBuZXdVc2VyID0gTWVzc2FnZS5maW5kKHtcIm1zZ19pZFwiOm1lc3NhZ2VfaWR9KS5mZXRjaCgpO1xuICAgICAgICBcdGlmKHN0YXR1cyA9PSBcInJlYWRcIil7XG5cdFx0XHRcdHZhciBuZXdVc2VyID0gTWVzc2FnZS5maW5kKHtcImNoYXRyb29tX2lkXCI6bmV3VXNlclswXS5jaGF0cm9vbV9pZH0pLmZldGNoKCk7XG5cdFx0XHRcdGZvcih2YXIgaT0wO2k8bmV3VXNlci5sZW5ndGg7aSsrKXtcblx0XHRcdFx0dmFyIHJlc3VsdCA9IE1lc3NhZ2UudXBkYXRlKHtcblx0XHRcdFx0XHRfaWQ6IG5ld1VzZXJbaV0uX2lkLFxuXHRcdFx0XHQgXHR9LCB7XG5cdFx0XHRcdFx0JHNldDoge1wiZGVsaXZlcnlfc3RhdHVzXCI6IFwicmVhZFwifVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0fVxuXHRcdFx0XHRcblx0XHRcdFxuICAgICAgICBcdH1lbHNle1xuICAgICAgICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0dmFyIHJlc3VsdCA9IE1lc3NhZ2UudXBkYXRlKHtcblx0XHRcdFx0XHRfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0JHNldDoge1wiZGVsaXZlcnlfc3RhdHVzXCI6IHN0YXR1c31cblx0XHRcdFx0fSk7XG5cdFx0XHR9XHRcbiAgICAgICAgXHR9XG5cdFx0XHRcblx0XHRcdFx0ICBcdHJldHVybiByZXN1bHQ7XHRcbiAgICAgICAgfSxcblxuXG5cbn0pO1xuXG5cblxuXG5cbiJdfQ==
