var require = meteorInstall({"lib":{"config.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// lib/config.js                                                                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Base64;
module.watch(require("meteor/ostrio:base64"), {
  Base64(v) {
    Base64 = v;
  }

}, 0);
let Session;
module.watch(require("meteor/session"), {
  Session(v) {
    Session = v;
  }

}, 1);
Router.route('/profile', function () {
  if (Session.get("userId") != "") {
    this.render('profile');
  } else {
    Router.go('/');
  }
});
Router.route('/view_profile/:user_id', function () {
  var params = this.params; // { _id: "5" }
  // var id = params.user_id; // "5"

  var userId = params.user_id; // "5"

  userId = Base64.decode(userId); // alert("decrypt" + userId);
  // Session.set("makeUserActive","true");
  // Session.setPersistent("show_connection",head[0].user_id);

  Session.set("show_connection", userId); // alert('hi');

  this.render('view_profile');
});
Router.route('/', function () {
  this.render('login');
});
Router.route('/signup', function () {
  if (Session.get("userId") != "") {
    this.render('signup');
  } else {
    Router.go('/');
  }
});
Router.route('/connection', function () {
  this.render('connection');
});
Router.route('/Messaging', function () {
  this.render('messagingpage');
});
Router.route('/grplisting', function () {
  this.render('grplisting');
});
Router.route('/group_discussion', function () {
  this.render('group_discussion');
});
Router.route('/email', function () {
  if (Session.get("userId") != "") {
    this.render('email');
  } else {
    Router.go('/');
  }
});
Router.route('/activate_email/:id', function () {
  var params = this.params; // { _id: "5" }

  var userId = params.id; // "5"

  userId = Base64.decode(userId); // alert("decrypt" + userId);

  Session.set("makeUserActive", "true");
  Session.setPersistent("userId", userId);
  this.render('email');
});
Router.route('/creategroup', function () {
  this.render('creategroup');
});
Router.route('/messaging_page', function () {
  this.render('messaging_page');
});
Router.route('/groupdetail/:grp_id', function () {
  var params = this.params; // { _id: "5" }

  var encrypted = params.grp_id; // "5"
  // decrypted = CryptoJS.AES.decrypt(encrypted, 'Passphrase');
  // var id = decrypted.toString(CryptoJS.enc.Utf8);

  Session.set("show_grp_id", encrypted);
  this.render('groupdetail');
});
Router.route('/editgroup/:grp_id', function () {
  var params = this.params; // { _id: "5" }

  var encrypted = params.grp_id; // "5"
  // decrypted = CryptoJS.AES.decrypt(encrypted, 'Passphrase');
  // var id = decrypted.toString(CryptoJS.enc.Utf8);

  Session.set("show_grp_edit_id", encrypted);
  this.render('editgroup');
});
Router.route('/logout', function () {
  this.render('login');
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"import":{"collections":{"insert.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// import/collections/insert.js                                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  UserInfo: () => UserInfo,
  UserSkill: () => UserSkill,
  UserProfJr: () => UserProfJr,
  UserEdu: () => UserEdu,
  UserAward: () => UserAward,
  UserMedical: () => UserMedical,
  FriendRequest: () => FriendRequest,
  Message: () => Message,
  UserGroup: () => UserGroup,
  GroupRequest: () => GroupRequest,
  Chatroom: () => Chatroom
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const UserInfo = new Mongo.Collection('user_info');
const UserSkill = new Mongo.Collection('user_skill');
const UserProfJr = new Mongo.Collection('user_profjr');
const UserEdu = new Mongo.Collection('user_edu');
const UserAward = new Mongo.Collection('user_award');
const UserMedical = new Mongo.Collection('user_medical');
const FriendRequest = new Mongo.Collection('friend');
const Message = new Mongo.Collection('message');
const UserGroup = new Mongo.Collection('user_group');
const GroupRequest = new Mongo.Collection('group_request');
const Chatroom = new Mongo.Collection('chatroom');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// import/config.js                                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  Images: () => Images
});
let FilesCollection;
module.watch(require("meteor/ostrio:files"), {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 0);
const Images = new FilesCollection({
  debug: true,
  collectionName: 'Images',
  allowClientCode: false,
  // Disallow remove files from Client
  storagePath: () => {
    return `${process.env.PWD}/uploads`;
  },
  onBeforeUpload: function (file) {
    // Allow upload files under 10MB, and only in png/jpg/jpeg formats
    if (file.size <= 1024 * 1024 * 10 && /png|jpe?g/i.test(file.extension)) {
      return true;
    }

    return 'Please upload image, with size equal or less than 10MB';
  }
});
module.exportDefault(Images);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.watch(require("meteor/meteor"), {
	Meteor(v) {
		Meteor = v;
	}

}, 0);
let UserInfo;
module.watch(require("./../import/collections/insert.js"), {
	UserInfo(v) {
		UserInfo = v;
	}

}, 1);
let UserSkill;
module.watch(require("./../import/collections/insert.js"), {
	UserSkill(v) {
		UserSkill = v;
	}

}, 2);
let UserProfJr;
module.watch(require("./../import/collections/insert.js"), {
	UserProfJr(v) {
		UserProfJr = v;
	}

}, 3);
let UserEdu;
module.watch(require("./../import/collections/insert.js"), {
	UserEdu(v) {
		UserEdu = v;
	}

}, 4);
let UserAward;
module.watch(require("./../import/collections/insert.js"), {
	UserAward(v) {
		UserAward = v;
	}

}, 5);
let UserMedical;
module.watch(require("./../import/collections/insert.js"), {
	UserMedical(v) {
		UserMedical = v;
	}

}, 6);
let FriendRequest;
module.watch(require("./../import/collections/insert.js"), {
	FriendRequest(v) {
		FriendRequest = v;
	}

}, 7);
let Message;
module.watch(require("./../import/collections/insert.js"), {
	Message(v) {
		Message = v;
	}

}, 8);
let UserGroup;
module.watch(require("./../import/collections/insert.js"), {
	UserGroup(v) {
		UserGroup = v;
	}

}, 9);
let Email;
module.watch(require("meteor/email"), {
	Email(v) {
		Email = v;
	}

}, 10);
let GroupRequest;
module.watch(require("./../import/collections/insert.js"), {
	GroupRequest(v) {
		GroupRequest = v;
	}

}, 11);
let Chatroom;
module.watch(require("./../import/collections/insert.js"), {
	Chatroom(v) {
		Chatroom = v;
	}

}, 12);
let ServiceConfiguration;
module.watch(require("meteor/service-configuration"), {
	ServiceConfiguration(v) {
		ServiceConfiguration = v;
	}

}, 13);
Meteor.startup(function () {
	UploadServer.init({
		tmpDir: process.env.PWD + '/.uploads/tmp',
		uploadDir: process.env.PWD + '/uploaded/'
	});
}); //    var t1 = Presence.configure({
//   state: function() {
//     return {
//       online: false
//     }
//     userId: cool;
//   }
// });
//     if(t1 == 0){
//     	alert('i am active');
//     	console.log('active');
//     }
//     else if( t1 == 1 || t1 == 2){
//        alert('i am inactive');
//        console.log('In-active');
//        Session.setPersistent("login_status",0);              
//     }
//     else{
//     	console.log('In-active');
//     }

ServiceConfiguration.configurations.remove({
	service: "google"
});
ServiceConfiguration.configurations.insert({
	service: "google",
	clientId: "448932643096-qqt9pqi7c3ag0rcq1v6e9q2a8rfe65ap.apps.googleusercontent.com",
	secret: "0bTZibxwUduW_NEqf4W0Ngmb"
}); // first, remove configuration entry in case service is already configured

ServiceConfiguration.configurations.remove({
	service: "facebook"
});
ServiceConfiguration.configurations.insert({
	service: "facebook",
	appId: "784566848397487",
	secret: "678712697eae8bdc3cff25938136e2b9"
});
ServiceConfiguration.configurations.remove({
	service: "linkedin"
});
ServiceConfiguration.configurations.insert({
	service: "linkedin",
	clientId: "78eqh4qk0yx7y7",
	secret: "ixPAnSBiCtBq6WPJ"
}); // // first, remove configuration entry in case service is already configured
// Accounts.loginServiceConfiguration.remove({
//   service: "facebook"
// });
// Accounts.loginServiceConfiguration.insert({
//   service: "facebook",
//   appId: "784566848397487",
//   secret: "678712697eae8bdc3cff25938136e2b9"
// });

smtp = {
	username: 'ankit.vayuz@gmail.com',
	password: 'rsklxjzhbthcowko',
	server: 'smtp.gmail.com',
	port: 587
};
process.env.MAIL_URL = 'smtp://' + encodeURIComponent(smtp.username) + ':' + encodeURIComponent(smtp.password) + '@' + encodeURIComponent(smtp.server) + ':' + smtp.port;
Meteor.methods({
	logout_google: function (name) {
		var result = Meteor.users.update({
			_id: name
		}, {
			$set: {
				"services.resume.loginTokens": []
			}
		}, {
			multi: true
		});
		return result;
	},
	insert_address: function (userId, address) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"location": address
				}
			});
		} else {
			var result = UserInfo.insert({
				location: address,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	insert_contact_no: function (userId, contactno) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"phone": contactno
				}
			});
		} else {
			var result = UserInfo.insert({
				phone: contactno,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	insert_disabilities: function (userId, hearing, speech, visual, physical, special_note) {
		var newUser = UserMedical.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserMedical.update({
				user_id: userId
			}, {
				$set: {
					"hearing": hearing,
					"speech": speech,
					"visual": visual,
					"physical": physical,
					"special_note": special_note
				}
			});
		} else {
			var result = UserMedical.insert({
				user_id: userId,
				hearing: hearing,
				speech: speech,
				visual: visual,
				physical: physical,
				special_note: special_note,
				createdAt: new Date() // no comma needed here

			});
			var newUser = UserInfo.find({
				"user_id": userId
			}).fetch();

			if (newUser[0]) {
				var result = UserInfo.update({
					_id: newUser[0]._id
				}, {
					$set: {
						"disablities": "true"
					}
				});
			}
		}

		return result;
	},
	upload_user_image: function (userId, profile_pic) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"profile_pic": profile_pic
				}
			});
		} else {
			var result = UserInfo.insert({
				profile_pic: profile_pic,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	update_headline: function (userId, headline) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"headline": headline
				}
			});
		} else {
			var result = UserInfo.insert({
				headline: headline,
				user_id: userId,
				login_status: 1,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	update_summary: function (userId, summary) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"summary": summary
				}
			});
		} else {
			var result = UserInfo.insert({
				summary: summary,
				user_id: userId,
				createdAt: new Date() // no comma needed here

			});
		}

		return result;
	},
	create_user: function (userID, source, name, email) {
		var result = UserInfo.insert({
			name: name,
			email: email,
			user_id: userID,
			source: source,
			email_status: 0,
			createdAt: new Date() // no comma needed here

		});
		return result;
	},
	con_req_insert: function (sent_to, sent_by, reqID) {
		var result = FriendRequest.insert({
			req_id: reqID,
			sent_to: sent_to,
			sent_by: sent_by,
			req_status: 0,
			requestedAt: new Date(),
			updatedAt: new Date()
		});
		return result;
	},
	con_req_update: function (sent_by, sent_to, request_type) {
		var result = FriendRequest.update({
			sent_by: sent_by,
			sent_to: sent_to
		}, {
			$set: {
				"req_status": request_type,
				"updatedAt": new Date()
			}
		});
		return result;
	},
	pers_info_update: function (name, gender, marital_status, phone, datepicker, autocomplete, user_id) {
		var result = UserInfo.update({
			'user_id': user_id
		}, {
			$set: {
				'name': name,
				'gender': gender,
				'marital_status': marital_status,
				'phone': phone,
				'dob': datepicker,
				'location': autocomplete
			}
		});
		return result;
	},
	insert_education: function (user_id, course, board, school, score, edu_start_month, edu_start_year, edu_end_month, edu_end_year, edu_location) {
		var result = UserEdu.insert({
			'user_id': user_id,
			'course': course,
			'board': board,
			'school': school,
			'score': score,
			'edu_start_month': edu_start_month,
			'edu_start_year': edu_start_year,
			'edu_end_month': edu_end_month,
			'edu_end_year': edu_end_year,
			'edu_location': edu_location
		});
		return result;
	},
	insert_profjr: function (company_name, job_title, start_month, start_year, end_month, end_year, Job_location, skill_used, key_responsibilities, job_type, user_id) {
		var result = UserProfJr.insert({
			user_id: user_id,
			company: company_name,
			title: job_title,
			start_month: start_month,
			start_year: start_year,
			end_month: end_month,
			end_year: end_year,
			location: Job_location,
			skill: skill_used,
			key_responsibilities: key_responsibilities,
			job_type: job_type,
			createdAt: new Date()
		});
		return result;
	},
	insert_awd: function (userId, awd_type, description, awd_month, awd_year, awd_location) {
		var result = UserAward.insert({
			user_id: userId,
			type: awd_type,
			description: description,
			awd_month: awd_month,
			awd_year: awd_year,
			location: awd_location,
			createdAt: new Date()
		});
		return result;
	},
	update_awd: function (userId, edit_id, awd_type, description, awd_month, awd_year, awd_location) {
		var result = UserAward.update({
			_id: edit_id
		}, {
			$set: {
				"type": awd_type,
				"description": description,
				"awd_month": awd_month,
				"awd_year": awd_year,
				"location": awd_location,
				"createdAt": new Date()
			}
		});
		return result;
	},
	insert_skill: function (userId, awd_expert, last_used, skill_name) {
		var result = UserSkill.insert({
			user_id: userId,
			awd_expert: awd_expert,
			last_used: last_used,
			skill_name: skill_name,
			createdAt: new Date()
		});
		return true;
	},
	update_skill: function (edit_id, awd_expert, last_used, skill_name) {
		var result = UserSkill.update({
			_id: edit_id
		}, {
			$set: {
				awd_expert: awd_expert,
				last_used: last_used,
				skill_name: skill_name,
				createdAt: new Date()
			}
		});
		return true;
	},
	update_profjr: function (edit_id, company_name, job_title, start_month, start_year, end_month, end_year, Job_location, skill_used, key_responsibilities, job_type) {
		var result = UserProfJr.update({
			_id: edit_id
		}, {
			$set: {
				company: company_name,
				title: job_title,
				start_month: start_month,
				start_year: start_year,
				end_month: end_month,
				end_year: end_year,
				location: Job_location,
				skill: skill_used,
				job_type: job_type,
				key_responsibilities: key_responsibilities,
				updatedAt: new Date()
			}
		});
		return true;
	},
	update_profjr_2: function (edit_id, company_name, job_title, start_month, end_month, Job_location, skill_used, key_responsibilities, job_type) {
		var result = UserProfJr.update({
			_id: edit_id
		}, {
			$set: {
				company: company_name,
				title: job_title,
				start_month: start_month,
				start_year: start_year,
				location: Job_location,
				skill: skill_used,
				job_type: job_type,
				key_responsibilities: key_responsibilities,
				updatedAt: new Date()
			}
		});
		return true;
	},
	update_education: function (edit_id, course, board, school, score, edu_start_month, edu_start_year, edu_end_month, edu_end_year, edu_location) {
		var result = UserEdu.update({
			_id: edit_id
		}, {
			$set: {
				'course': course,
				'board': board,
				'school': school,
				'score': score,
				'edu_start_month': edu_start_month,
				'edu_start_year': edu_start_year,
				'edu_end_month': edu_end_month,
				'edu_end_year': edu_end_year,
				'edu_location': edu_location
			}
		});
		return true;
	},
	upload_cover_image: function (user_id, imagePath) {
		var result = UserInfo.update({
			user_id: user_id
		}, {
			$set: {
				"cover_image": imagePath,
				"lastUpdateAt": new Date()
			}
		});
		return result;
	},
	upload_profile_image: function (user_id, imagePath) {
		var result = UserInfo.update({
			user_id: user_id
		}, {
			$set: {
				"profile_pic": imagePath,
				"lastUpdateAt": new Date()
			}
		});
		return result;
	},
	insert_message: function (sent_by, sent_to, msg_text, msg_id, chatroom_id, msg_img_id) {
		var result = Message.insert({
			msg_id: msg_id,
			sent_by: sent_by,
			sent_to: sent_to,
			chatroom_id: chatroom_id,
			msg_text: msg_text,
			image_attach: msg_img_id,
			sentAt: new Date()
		});
		return true;
	},
	insert_message_With_img: function (sent_by, sent_to, msg_img_id, msg_id) {
		var result = Message.insert({
			msg_id: msg_id,
			sent_by: sent_by,
			sent_to: sent_to,
			msg_text: 0,
			image_attach: msg_img_id,
			sentAt: new Date()
		});
		return true;
	},
	insert_message_With_attachment: function (msg_id, sent_to, sent_by, attach_name, attach_path, format) {
		var result = Message.insert({
			msg_id: msg_id,
			sent_by: sent_by,
			sent_to: sent_to,
			msg_text: 0,
			image_attach: 0,
			attachment_name: attach_name,
			attachment_path: attach_path,
			format: format,
			sentAt: new Date()
		});
		return true;
	},
	insert_Group_details: function (user_id, grp_image, grp_title, grp_type, grp_discription, grp_visibility, grp_id) {
		var result = UserGroup.insert({
			grp_id: grp_id,
			grp_title: grp_title,
			admin: user_id,
			grp_type: grp_type,
			grp_discription: grp_discription,
			grp_visibility: grp_visibility,
			grp_image: grp_image,
			activity_status: 1,
			createdAt: new Date()
		});
		return true;
	},
	update_Group_details: function (user_id, grp_image, grp_title, grp_type, grp_discription, grp_visibility, grp_id, activity_status) {
		var result = UserGroup.update({
			grp_id: grp_id
		}, {
			$set: {
				grp_title: grp_title,
				admin: user_id,
				grp_type: grp_type,
				grp_discription: grp_discription,
				grp_visibility: grp_visibility,
				grp_image: grp_image,
				activity_status: activity_status,
				UpdatedAt: new Date()
			}
		});
		return true;
	},
	sendEmail: function (userId, email) {
		Email.send(email);
	},
	update_Group_activity: function (grp_id, activity_status) {
		var result = UserGroup.update({
			grp_id: grp_id
		}, {
			$set: {
				"activity_status": activity_status,
				"lastUpdateAt": new Date()
			}
		});
		return result;
	},
	update_email_status: function (userId, email_status) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"email_status": 1
				}
			});
		}

		return result;
	},
	set_default_cover: function (userId, set_default) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"cover_image": set_default
				}
			});
		}

		return result;
	},
	set_default_profile_pic: function (userId, set_default) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"profile_pic": set_default
				}
			});
		}

		return result;
	},
	update_login_status: function (login_status, userId) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"login_status": login_status
				}
			});
		}

		return result;
	},
	update_passion: function (userId, passion) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"passion": passion
				}
			});
		}

		return result;
	},
	remove_skill: function (skill_id) {
		var result = UserSkill.remove({
			_id: skill_id
		});
		return result;
	},
	remove_award: function (awd_id) {
		var result = UserAward.remove({
			_id: awd_id
		});
		return result;
	},
	remove_profjr: function (profjr_id) {
		var result = UserProfJr.remove({
			_id: profjr_id
		});
		return result;
	},
	remove_education: function (edu_id) {
		var result = UserEdu.remove({
			_id: edu_id
		});
		return result;
	},
	remove_group_request: function (sent_by, grp_id) {
		var result = GroupRequest.remove({
			sent_by: sent_by,
			grp_id: grp_id
		});
		return result;
	},
	insert_group_request: function (req_id, sent_by, grp_id, status) {
		var result = GroupRequest.insert({
			req_id: req_id,
			sent_by: sent_by,
			grp_id: grp_id,
			status: status,
			sentAt: new Date()
		});
		return result;
	},
	Update_Chatroom: function (chatroom_id, user1, user2, last_msg, last_msg_id, last_msg_sent_by, connect_status, currently_typing) {
		var newUser = Chatroom.find({
			chatroom_id: chatroom_id
		}).fetch();
		var total_messages = Message.find({
			"chatroom_id": chatroom_id
		}).count();

		if (newUser[0]) {
			var result = Chatroom.update({
				_id: newUser[0]._id
			}, {
				$set: {
					total_messages: total_messages + 1,
					last_msg: last_msg,
					last_msg_id: last_msg_id,
					last_msg_time: Date.now(),
					last_msg_sent_by: last_msg_sent_by,
					connect_status: connect_status,
					currently_typing: currently_typing
				}
			});
		} else {
			var result = Chatroom.insert({
				chatroom_id: chatroom_id,
				user1: user1,
				user2: user2,
				last_msg_id: last_msg_id,
				last_msg: last_msg,
				last_msg_time: Date.now(),
				last_msg_sent_by: last_msg_sent_by,
				connect_status: connect_status,
				currently_typing: currently_typing
			});
		}

		return result;
	},
	Update_currently_typing: function (chatroom_id, currently_typing) {
		var newUser = Chatroom.find({
			chatroom_id: chatroom_id
		}).fetch();

		if (newUser[0]) {
			var result = Chatroom.update({
				_id: newUser[0]._id
			}, {
				$set: {
					currently_typing: currently_typing
				}
			});
		}

		return result;
	},
	change_user_online_status: function (userId, status) {
		var newUser = UserInfo.find({
			"user_id": userId
		}).fetch();

		if (newUser[0]) {
			var result = UserInfo.update({
				_id: newUser[0]._id
			}, {
				$set: {
					"online_status": status
				}
			});
		}

		return result;
	},
	update_chatroom_count: function (chatroom_id, count) {
		var newUser = Chatroom.find({
			chatroom_id: chatroom_id
		}).fetch();
		var updatedCount = 0;

		if (newUser[0].unread_msg_count) {
			updatedCount = newUser[0].unread_msg_count + 1;
		} else {
			updatedCount = 1;
		}

		if (count == 0) {
			updatedCount = 0;
		}

		if (newUser[0]) {
			var result = Chatroom.update({
				_id: newUser[0]._id
			}, {
				$set: {
					last_msg_time: Date.now(),
					unread_msg_count: updatedCount
				}
			});
		}

		return result;
	},
	update_last_msg_status: function (message_id, status) {
		var newUser = Message.find({
			"msg_id": message_id
		}).fetch();

		if (status == "read") {
			var newUser = Message.find({
				"chatroom_id": newUser[0].chatroom_id
			}).fetch();

			for (var i = 0; i < newUser.length; i++) {
				var result = Message.update({
					_id: newUser[i]._id
				}, {
					$set: {
						"delivery_status": "read"
					}
				});
			}
		} else {
			if (newUser[0]) {
				var result = Message.update({
					_id: newUser[0]._id
				}, {
					$set: {
						"delivery_status": status
					}
				});
			}
		}

		return result;
	}
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/config.js");
require("./import/collections/insert.js");
require("./import/config.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0L2NvbmZpZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiQmFzZTY0IiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIlNlc3Npb24iLCJSb3V0ZXIiLCJyb3V0ZSIsImdldCIsInJlbmRlciIsImdvIiwicGFyYW1zIiwidXNlcklkIiwidXNlcl9pZCIsImRlY29kZSIsInNldCIsImlkIiwic2V0UGVyc2lzdGVudCIsImVuY3J5cHRlZCIsImdycF9pZCIsImV4cG9ydCIsIlVzZXJJbmZvIiwiVXNlclNraWxsIiwiVXNlclByb2ZKciIsIlVzZXJFZHUiLCJVc2VyQXdhcmQiLCJVc2VyTWVkaWNhbCIsIkZyaWVuZFJlcXVlc3QiLCJNZXNzYWdlIiwiVXNlckdyb3VwIiwiR3JvdXBSZXF1ZXN0IiwiQ2hhdHJvb20iLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJJbWFnZXMiLCJGaWxlc0NvbGxlY3Rpb24iLCJkZWJ1ZyIsImNvbGxlY3Rpb25OYW1lIiwiYWxsb3dDbGllbnRDb2RlIiwic3RvcmFnZVBhdGgiLCJwcm9jZXNzIiwiZW52IiwiUFdEIiwib25CZWZvcmVVcGxvYWQiLCJmaWxlIiwic2l6ZSIsInRlc3QiLCJleHRlbnNpb24iLCJleHBvcnREZWZhdWx0IiwiTWV0ZW9yIiwiRW1haWwiLCJTZXJ2aWNlQ29uZmlndXJhdGlvbiIsInN0YXJ0dXAiLCJVcGxvYWRTZXJ2ZXIiLCJpbml0IiwidG1wRGlyIiwidXBsb2FkRGlyIiwiY29uZmlndXJhdGlvbnMiLCJyZW1vdmUiLCJzZXJ2aWNlIiwiaW5zZXJ0IiwiY2xpZW50SWQiLCJzZWNyZXQiLCJhcHBJZCIsInNtdHAiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwic2VydmVyIiwicG9ydCIsIk1BSUxfVVJMIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwibWV0aG9kcyIsImxvZ291dF9nb29nbGUiLCJuYW1lIiwicmVzdWx0IiwidXNlcnMiLCJ1cGRhdGUiLCJfaWQiLCIkc2V0IiwibXVsdGkiLCJpbnNlcnRfYWRkcmVzcyIsImFkZHJlc3MiLCJuZXdVc2VyIiwiZmluZCIsImZldGNoIiwibG9jYXRpb24iLCJjcmVhdGVkQXQiLCJEYXRlIiwiaW5zZXJ0X2NvbnRhY3Rfbm8iLCJjb250YWN0bm8iLCJwaG9uZSIsImluc2VydF9kaXNhYmlsaXRpZXMiLCJoZWFyaW5nIiwic3BlZWNoIiwidmlzdWFsIiwicGh5c2ljYWwiLCJzcGVjaWFsX25vdGUiLCJ1cGxvYWRfdXNlcl9pbWFnZSIsInByb2ZpbGVfcGljIiwidXBkYXRlX2hlYWRsaW5lIiwiaGVhZGxpbmUiLCJsb2dpbl9zdGF0dXMiLCJ1cGRhdGVfc3VtbWFyeSIsInN1bW1hcnkiLCJjcmVhdGVfdXNlciIsInVzZXJJRCIsInNvdXJjZSIsImVtYWlsIiwiZW1haWxfc3RhdHVzIiwiY29uX3JlcV9pbnNlcnQiLCJzZW50X3RvIiwic2VudF9ieSIsInJlcUlEIiwicmVxX2lkIiwicmVxX3N0YXR1cyIsInJlcXVlc3RlZEF0IiwidXBkYXRlZEF0IiwiY29uX3JlcV91cGRhdGUiLCJyZXF1ZXN0X3R5cGUiLCJwZXJzX2luZm9fdXBkYXRlIiwiZ2VuZGVyIiwibWFyaXRhbF9zdGF0dXMiLCJkYXRlcGlja2VyIiwiYXV0b2NvbXBsZXRlIiwiaW5zZXJ0X2VkdWNhdGlvbiIsImNvdXJzZSIsImJvYXJkIiwic2Nob29sIiwic2NvcmUiLCJlZHVfc3RhcnRfbW9udGgiLCJlZHVfc3RhcnRfeWVhciIsImVkdV9lbmRfbW9udGgiLCJlZHVfZW5kX3llYXIiLCJlZHVfbG9jYXRpb24iLCJpbnNlcnRfcHJvZmpyIiwiY29tcGFueV9uYW1lIiwiam9iX3RpdGxlIiwic3RhcnRfbW9udGgiLCJzdGFydF95ZWFyIiwiZW5kX21vbnRoIiwiZW5kX3llYXIiLCJKb2JfbG9jYXRpb24iLCJza2lsbF91c2VkIiwia2V5X3Jlc3BvbnNpYmlsaXRpZXMiLCJqb2JfdHlwZSIsImNvbXBhbnkiLCJ0aXRsZSIsInNraWxsIiwiaW5zZXJ0X2F3ZCIsImF3ZF90eXBlIiwiZGVzY3JpcHRpb24iLCJhd2RfbW9udGgiLCJhd2RfeWVhciIsImF3ZF9sb2NhdGlvbiIsInR5cGUiLCJ1cGRhdGVfYXdkIiwiZWRpdF9pZCIsImluc2VydF9za2lsbCIsImF3ZF9leHBlcnQiLCJsYXN0X3VzZWQiLCJza2lsbF9uYW1lIiwidXBkYXRlX3NraWxsIiwidXBkYXRlX3Byb2ZqciIsInVwZGF0ZV9wcm9manJfMiIsInVwZGF0ZV9lZHVjYXRpb24iLCJ1cGxvYWRfY292ZXJfaW1hZ2UiLCJpbWFnZVBhdGgiLCJ1cGxvYWRfcHJvZmlsZV9pbWFnZSIsImluc2VydF9tZXNzYWdlIiwibXNnX3RleHQiLCJtc2dfaWQiLCJjaGF0cm9vbV9pZCIsIm1zZ19pbWdfaWQiLCJpbWFnZV9hdHRhY2giLCJzZW50QXQiLCJpbnNlcnRfbWVzc2FnZV9XaXRoX2ltZyIsImluc2VydF9tZXNzYWdlX1dpdGhfYXR0YWNobWVudCIsImF0dGFjaF9uYW1lIiwiYXR0YWNoX3BhdGgiLCJmb3JtYXQiLCJhdHRhY2htZW50X25hbWUiLCJhdHRhY2htZW50X3BhdGgiLCJpbnNlcnRfR3JvdXBfZGV0YWlscyIsImdycF9pbWFnZSIsImdycF90aXRsZSIsImdycF90eXBlIiwiZ3JwX2Rpc2NyaXB0aW9uIiwiZ3JwX3Zpc2liaWxpdHkiLCJhZG1pbiIsImFjdGl2aXR5X3N0YXR1cyIsInVwZGF0ZV9Hcm91cF9kZXRhaWxzIiwiVXBkYXRlZEF0Iiwic2VuZEVtYWlsIiwic2VuZCIsInVwZGF0ZV9Hcm91cF9hY3Rpdml0eSIsInVwZGF0ZV9lbWFpbF9zdGF0dXMiLCJzZXRfZGVmYXVsdF9jb3ZlciIsInNldF9kZWZhdWx0Iiwic2V0X2RlZmF1bHRfcHJvZmlsZV9waWMiLCJ1cGRhdGVfbG9naW5fc3RhdHVzIiwidXBkYXRlX3Bhc3Npb24iLCJwYXNzaW9uIiwicmVtb3ZlX3NraWxsIiwic2tpbGxfaWQiLCJyZW1vdmVfYXdhcmQiLCJhd2RfaWQiLCJyZW1vdmVfcHJvZmpyIiwicHJvZmpyX2lkIiwicmVtb3ZlX2VkdWNhdGlvbiIsImVkdV9pZCIsInJlbW92ZV9ncm91cF9yZXF1ZXN0IiwiaW5zZXJ0X2dyb3VwX3JlcXVlc3QiLCJzdGF0dXMiLCJVcGRhdGVfQ2hhdHJvb20iLCJ1c2VyMSIsInVzZXIyIiwibGFzdF9tc2ciLCJsYXN0X21zZ19pZCIsImxhc3RfbXNnX3NlbnRfYnkiLCJjb25uZWN0X3N0YXR1cyIsImN1cnJlbnRseV90eXBpbmciLCJ0b3RhbF9tZXNzYWdlcyIsImNvdW50IiwibGFzdF9tc2dfdGltZSIsIm5vdyIsIlVwZGF0ZV9jdXJyZW50bHlfdHlwaW5nIiwiY2hhbmdlX3VzZXJfb25saW5lX3N0YXR1cyIsInVwZGF0ZV9jaGF0cm9vbV9jb3VudCIsInVwZGF0ZWRDb3VudCIsInVucmVhZF9tc2dfY291bnQiLCJ1cGRhdGVfbGFzdF9tc2dfc3RhdHVzIiwibWVzc2FnZV9pZCIsImkiLCJsZW5ndGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDSCxTQUFPSSxDQUFQLEVBQVM7QUFBQ0osYUFBT0ksQ0FBUDtBQUFTOztBQUFwQixDQUE3QyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJQyxPQUFKO0FBQVlKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQkFBUixDQUFiLEVBQXVDO0FBQUNFLFVBQVFELENBQVIsRUFBVTtBQUFDQyxjQUFRRCxDQUFSO0FBQVU7O0FBQXRCLENBQXZDLEVBQStELENBQS9EO0FBSzdGRSxPQUFPQyxLQUFQLENBQWEsVUFBYixFQUF5QixZQUFZO0FBQ25DLE1BQUdGLFFBQVFHLEdBQVIsQ0FBWSxRQUFaLEtBQXVCLEVBQTFCLEVBQTZCO0FBQzdCLFNBQUtDLE1BQUwsQ0FBWSxTQUFaO0FBQ0QsR0FGQyxNQUVHO0FBQ0hILFdBQU9JLEVBQVAsQ0FBVSxHQUFWO0FBQ0Q7QUFDQSxDQU5EO0FBUUFKLE9BQU9DLEtBQVAsQ0FBYSx3QkFBYixFQUF1QyxZQUFZO0FBQ2hELE1BQUtJLFNBQVMsS0FBS0EsTUFBbkIsQ0FEZ0QsQ0FDckI7QUFDNUI7O0FBRUUsTUFBSUMsU0FBU0QsT0FBT0UsT0FBcEIsQ0FKK0MsQ0FJbEI7O0FBQzdCRCxXQUFTWixPQUFPYyxNQUFQLENBQWNGLE1BQWQsQ0FBVCxDQUwrQyxDQU03QztBQUNKO0FBQ0E7O0FBQ0FQLFVBQVFVLEdBQVIsQ0FBWSxpQkFBWixFQUE4QkgsTUFBOUIsRUFUaUQsQ0FVakQ7O0FBQ0EsT0FBS0gsTUFBTCxDQUFZLGNBQVo7QUFDRCxDQVpEO0FBY0FILE9BQU9DLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLFlBQVk7QUFDNUIsT0FBS0UsTUFBTCxDQUFZLE9BQVo7QUFDRCxDQUZEO0FBSUFILE9BQU9DLEtBQVAsQ0FBYSxTQUFiLEVBQXdCLFlBQVk7QUFDakMsTUFBR0YsUUFBUUcsR0FBUixDQUFZLFFBQVosS0FBdUIsRUFBMUIsRUFBNkI7QUFDL0IsU0FBS0MsTUFBTCxDQUFZLFFBQVo7QUFDQSxHQUZFLE1BRUU7QUFDSEgsV0FBT0ksRUFBUCxDQUFVLEdBQVY7QUFDRDtBQUdBLENBUkQ7QUFVQUosT0FBT0MsS0FBUCxDQUFhLGFBQWIsRUFBNEIsWUFBWTtBQUN0QyxPQUFLRSxNQUFMLENBQVksWUFBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLFlBQWIsRUFBMkIsWUFBWTtBQUNyQyxPQUFLRSxNQUFMLENBQVksZUFBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLGFBQWIsRUFBNEIsWUFBWTtBQUN0QyxPQUFLRSxNQUFMLENBQVksWUFBWjtBQUNELENBRkQ7QUFJQUgsT0FBT0MsS0FBUCxDQUFhLG1CQUFiLEVBQWtDLFlBQVk7QUFDNUMsT0FBS0UsTUFBTCxDQUFZLGtCQUFaO0FBQ0QsQ0FGRDtBQUlBSCxPQUFPQyxLQUFQLENBQWEsUUFBYixFQUF1QixZQUN2QjtBQUFHLE1BQUdGLFFBQVFHLEdBQVIsQ0FBWSxRQUFaLEtBQXVCLEVBQTFCLEVBQTZCO0FBQzlCLFNBQUtDLE1BQUwsQ0FBWSxPQUFaO0FBQ0QsR0FGRSxNQUVFO0FBQ0hILFdBQU9JLEVBQVAsQ0FBVSxHQUFWO0FBQ0Q7QUFFQSxDQVBEO0FBU0FKLE9BQU9DLEtBQVAsQ0FBYSxxQkFBYixFQUFvQyxZQUFZO0FBQzlDLE1BQUtJLFNBQVMsS0FBS0EsTUFBbkIsQ0FEOEMsQ0FDbkI7O0FBQzNCLE1BQUlDLFNBQVNELE9BQU9LLEVBQXBCLENBRjhDLENBRXRCOztBQUN0QkosV0FBU1osT0FBT2MsTUFBUCxDQUFjRixNQUFkLENBQVQsQ0FINEMsQ0FJMUM7O0FBQ0pQLFVBQVFVLEdBQVIsQ0FBWSxnQkFBWixFQUE2QixNQUE3QjtBQUNBVixVQUFRWSxhQUFSLENBQXNCLFFBQXRCLEVBQStCTCxNQUEvQjtBQUNBLE9BQUtILE1BQUwsQ0FBWSxPQUFaO0FBR0QsQ0FWRDtBQWNBSCxPQUFPQyxLQUFQLENBQWEsY0FBYixFQUE2QixZQUFZO0FBQ3ZDLE9BQUtFLE1BQUwsQ0FBWSxhQUFaO0FBQ0QsQ0FGRDtBQUlBSCxPQUFPQyxLQUFQLENBQWEsaUJBQWIsRUFBZ0MsWUFBWTtBQUMxQyxPQUFLRSxNQUFMLENBQVksZ0JBQVo7QUFDRCxDQUZEO0FBSUFILE9BQU9DLEtBQVAsQ0FBYSxzQkFBYixFQUFxQyxZQUFZO0FBQy9DLE1BQUtJLFNBQVMsS0FBS0EsTUFBbkIsQ0FEK0MsQ0FDcEI7O0FBQzNCLE1BQUlPLFlBQVlQLE9BQU9RLE1BQXZCLENBRitDLENBRWhCO0FBRWpDO0FBQ0E7O0FBRUFkLFVBQVFVLEdBQVIsQ0FBWSxhQUFaLEVBQTBCRyxTQUExQjtBQUNDLE9BQUtULE1BQUwsQ0FBWSxhQUFaO0FBQ0EsQ0FURDtBQVdBSCxPQUFPQyxLQUFQLENBQWEsb0JBQWIsRUFBbUMsWUFBWTtBQUM3QyxNQUFLSSxTQUFTLEtBQUtBLE1BQW5CLENBRDZDLENBQ2xCOztBQUMzQixNQUFJTyxZQUFZUCxPQUFPUSxNQUF2QixDQUY2QyxDQUVkO0FBRWpDO0FBQ0E7O0FBRUFkLFVBQVFVLEdBQVIsQ0FBWSxrQkFBWixFQUErQkcsU0FBL0I7QUFDRSxPQUFLVCxNQUFMLENBQVksV0FBWjtBQUNELENBVEQ7QUFXQUgsT0FBT0MsS0FBUCxDQUFhLFNBQWIsRUFBd0IsWUFBWTtBQUNsQyxPQUFLRSxNQUFMLENBQVksT0FBWjtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUM5R0FSLE9BQU9tQixNQUFQLENBQWM7QUFBQ0MsWUFBUyxNQUFJQSxRQUFkO0FBQXVCQyxhQUFVLE1BQUlBLFNBQXJDO0FBQStDQyxjQUFXLE1BQUlBLFVBQTlEO0FBQXlFQyxXQUFRLE1BQUlBLE9BQXJGO0FBQTZGQyxhQUFVLE1BQUlBLFNBQTNHO0FBQXFIQyxlQUFZLE1BQUlBLFdBQXJJO0FBQWlKQyxpQkFBYyxNQUFJQSxhQUFuSztBQUFpTEMsV0FBUSxNQUFJQSxPQUE3TDtBQUFxTUMsYUFBVSxNQUFJQSxTQUFuTjtBQUE2TkMsZ0JBQWEsTUFBSUEsWUFBOU87QUFBMlBDLFlBQVMsTUFBSUE7QUFBeFEsQ0FBZDtBQUFpUyxJQUFJQyxLQUFKO0FBQVUvQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM2QixRQUFNNUIsQ0FBTixFQUFRO0FBQUM0QixZQUFNNUIsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUVwUyxNQUFNaUIsV0FBVyxJQUFJVyxNQUFNQyxVQUFWLENBQXFCLFdBQXJCLENBQWpCO0FBQ0EsTUFBTVgsWUFBWSxJQUFJVSxNQUFNQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCO0FBQ0EsTUFBTVYsYUFBYSxJQUFJUyxNQUFNQyxVQUFWLENBQXFCLGFBQXJCLENBQW5CO0FBQ0EsTUFBTVQsVUFBVSxJQUFJUSxNQUFNQyxVQUFWLENBQXFCLFVBQXJCLENBQWhCO0FBQ0EsTUFBTVIsWUFBWSxJQUFJTyxNQUFNQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCO0FBQ0EsTUFBTVAsY0FBYyxJQUFJTSxNQUFNQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBRUEsTUFBTU4sZ0JBQWdCLElBQUlLLE1BQU1DLFVBQVYsQ0FBcUIsUUFBckIsQ0FBdEI7QUFDQSxNQUFNTCxVQUFVLElBQUlJLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEI7QUFDQSxNQUFNSixZQUFZLElBQUlHLE1BQU1DLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbEI7QUFDQSxNQUFNSCxlQUFlLElBQUlFLE1BQU1DLFVBQVYsQ0FBcUIsZUFBckIsQ0FBckI7QUFDQSxNQUFNRixXQUFXLElBQUlDLE1BQU1DLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakIsQzs7Ozs7Ozs7Ozs7QUNiUGhDLE9BQU9tQixNQUFQLENBQWM7QUFBQ2MsVUFBTyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSUMsZUFBSjtBQUFvQmxDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQkFBUixDQUFiLEVBQTRDO0FBQUNnQyxrQkFBZ0IvQixDQUFoQixFQUFrQjtBQUFDK0Isc0JBQWdCL0IsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQTVDLEVBQW9GLENBQXBGO0FBRWhELE1BQU04QixTQUFTLElBQUlDLGVBQUosQ0FBb0I7QUFDeENDLFNBQU8sSUFEaUM7QUFFeENDLGtCQUFnQixRQUZ3QjtBQUd4Q0MsbUJBQWlCLEtBSHVCO0FBR2hCO0FBQ3hCQyxlQUFhLE1BQU07QUFDYixXQUFRLEdBQUVDLFFBQVFDLEdBQVIsQ0FBWUMsR0FBSSxVQUExQjtBQUNMLEdBTnVDO0FBTW5DQyxrQkFBZ0IsVUFBVUMsSUFBVixFQUFnQjtBQUNuQztBQUNBLFFBQUlBLEtBQUtDLElBQUwsSUFBYSxPQUFPLElBQVAsR0FBYyxFQUEzQixJQUFpQyxhQUFhQyxJQUFiLENBQWtCRixLQUFLRyxTQUF2QixDQUFyQyxFQUF3RTtBQUN0RSxhQUFPLElBQVA7QUFDRDs7QUFDRCxXQUFPLHdEQUFQO0FBQ0Q7QUFadUMsQ0FBcEIsQ0FBZjtBQUZQOUMsT0FBTytDLGFBQVAsQ0FpQmVkLE1BakJmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSWUsTUFBSjtBQUFXaEQsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDOEMsUUFBTzdDLENBQVAsRUFBUztBQUFDNkMsV0FBTzdDLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWlCLFFBQUo7QUFBYXBCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUNrQixVQUFTakIsQ0FBVCxFQUFXO0FBQUNpQixhQUFTakIsQ0FBVDtBQUFXOztBQUF4QixDQUExRCxFQUFvRixDQUFwRjtBQUF1RixJQUFJa0IsU0FBSjtBQUFjckIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ21CLFdBQVVsQixDQUFWLEVBQVk7QUFBQ2tCLGNBQVVsQixDQUFWO0FBQVk7O0FBQTFCLENBQTFELEVBQXNGLENBQXRGO0FBQXlGLElBQUltQixVQUFKO0FBQWV0QixPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDb0IsWUFBV25CLENBQVgsRUFBYTtBQUFDbUIsZUFBV25CLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSW9CLE9BQUo7QUFBWXZCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUNxQixTQUFRcEIsQ0FBUixFQUFVO0FBQUNvQixZQUFRcEIsQ0FBUjtBQUFVOztBQUF0QixDQUExRCxFQUFrRixDQUFsRjtBQUFxRixJQUFJcUIsU0FBSjtBQUFjeEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ3NCLFdBQVVyQixDQUFWLEVBQVk7QUFBQ3FCLGNBQVVyQixDQUFWO0FBQVk7O0FBQTFCLENBQTFELEVBQXNGLENBQXRGO0FBQXlGLElBQUlzQixXQUFKO0FBQWdCekIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ3VCLGFBQVl0QixDQUFaLEVBQWM7QUFBQ3NCLGdCQUFZdEIsQ0FBWjtBQUFjOztBQUE5QixDQUExRCxFQUEwRixDQUExRjtBQUE2RixJQUFJdUIsYUFBSjtBQUFrQjFCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxtQ0FBUixDQUFiLEVBQTBEO0FBQUN3QixlQUFjdkIsQ0FBZCxFQUFnQjtBQUFDdUIsa0JBQWN2QixDQUFkO0FBQWdCOztBQUFsQyxDQUExRCxFQUE4RixDQUE5RjtBQUFpRyxJQUFJd0IsT0FBSjtBQUFZM0IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQ3lCLFNBQVF4QixDQUFSLEVBQVU7QUFBQ3dCLFlBQVF4QixDQUFSO0FBQVU7O0FBQXRCLENBQTFELEVBQWtGLENBQWxGO0FBQXFGLElBQUl5QixTQUFKO0FBQWM1QixPQUFPQyxLQUFQLENBQWFDLFFBQVEsbUNBQVIsQ0FBYixFQUEwRDtBQUFDMEIsV0FBVXpCLENBQVYsRUFBWTtBQUFDeUIsY0FBVXpCLENBQVY7QUFBWTs7QUFBMUIsQ0FBMUQsRUFBc0YsQ0FBdEY7QUFBeUYsSUFBSThDLEtBQUo7QUFBVWpELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQytDLE9BQU05QyxDQUFOLEVBQVE7QUFBQzhDLFVBQU05QyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELEVBQXpEO0FBQTZELElBQUkwQixZQUFKO0FBQWlCN0IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQzJCLGNBQWExQixDQUFiLEVBQWU7QUFBQzBCLGlCQUFhMUIsQ0FBYjtBQUFlOztBQUFoQyxDQUExRCxFQUE0RixFQUE1RjtBQUFnRyxJQUFJMkIsUUFBSjtBQUFhOUIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG1DQUFSLENBQWIsRUFBMEQ7QUFBQzRCLFVBQVMzQixDQUFULEVBQVc7QUFBQzJCLGFBQVMzQixDQUFUO0FBQVc7O0FBQXhCLENBQTFELEVBQW9GLEVBQXBGO0FBQXdGLElBQUkrQyxvQkFBSjtBQUF5QmxELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw4QkFBUixDQUFiLEVBQXFEO0FBQUNnRCxzQkFBcUIvQyxDQUFyQixFQUF1QjtBQUFDK0MseUJBQXFCL0MsQ0FBckI7QUFBdUI7O0FBQWhELENBQXJELEVBQXVHLEVBQXZHO0FBbUJyeUM2QyxPQUFPRyxPQUFQLENBQWUsWUFBWTtBQUN6QkMsY0FBYUMsSUFBYixDQUFrQjtBQUNoQkMsVUFBUWYsUUFBUUMsR0FBUixDQUFZQyxHQUFaLEdBQWtCLGVBRFY7QUFFaEJjLGFBQVdoQixRQUFRQyxHQUFSLENBQVlDLEdBQVosR0FBa0I7QUFGYixFQUFsQjtBQUlELENBTEQsRSxDQVVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBR0FTLHFCQUFxQk0sY0FBckIsQ0FBb0NDLE1BQXBDLENBQTJDO0FBQ3pDQyxVQUFTO0FBRGdDLENBQTNDO0FBSUFSLHFCQUFxQk0sY0FBckIsQ0FBb0NHLE1BQXBDLENBQTJDO0FBQ3pDRCxVQUFTLFFBRGdDO0FBRXpDRSxXQUFVLDBFQUYrQjtBQUd6Q0MsU0FBUTtBQUhpQyxDQUEzQyxFLENBTUE7O0FBQ0FYLHFCQUFxQk0sY0FBckIsQ0FBb0NDLE1BQXBDLENBQTJDO0FBQ3pDQyxVQUFTO0FBRGdDLENBQTNDO0FBSUFSLHFCQUFxQk0sY0FBckIsQ0FBb0NHLE1BQXBDLENBQTJDO0FBQ3pDRCxVQUFTLFVBRGdDO0FBRXpDSSxRQUFPLGlCQUZrQztBQUd6Q0QsU0FBUTtBQUhpQyxDQUEzQztBQU1BWCxxQkFBcUJNLGNBQXJCLENBQW9DQyxNQUFwQyxDQUEyQztBQUN6Q0MsVUFBUztBQURnQyxDQUEzQztBQUlBUixxQkFBcUJNLGNBQXJCLENBQW9DRyxNQUFwQyxDQUEyQztBQUN6Q0QsVUFBUyxVQURnQztBQUV6Q0UsV0FBVSxnQkFGK0I7QUFHekNDLFNBQVE7QUFIaUMsQ0FBM0MsRSxDQUtBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQ0UsT0FBTztBQUNKQyxXQUFVLHVCQUROO0FBRUpDLFdBQVUsa0JBRk47QUFHSkMsU0FBUSxnQkFISjtBQUlKQyxPQUFNO0FBSkYsQ0FBUDtBQU1DNUIsUUFBUUMsR0FBUixDQUFZNEIsUUFBWixHQUF1QixZQUFZQyxtQkFBbUJOLEtBQUtDLFFBQXhCLENBQVosR0FBZ0QsR0FBaEQsR0FBc0RLLG1CQUFtQk4sS0FBS0UsUUFBeEIsQ0FBdEQsR0FBMEYsR0FBMUYsR0FBZ0dJLG1CQUFtQk4sS0FBS0csTUFBeEIsQ0FBaEcsR0FBa0ksR0FBbEksR0FBd0lILEtBQUtJLElBQXBLO0FBRUZuQixPQUFPc0IsT0FBUCxDQUFlO0FBRWZDLGdCQUFlLFVBQVNDLElBQVQsRUFBYztBQUM3QixNQUFJQyxTQUFTekIsT0FBTzBCLEtBQVAsQ0FBYUMsTUFBYixDQUFvQjtBQUM5QkMsUUFBS0o7QUFEeUIsR0FBcEIsRUFFVjtBQUNBSyxTQUFNO0FBQ0YsbUNBQStCO0FBRDdCO0FBRE4sR0FGVSxFQU1WO0FBQ0FDLFVBQU87QUFEUCxHQU5VLENBQWI7QUFTQSxTQUFPTCxNQUFQO0FBQ0MsRUFiYztBQWViTSxpQkFBZ0IsVUFBVXBFLE1BQVYsRUFBaUJxRSxPQUFqQixFQUEwQjtBQUN6QyxNQUFJQyxVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNBLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLGlCQUFZRztBQUFiO0FBREwsSUFGUyxDQUFiO0FBS0UsR0FORCxNQU1LO0FBQ0wsT0FBSVAsU0FBUXJELFNBQVN1QyxNQUFULENBQWdCO0FBQzFCeUIsY0FBU0osT0FEaUI7QUFFcEJwRSxhQUFRRCxNQUZZO0FBR3BCMEUsZUFBVyxJQUFJQyxJQUFKLEVBSFMsQ0FHQzs7QUFIRCxJQUFoQixDQUFaO0FBS0M7O0FBQ0EsU0FBT2IsTUFBUDtBQUNELEVBL0JZO0FBaUNiYyxvQkFBbUIsVUFBVTVFLE1BQVYsRUFBaUI2RSxTQUFqQixFQUE0QjtBQUM5QyxNQUFJUCxVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNBLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLGNBQVNXO0FBQVY7QUFETCxJQUZTLENBQWI7QUFLRSxHQU5ELE1BTUs7QUFDTCxPQUFJZixTQUFRckQsU0FBU3VDLE1BQVQsQ0FBZ0I7QUFDMUI4QixXQUFNRCxTQURvQjtBQUVwQjVFLGFBQVFELE1BRlk7QUFHcEIwRSxlQUFVLElBQUlDLElBQUosRUFIVSxDQUdDOztBQUhELElBQWhCLENBQVo7QUFLQzs7QUFDQSxTQUFPYixNQUFQO0FBQ0QsRUFqRFk7QUFrRFppQixzQkFBcUIsVUFBVS9FLE1BQVYsRUFBaUJnRixPQUFqQixFQUEwQkMsTUFBMUIsRUFBa0NDLE1BQWxDLEVBQTBDQyxRQUExQyxFQUFvREMsWUFBcEQsRUFBa0U7QUFDdkYsTUFBSWQsVUFBVXhELFlBQVl5RCxJQUFaLENBQWlCO0FBQUMsY0FBVXZFO0FBQVgsR0FBakIsRUFBcUN3RSxLQUFyQyxFQUFkOztBQUNBLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFRaEQsWUFBWWtELE1BQVosQ0FBbUI7QUFDNUIvRCxhQUFTRDtBQURtQixJQUFuQixFQUVSO0FBQ0RrRSxVQUFNO0FBQ0wsZ0JBQVdjLE9BRE47QUFFTCxlQUFVQyxNQUZMO0FBR0wsZUFBVUMsTUFITDtBQUlMLGlCQUFZQyxRQUpQO0FBS0wscUJBQWdCQztBQUxYO0FBREwsSUFGUSxDQUFaO0FBWUUsR0FiRCxNQWFLO0FBRU4sT0FBSXRCLFNBQVFoRCxZQUFZa0MsTUFBWixDQUFtQjtBQUN0Qi9DLGFBQVNELE1BRGE7QUFFdEJnRixhQUFTQSxPQUZhO0FBRzFCQyxZQUFRQSxNQUhrQjtBQUkxQkMsWUFBUUEsTUFKa0I7QUFLMUJDLGNBQVVBLFFBTGdCO0FBTTFCQyxrQkFBY0EsWUFOWTtBQU90QlYsZUFBVyxJQUFJQyxJQUFKLEVBUFcsQ0FPQTs7QUFQQSxJQUFuQixDQUFaO0FBV0EsT0FBSUwsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxlQUFVdkU7QUFBWCxJQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDRyxPQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsUUFBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxVQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxLQUFoQixFQUVUO0FBQ0RDLFdBQU07QUFBQyxxQkFBZTtBQUFoQjtBQURMLEtBRlMsQ0FBYjtBQUtFO0FBSUY7O0FBRUEsU0FBT0osTUFBUDtBQUNELEVBNUZZO0FBNkZidUIsb0JBQWtCLFVBQVNyRixNQUFULEVBQWdCc0YsV0FBaEIsRUFBNEI7QUFDOUMsTUFBSWhCLFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsY0FBVXZFO0FBQVgsR0FBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0MsTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQUMsb0JBQWVvQjtBQUFoQjtBQURMLElBRlMsQ0FBYjtBQUtFLEdBTkQsTUFNSztBQUVMLE9BQUl4QixTQUFRckQsU0FBU3VDLE1BQVQsQ0FBZ0I7QUFDMUJzQyxpQkFBWUEsV0FEYztBQUVwQnJGLGFBQVFELE1BRlk7QUFHcEIwRSxlQUFVLElBQUlDLElBQUosRUFIVSxDQUdDOztBQUhELElBQWhCLENBQVo7QUFNQzs7QUFDRCxTQUFPYixNQUFQO0FBQ0EsRUEvR1k7QUFpSGJ5QixrQkFBZ0IsVUFBU3ZGLE1BQVQsRUFBZ0J3RixRQUFoQixFQUF5QjtBQUN6QyxNQUFJbEIsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDQyxNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxpQkFBWXNCO0FBQWI7QUFETCxJQUZTLENBQWI7QUFLRSxHQU5ELE1BTUs7QUFDTCxPQUFJMUIsU0FBUXJELFNBQVN1QyxNQUFULENBQWdCO0FBQzFCd0MsY0FBU0EsUUFEaUI7QUFFcEJ2RixhQUFRRCxNQUZZO0FBR3BCeUYsa0JBQWMsQ0FITTtBQUlwQmYsZUFBVSxJQUFJQyxJQUFKLEVBSlUsQ0FJQzs7QUFKRCxJQUFoQixDQUFaO0FBT0M7O0FBQ0QsU0FBT2IsTUFBUDtBQUNBLEVBbklZO0FBcUliNEIsaUJBQWUsVUFBUzFGLE1BQVQsRUFBZ0IyRixPQUFoQixFQUF3QjtBQUN2QyxNQUFJckIsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDQyxNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxnQkFBV3lCO0FBQVo7QUFETCxJQUZTLENBQWI7QUFLRSxHQU5ELE1BTUs7QUFDTCxPQUFJN0IsU0FBUXJELFNBQVN1QyxNQUFULENBQWdCO0FBQzFCMkMsYUFBUUEsT0FEa0I7QUFFcEIxRixhQUFRRCxNQUZZO0FBR3BCMEUsZUFBVSxJQUFJQyxJQUFKLEVBSFUsQ0FHQzs7QUFIRCxJQUFoQixDQUFaO0FBS0M7O0FBQ0QsU0FBT2IsTUFBUDtBQUNBLEVBckpZO0FBdUpiOEIsY0FBWSxVQUFTQyxNQUFULEVBQWdCQyxNQUFoQixFQUF1QmpDLElBQXZCLEVBQTRCa0MsS0FBNUIsRUFBa0M7QUFDN0MsTUFBSWpDLFNBQVFyRCxTQUFTdUMsTUFBVCxDQUFnQjtBQUMxQmEsU0FBTUEsSUFEb0I7QUFFcEJrQyxVQUFPQSxLQUZhO0FBR3BCOUYsWUFBUzRGLE1BSFc7QUFJcEJDLFdBQVFBLE1BSlk7QUFLcEJFLGlCQUFjLENBTE07QUFNcEJ0QixjQUFVLElBQUlDLElBQUosRUFOVSxDQU1DOztBQU5ELEdBQWhCLENBQVo7QUFTQSxTQUFPYixNQUFQO0FBQ0EsRUFsS1k7QUFvS1BtQyxpQkFBZ0IsVUFBU0MsT0FBVCxFQUFpQkMsT0FBakIsRUFBeUJDLEtBQXpCLEVBQStCO0FBQ25ELE1BQUl0QyxTQUFTL0MsY0FBY2lDLE1BQWQsQ0FBcUI7QUFDakNxRCxXQUFRRCxLQUR5QjtBQUVqQ0YsWUFBU0EsT0FGd0I7QUFHakNDLFlBQVNBLE9BSHdCO0FBSWpDRyxlQUFZLENBSnFCO0FBS2pDQyxnQkFBYSxJQUFJNUIsSUFBSixFQUxvQjtBQU1qQzZCLGNBQVcsSUFBSTdCLElBQUo7QUFOc0IsR0FBckIsQ0FBYjtBQVFFLFNBQU9iLE1BQVA7QUFDRSxFQTlLTztBQWdMUjJDLGlCQUFnQixVQUFTTixPQUFULEVBQWlCRCxPQUFqQixFQUF5QlEsWUFBekIsRUFBc0M7QUFDekQsTUFBSTVDLFNBQVMvQyxjQUFjaUQsTUFBZCxDQUFxQjtBQUNqQ21DLFlBQVNBLE9BRHdCO0FBRWpDRCxZQUFTQTtBQUZ3QixHQUFyQixFQUdYO0FBQ0RoQyxTQUFNO0FBQUMsa0JBQWN3QyxZQUFmO0FBQTRCLGlCQUFhLElBQUkvQixJQUFKO0FBQXpDO0FBREwsR0FIVyxDQUFiO0FBTUEsU0FBT2IsTUFBUDtBQUNBLEVBeExXO0FBMExWNkMsbUJBQWtCLFVBQVM5QyxJQUFULEVBQWMrQyxNQUFkLEVBQXFCQyxjQUFyQixFQUFvQy9CLEtBQXBDLEVBQTBDZ0MsVUFBMUMsRUFBcURDLFlBQXJELEVBQWtFOUcsT0FBbEUsRUFDbEI7QUFDRCxNQUFJNkQsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQUMsY0FBVy9EO0FBQVosR0FBaEIsRUFBcUM7QUFBQ2lFLFNBQU07QUFBQyxZQUFRTCxJQUFUO0FBQWMsY0FBVStDLE1BQXhCO0FBQ25ELHNCQUFrQkMsY0FEaUM7QUFDbEIsYUFBUy9CLEtBRFM7QUFDSCxXQUFPZ0MsVUFESjtBQUVuRCxnQkFBWUM7QUFGdUM7QUFBUCxHQUFyQyxDQUFiO0FBR0YsU0FBT2pELE1BQVA7QUFDQyxFQWhNWTtBQWtNVmtELG1CQUFrQixVQUFTL0csT0FBVCxFQUFpQmdILE1BQWpCLEVBQXdCQyxLQUF4QixFQUE4QkMsTUFBOUIsRUFBcUNDLEtBQXJDLEVBQTJDQyxlQUEzQyxFQUEyREMsY0FBM0QsRUFBMEVDLGFBQTFFLEVBQXdGQyxZQUF4RixFQUFxR0MsWUFBckcsRUFDbEI7QUFDRCxNQUFJM0QsU0FBU2xELFFBQVFvQyxNQUFSLENBQWU7QUFBQyxjQUFXL0MsT0FBWjtBQUFvQixhQUFVZ0gsTUFBOUI7QUFBcUMsWUFBU0MsS0FBOUM7QUFDdEIsYUFBVUMsTUFEWTtBQUNMLFlBQVNDLEtBREo7QUFDVSxzQkFBbUJDLGVBRDdCO0FBRXRCLHFCQUFrQkMsY0FGSTtBQUVXLG9CQUFpQkMsYUFGNUI7QUFFMEMsbUJBQWdCQyxZQUYxRDtBQUV1RSxtQkFBZ0JDO0FBRnZGLEdBQWYsQ0FBYjtBQUdGLFNBQU8zRCxNQUFQO0FBQ0MsRUF4TVk7QUEwTVY0RCxnQkFBZSxVQUFTQyxZQUFULEVBQXNCQyxTQUF0QixFQUFnQ0MsV0FBaEMsRUFBNENDLFVBQTVDLEVBQXVEQyxTQUF2RCxFQUFpRUMsUUFBakUsRUFBMEVDLFlBQTFFLEVBQXVGQyxVQUF2RixFQUFrR0Msb0JBQWxHLEVBQXVIQyxRQUF2SCxFQUFnSW5JLE9BQWhJLEVBQ2Y7QUFDRCxNQUFJNkQsU0FBU25ELFdBQVdxQyxNQUFYLENBQWtCO0FBQzFCL0MsWUFBU0EsT0FEaUI7QUFFMUJvSSxZQUFTVixZQUZpQjtBQUcxQlcsVUFBT1YsU0FIbUI7QUFJMUJDLGdCQUFhQSxXQUphO0FBSzFCQyxlQUFZQSxVQUxjO0FBTTFCQyxjQUFXQSxTQU5lO0FBTzFCQyxhQUFVQSxRQVBnQjtBQVExQnZELGFBQVV3RCxZQVJnQjtBQVMxQk0sVUFBT0wsVUFUbUI7QUFVMUJDLHlCQUFzQkEsb0JBVkk7QUFXMUJDLGFBQVVBLFFBWGdCO0FBWTFCMUQsY0FBVyxJQUFJQyxJQUFKO0FBWmUsR0FBbEIsQ0FBYjtBQWNGLFNBQU9iLE1BQVA7QUFDQyxFQTNOWTtBQTZOWjBFLGFBQVksVUFBU3hJLE1BQVQsRUFBZ0J5SSxRQUFoQixFQUEwQkMsV0FBMUIsRUFBc0NDLFNBQXRDLEVBQWdEQyxRQUFoRCxFQUF5REMsWUFBekQsRUFDVjtBQUNELE1BQUkvRSxTQUFTakQsVUFBVW1DLE1BQVYsQ0FBaUI7QUFDekIvQyxZQUFTRCxNQURnQjtBQUV6QjhJLFNBQU1MLFFBRm1CO0FBR3pCQyxnQkFBYUEsV0FIWTtBQUl6QkMsY0FBV0EsU0FKYztBQUt6QkMsYUFBVUEsUUFMZTtBQU16Qm5FLGFBQVVvRSxZQU5lO0FBT3pCbkUsY0FBVyxJQUFJQyxJQUFKO0FBUGMsR0FBakIsQ0FBYjtBQVNGLFNBQU9iLE1BQVA7QUFDQyxFQXpPWTtBQTJPWmlGLGFBQVksVUFBUy9JLE1BQVQsRUFBZ0JnSixPQUFoQixFQUF3QlAsUUFBeEIsRUFBa0NDLFdBQWxDLEVBQThDQyxTQUE5QyxFQUF3REMsUUFBeEQsRUFBaUVDLFlBQWpFLEVBQ1Y7QUFDSCxNQUFJL0UsU0FBU2pELFVBQVVtRCxNQUFWLENBQWlCO0FBQzNCQyxRQUFLK0U7QUFEc0IsR0FBakIsRUFFVDtBQUNEOUUsU0FBTTtBQUNBLFlBQVF1RSxRQURSO0FBRUMsbUJBQWVDLFdBRmhCO0FBR0MsaUJBQWFDLFNBSGQ7QUFJQyxnQkFBWUMsUUFKYjtBQUtDLGdCQUFZQyxZQUxiO0FBTUMsaUJBQWEsSUFBSWxFLElBQUo7QUFOZDtBQURMLEdBRlMsQ0FBYjtBQVlBLFNBQU9iLE1BQVA7QUFDQyxFQTFQWTtBQTRQWG1GLGVBQWMsVUFBU2pKLE1BQVQsRUFBZ0JrSixVQUFoQixFQUEyQkMsU0FBM0IsRUFBcUNDLFVBQXJDLEVBQ2I7QUFDSCxNQUFJdEYsU0FBU3BELFVBQVVzQyxNQUFWLENBQWlCO0FBQ3ZCL0MsWUFBU0QsTUFEYztBQUV2QmtKLGVBQVlBLFVBRlc7QUFHdkJDLGNBQVdBLFNBSFk7QUFJdkJDLGVBQVlBLFVBSlc7QUFLdkIxRSxjQUFXLElBQUlDLElBQUo7QUFMWSxHQUFqQixDQUFiO0FBT0EsU0FBTyxJQUFQO0FBQ0MsRUF0UVk7QUF3UVgwRSxlQUFjLFVBQVNMLE9BQVQsRUFBaUJFLFVBQWpCLEVBQTRCQyxTQUE1QixFQUFzQ0MsVUFBdEMsRUFDYjtBQUNILE1BQUl0RixTQUFTcEQsVUFBVXNELE1BQVYsQ0FBaUI7QUFDM0JDLFFBQUsrRTtBQURzQixHQUFqQixFQUVUO0FBQ0Q5RSxTQUFNO0FBQ0RnRixnQkFBWUEsVUFEWDtBQUVEQyxlQUFXQSxTQUZWO0FBR0RDLGdCQUFZQSxVQUhYO0FBSUQxRSxlQUFXLElBQUlDLElBQUo7QUFKVjtBQURMLEdBRlMsQ0FBYjtBQVVBLFNBQU8sSUFBUDtBQUNDLEVBclJZO0FBc1JiMkUsZ0JBQWUsVUFBU04sT0FBVCxFQUFpQnJCLFlBQWpCLEVBQThCQyxTQUE5QixFQUF3Q0MsV0FBeEMsRUFBb0RDLFVBQXBELEVBQStEQyxTQUEvRCxFQUF5RUMsUUFBekUsRUFBa0ZDLFlBQWxGLEVBQ1BDLFVBRE8sRUFDSUMsb0JBREosRUFDeUJDLFFBRHpCLEVBRVo7QUFDSCxNQUFJdEUsU0FBU25ELFdBQVdxRCxNQUFYLENBQWtCO0FBQ3JCQyxRQUFLK0U7QUFEZ0IsR0FBbEIsRUFHSDtBQUNKOUUsU0FBTTtBQUNMbUUsYUFBU1YsWUFESjtBQUVMVyxXQUFPVixTQUZGO0FBR0xDLGlCQUFhQSxXQUhSO0FBSUxDLGdCQUFZQSxVQUpQO0FBTUxDLGVBQVdBLFNBTk47QUFPTEMsY0FBVUEsUUFQTDtBQVFMdkQsY0FBVXdELFlBUkw7QUFTTE0sV0FBT0wsVUFURjtBQVVMRSxjQUFVQSxRQVZMO0FBV0xELDBCQUFzQkEsb0JBWGpCO0FBWUwzQixlQUFXLElBQUk3QixJQUFKO0FBWk47QUFERixHQUhHLENBQWI7QUFrQkEsU0FBTyxJQUFQO0FBQ0MsRUE1U1k7QUE4U2I0RSxrQkFBaUIsVUFBU1AsT0FBVCxFQUFpQnJCLFlBQWpCLEVBQThCQyxTQUE5QixFQUF3Q0MsV0FBeEMsRUFBb0RFLFNBQXBELEVBQThERSxZQUE5RCxFQUNUQyxVQURTLEVBQ0VDLG9CQURGLEVBQ3VCQyxRQUR2QixFQUVkO0FBQ0gsTUFBSXRFLFNBQVNuRCxXQUFXcUQsTUFBWCxDQUFrQjtBQUNyQkMsUUFBSytFO0FBRGdCLEdBQWxCLEVBR0g7QUFDSjlFLFNBQU07QUFDTG1FLGFBQVNWLFlBREo7QUFFTFcsV0FBT1YsU0FGRjtBQUdMQyxpQkFBYUEsV0FIUjtBQUlMQyxnQkFBWUEsVUFKUDtBQU1MckQsY0FBVXdELFlBTkw7QUFPTE0sV0FBT0wsVUFQRjtBQVFMRSxjQUFVQSxRQVJMO0FBU0xELDBCQUFzQkEsb0JBVGpCO0FBVUwzQixlQUFXLElBQUk3QixJQUFKO0FBVk47QUFERixHQUhHLENBQWI7QUFnQkEsU0FBTyxJQUFQO0FBQ0MsRUFsVVk7QUFxVWI2RSxtQkFBa0IsVUFBU1IsT0FBVCxFQUFpQi9CLE1BQWpCLEVBQXdCQyxLQUF4QixFQUE4QkMsTUFBOUIsRUFBcUNDLEtBQXJDLEVBQTJDQyxlQUEzQyxFQUEyREMsY0FBM0QsRUFBMEVDLGFBQTFFLEVBQXdGQyxZQUF4RixFQUFxR0MsWUFBckcsRUFDZjtBQUVILE1BQUkzRCxTQUFTbEQsUUFBUW9ELE1BQVIsQ0FBZTtBQUNsQkMsUUFBSytFO0FBRGEsR0FBZixFQUlIO0FBQ0o5RSxTQUFNO0FBQUMsY0FBVStDLE1BQVg7QUFBa0IsYUFBU0MsS0FBM0I7QUFDSixjQUFVQyxNQUROO0FBQ2EsYUFBU0MsS0FEdEI7QUFDNEIsdUJBQW1CQyxlQUQvQztBQUVKLHNCQUFrQkMsY0FGZDtBQUU2QixxQkFBaUJDLGFBRjlDO0FBRTRELG9CQUFnQkMsWUFGNUU7QUFFeUYsb0JBQWdCQztBQUZ6RztBQURGLEdBSkcsQ0FBYjtBQVNBLFNBQU8sSUFBUDtBQUNDLEVBbFZZO0FBbVZQZ0MscUJBQW9CLFVBQVN4SixPQUFULEVBQWlCeUosU0FBakIsRUFDdkI7QUFDSCxNQUFJNUYsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCL0QsWUFBU0E7QUFEaUIsR0FBaEIsRUFFVDtBQUNEaUUsU0FBTTtBQUNBLG1CQUFld0YsU0FEZjtBQUVDLG9CQUFnQixJQUFJL0UsSUFBSjtBQUZqQjtBQURMLEdBRlMsQ0FBYjtBQVFBLFNBQU9iLE1BQVA7QUFDQyxFQTlWWTtBQWdXYjZGLHVCQUFzQixVQUFTMUosT0FBVCxFQUFpQnlKLFNBQWpCLEVBQ25CO0FBQ0gsTUFBSTVGLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQi9ELFlBQVNBO0FBRGlCLEdBQWhCLEVBRVQ7QUFDRGlFLFNBQU07QUFDQSxtQkFBZXdGLFNBRGY7QUFFQyxvQkFBZ0IsSUFBSS9FLElBQUo7QUFGakI7QUFETCxHQUZTLENBQWI7QUFRQSxTQUFPYixNQUFQO0FBQ0MsRUEzV1k7QUE2V1A4RixpQkFBZ0IsVUFBU3pELE9BQVQsRUFBaUJELE9BQWpCLEVBQXlCMkQsUUFBekIsRUFBa0NDLE1BQWxDLEVBQXlDQyxXQUF6QyxFQUFxREMsVUFBckQsRUFDbkI7QUFDSCxNQUFJbEcsU0FBUzlDLFFBQVFnQyxNQUFSLENBQWU7QUFDM0I4RyxXQUFRQSxNQURtQjtBQUVyQjNELFlBQVNBLE9BRlk7QUFHckJELFlBQVNBLE9BSFk7QUFJckI2RCxnQkFBWUEsV0FKUztBQUtyQkYsYUFBVUEsUUFMVztBQU1yQkksaUJBQWNELFVBTk87QUFPckJFLFdBQVEsSUFBSXZGLElBQUo7QUFQYSxHQUFmLENBQWI7QUFTQSxTQUFPLElBQVA7QUFDQyxFQXpYWTtBQTRYUHdGLDBCQUF5QixVQUFTaEUsT0FBVCxFQUFpQkQsT0FBakIsRUFBeUI4RCxVQUF6QixFQUFvQ0YsTUFBcEMsRUFDNUI7QUFDSCxNQUFJaEcsU0FBUzlDLFFBQVFnQyxNQUFSLENBQWU7QUFDM0I4RyxXQUFRQSxNQURtQjtBQUVyQjNELFlBQVNBLE9BRlk7QUFHckJELFlBQVNBLE9BSFk7QUFJckIyRCxhQUFVLENBSlc7QUFLckJJLGlCQUFjRCxVQUxPO0FBTXJCRSxXQUFRLElBQUl2RixJQUFKO0FBTmEsR0FBZixDQUFiO0FBUUEsU0FBTyxJQUFQO0FBQ0MsRUF2WVk7QUF5WWJ5RixpQ0FBZ0MsVUFBU04sTUFBVCxFQUFnQjVELE9BQWhCLEVBQXdCQyxPQUF4QixFQUFnQ2tFLFdBQWhDLEVBQTRDQyxXQUE1QyxFQUF3REMsTUFBeEQsRUFDN0I7QUFDSCxNQUFJekcsU0FBUzlDLFFBQVFnQyxNQUFSLENBQWU7QUFDM0I4RyxXQUFRQSxNQURtQjtBQUVyQjNELFlBQVNBLE9BRlk7QUFHckJELFlBQVNBLE9BSFk7QUFJckIyRCxhQUFVLENBSlc7QUFLckJJLGlCQUFjLENBTE87QUFNckJPLG9CQUFpQkgsV0FOSTtBQU9yQkksb0JBQWlCSCxXQVBJO0FBUXJCQyxXQUFRQSxNQVJhO0FBU3JCTCxXQUFRLElBQUl2RixJQUFKO0FBVGEsR0FBZixDQUFiO0FBV0EsU0FBTyxJQUFQO0FBQ0MsRUF2Wlk7QUF5WmIrRix1QkFBc0IsVUFBU3pLLE9BQVQsRUFBaUIwSyxTQUFqQixFQUEyQkMsU0FBM0IsRUFBcUNDLFFBQXJDLEVBQThDQyxlQUE5QyxFQUE4REMsY0FBOUQsRUFBNkV4SyxNQUE3RSxFQUNuQjtBQUNILE1BQUl1RCxTQUFTN0MsVUFBVStCLE1BQVYsQ0FBaUI7QUFDN0J6QyxXQUFRQSxNQURxQjtBQUU3QnFLLGNBQVdBLFNBRmtCO0FBRzdCSSxVQUFPL0ssT0FIc0I7QUFJdkI0SyxhQUFVQSxRQUphO0FBS3ZCQyxvQkFBaUJBLGVBTE07QUFNdkJDLG1CQUFnQkEsY0FOTztBQU92QkosY0FBV0EsU0FQWTtBQVF2Qk0sb0JBQWlCLENBUk07QUFTdkJ2RyxjQUFXLElBQUlDLElBQUo7QUFUWSxHQUFqQixDQUFiO0FBV0EsU0FBTyxJQUFQO0FBQ0MsRUF2YVk7QUF5YWJ1Ryx1QkFBc0IsVUFBU2pMLE9BQVQsRUFBaUIwSyxTQUFqQixFQUEyQkMsU0FBM0IsRUFBcUNDLFFBQXJDLEVBQThDQyxlQUE5QyxFQUNyQkMsY0FEcUIsRUFDTnhLLE1BRE0sRUFDQzBLLGVBREQsRUFFbkI7QUFDSCxNQUFJbkgsU0FBUzdDLFVBQVUrQyxNQUFWLENBQWlCO0FBQzNCekQsV0FBUUE7QUFEbUIsR0FBakIsRUFFVDtBQUNEMkQsU0FBTTtBQUNJMEcsZUFBV0EsU0FEZjtBQUVMSSxXQUFPL0ssT0FGRjtBQUdDNEssY0FBVUEsUUFIWDtBQUlDQyxxQkFBaUJBLGVBSmxCO0FBS0NDLG9CQUFnQkEsY0FMakI7QUFNQ0osZUFBV0EsU0FOWjtBQU9DTSxxQkFBaUJBLGVBUGxCO0FBUUNFLGVBQVcsSUFBSXhHLElBQUo7QUFSWjtBQURMLEdBRlMsQ0FBYjtBQWNBLFNBQU8sSUFBUDtBQUNDLEVBM2JZO0FBNmJUeUcsWUFBVyxVQUFVcEwsTUFBVixFQUFrQitGLEtBQWxCLEVBQXlCO0FBQzlCekQsUUFBTStJLElBQU4sQ0FBV3RGLEtBQVg7QUFDSCxFQS9iTTtBQWljUHVGLHdCQUF1QixVQUFTL0ssTUFBVCxFQUFnQjBLLGVBQWhCLEVBQzFCO0FBQ0gsTUFBSW5ILFNBQVM3QyxVQUFVK0MsTUFBVixDQUFpQjtBQUMzQnpELFdBQVFBO0FBRG1CLEdBQWpCLEVBRVQ7QUFDRDJELFNBQU07QUFDQSx1QkFBbUIrRyxlQURuQjtBQUVDLG9CQUFnQixJQUFJdEcsSUFBSjtBQUZqQjtBQURMLEdBRlMsQ0FBYjtBQVFBLFNBQU9iLE1BQVA7QUFDQyxFQTVjWTtBQTZjYnlILHNCQUFvQixVQUFTdkwsTUFBVCxFQUFnQmdHLFlBQWhCLEVBQTZCO0FBQ3pDLE1BQUkxQixVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNKLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLHFCQUFnQjtBQUFqQjtBQURMLElBRlMsQ0FBYjtBQUtFOztBQUNBLFNBQU9KLE1BQVA7QUFDRSxFQXZkTTtBQXdkYjBILG9CQUFrQixVQUFTeEwsTUFBVCxFQUFnQnlMLFdBQWhCLEVBQTRCO0FBQ3RDLE1BQUluSCxVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNKLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLG9CQUFldUg7QUFBaEI7QUFETCxJQUZTLENBQWI7QUFLRTs7QUFDQSxTQUFPM0gsTUFBUDtBQUNFLEVBbGVNO0FBbWViNEgsMEJBQXdCLFVBQVMxTCxNQUFULEVBQWdCeUwsV0FBaEIsRUFBNEI7QUFDNUMsTUFBSW5ILFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsY0FBVXZFO0FBQVgsR0FBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0osTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQUMsb0JBQWV1SDtBQUFoQjtBQURMLElBRlMsQ0FBYjtBQUtFOztBQUNBLFNBQU8zSCxNQUFQO0FBQ0UsRUE3ZU07QUErZWI2SCxzQkFBb0IsVUFBU2xHLFlBQVQsRUFBc0J6RixNQUF0QixFQUE2QjtBQUN6QyxNQUFJc0UsVUFBVTdELFNBQVM4RCxJQUFULENBQWM7QUFBQyxjQUFVdkU7QUFBWCxHQUFkLEVBQWtDd0UsS0FBbEMsRUFBZDs7QUFDSixNQUFHRixRQUFRLENBQVIsQ0FBSCxFQUFjO0FBQ2YsT0FBSVIsU0FBU3JELFNBQVN1RCxNQUFULENBQWdCO0FBQzFCQyxTQUFLSyxRQUFRLENBQVIsRUFBV0w7QUFEVSxJQUFoQixFQUVUO0FBQ0RDLFVBQU07QUFBQyxxQkFBZ0J1QjtBQUFqQjtBQURMLElBRlMsQ0FBYjtBQUtFOztBQUNBLFNBQU8zQixNQUFQO0FBQ0UsRUF6Zk07QUEyZmI4SCxpQkFBZSxVQUFTNUwsTUFBVCxFQUFnQjZMLE9BQWhCLEVBQXdCO0FBQy9CLE1BQUl2SCxVQUFVN0QsU0FBUzhELElBQVQsQ0FBYztBQUFDLGNBQVV2RTtBQUFYLEdBQWQsRUFBa0N3RSxLQUFsQyxFQUFkOztBQUNKLE1BQUdGLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTckQsU0FBU3VELE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUFDLGdCQUFXMkg7QUFBWjtBQURMLElBRlMsQ0FBYjtBQUtFOztBQUNBLFNBQU8vSCxNQUFQO0FBQ0UsRUFyZ0JNO0FBdWdCUGdJLGVBQWEsVUFBU0MsUUFBVCxFQUFrQjtBQUMxQixNQUFJakksU0FBU3BELFVBQVVvQyxNQUFWLENBQWlCO0FBQUNtQixRQUFLOEg7QUFBTixHQUFqQixDQUFiO0FBQ04sU0FBT2pJLE1BQVA7QUFDRSxFQTFnQk07QUEyZ0JQa0ksZUFBYSxVQUFTQyxNQUFULEVBQWdCO0FBQ3hCLE1BQUluSSxTQUFTakQsVUFBVWlDLE1BQVYsQ0FBaUI7QUFBQ21CLFFBQUtnSTtBQUFOLEdBQWpCLENBQWI7QUFDTixTQUFPbkksTUFBUDtBQUNFLEVBOWdCTTtBQStnQlBvSSxnQkFBYyxVQUFTQyxTQUFULEVBQW1CO0FBQzVCLE1BQUlySSxTQUFTbkQsV0FBV21DLE1BQVgsQ0FBa0I7QUFBQ21CLFFBQUtrSTtBQUFOLEdBQWxCLENBQWI7QUFDTixTQUFPckksTUFBUDtBQUNFLEVBbGhCTTtBQW1oQlBzSSxtQkFBaUIsVUFBU0MsTUFBVCxFQUFnQjtBQUM1QixNQUFJdkksU0FBU2xELFFBQVFrQyxNQUFSLENBQWU7QUFBQ21CLFFBQUtvSTtBQUFOLEdBQWYsQ0FBYjtBQUNOLFNBQU92SSxNQUFQO0FBQ0UsRUF0aEJNO0FBd2hCUHdJLHVCQUFxQixVQUFTbkcsT0FBVCxFQUFpQjVGLE1BQWpCLEVBQXdCO0FBQ3hDLE1BQUl1RCxTQUFTNUMsYUFBYTRCLE1BQWIsQ0FBb0I7QUFBQ3FELFlBQVNBLE9BQVY7QUFBbUI1RixXQUFRQTtBQUEzQixHQUFwQixDQUFiO0FBQ04sU0FBT3VELE1BQVA7QUFDRSxFQTNoQk07QUE2aEJQeUksdUJBQXFCLFVBQVNsRyxNQUFULEVBQWdCRixPQUFoQixFQUF3QjVGLE1BQXhCLEVBQStCaU0sTUFBL0IsRUFBc0M7QUFDekQsTUFBSTFJLFNBQVM1QyxhQUFhOEIsTUFBYixDQUFvQjtBQUMvQnFELFdBQVFBLE1BRHVCO0FBRS9CRixZQUFTQSxPQUZzQjtBQUcvQjVGLFdBQVFBLE1BSHVCO0FBSS9CaU0sV0FBUUEsTUFKdUI7QUFLL0J0QyxXQUFRLElBQUl2RixJQUFKO0FBTHVCLEdBQXBCLENBQWI7QUFPSCxTQUFPYixNQUFQO0FBQ0UsRUF0aUJNO0FBd2lCUDJJLGtCQUFnQixVQUFTMUMsV0FBVCxFQUFxQjJDLEtBQXJCLEVBQTJCQyxLQUEzQixFQUFpQ0MsUUFBakMsRUFBMENDLFdBQTFDLEVBQXNEQyxnQkFBdEQsRUFBdUVDLGNBQXZFLEVBQ3hCQyxnQkFEd0IsRUFDUDtBQUNQLE1BQUkxSSxVQUFVbkQsU0FBU29ELElBQVQsQ0FBYztBQUFDd0YsZ0JBQWFBO0FBQWQsR0FBZCxFQUEwQ3ZGLEtBQTFDLEVBQWQ7QUFDSixNQUFJeUksaUJBQWlCak0sUUFBUXVELElBQVIsQ0FBYTtBQUFDLGtCQUFjd0Y7QUFBZixHQUFiLEVBQTBDbUQsS0FBMUMsRUFBckI7O0FBQ0EsTUFBRzVJLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTM0MsU0FBUzZDLE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUNGK0kscUJBQWVBLGlCQUFlLENBRDVCO0FBRVFMLGVBQVVBLFFBRmxCO0FBR1FDLGtCQUFZQSxXQUhwQjtBQUlRTSxvQkFBZXhJLEtBQUt5SSxHQUFMLEVBSnZCO0FBS0VOLHVCQUFrQkEsZ0JBTHBCO0FBTUVDLHFCQUFnQkEsY0FObEI7QUFPRUMsdUJBQWtCQTtBQVBwQjtBQURMLElBRlMsQ0FBYjtBQWNFLEdBZkQsTUFnQkk7QUFDSCxPQUFJbEosU0FBUzNDLFNBQVM2QixNQUFULENBQWdCO0FBQ3BCK0csaUJBQWFBLFdBRE87QUFFcEIyQyxXQUFjQSxLQUZNO0FBR3BCQyxXQUFjQSxLQUhNO0FBSXBCRSxpQkFBYUEsV0FKTztBQUtwQkQsY0FBVUEsUUFMVTtBQU1wQk8sbUJBQWV4SSxLQUFLeUksR0FBTCxFQU5LO0FBT3BCTixzQkFBa0JBLGdCQVBFO0FBUXBCQyxvQkFBZ0JBLGNBUkk7QUFTcEJDLHNCQUFrQkE7QUFURSxJQUFoQixDQUFiO0FBV0E7O0FBQ0EsU0FBT2xKLE1BQVA7QUFDRSxFQTFrQk07QUE2a0JQdUosMEJBQXdCLFVBQVN0RCxXQUFULEVBQXFCaUQsZ0JBQXJCLEVBQXNDO0FBQzVELE1BQUkxSSxVQUFVbkQsU0FBU29ELElBQVQsQ0FBYztBQUFDd0YsZ0JBQWFBO0FBQWQsR0FBZCxFQUEwQ3ZGLEtBQTFDLEVBQWQ7O0FBQ0osTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVMzQyxTQUFTNkMsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQ1k4SSx1QkFBa0JBO0FBRDlCO0FBREwsSUFGUyxDQUFiO0FBT0U7O0FBQ0EsU0FBT2xKLE1BQVA7QUFDRSxFQXpsQk07QUEwbEJQd0osNEJBQTBCLFVBQVN0TixNQUFULEVBQWdCd00sTUFBaEIsRUFBdUI7QUFDaEQsTUFBSWxJLFVBQVU3RCxTQUFTOEQsSUFBVCxDQUFjO0FBQUMsY0FBVXZFO0FBQVgsR0FBZCxFQUFrQ3dFLEtBQWxDLEVBQWQ7O0FBQ0YsTUFBR0YsUUFBUSxDQUFSLENBQUgsRUFBYztBQUNmLE9BQUlSLFNBQVNyRCxTQUFTdUQsTUFBVCxDQUFnQjtBQUMxQkMsU0FBS0ssUUFBUSxDQUFSLEVBQVdMO0FBRFUsSUFBaEIsRUFFVDtBQUNEQyxVQUFNO0FBQUMsc0JBQWlCc0k7QUFBbEI7QUFETCxJQUZTLENBQWI7QUFLRTs7QUFDRCxTQUFPMUksTUFBUDtBQUNFLEVBcG1CTTtBQXFtQlB5Six3QkFBc0IsVUFBU3hELFdBQVQsRUFBcUJtRCxLQUFyQixFQUEyQjtBQUNoRCxNQUFJNUksVUFBVW5ELFNBQVNvRCxJQUFULENBQWM7QUFBQ3dGLGdCQUFhQTtBQUFkLEdBQWQsRUFBMEN2RixLQUExQyxFQUFkO0FBQ0MsTUFBSWdKLGVBQWEsQ0FBakI7O0FBQ0QsTUFBR2xKLFFBQVEsQ0FBUixFQUFXbUosZ0JBQWQsRUFBK0I7QUFDcENELGtCQUFnQmxKLFFBQVEsQ0FBUixFQUFXbUosZ0JBQVgsR0FBNEIsQ0FBNUM7QUFDTSxHQUZELE1BRUs7QUFDVkQsa0JBQWUsQ0FBZjtBQUNNOztBQUNELE1BQUdOLFNBQVMsQ0FBWixFQUFjO0FBQ3BCTSxrQkFBZSxDQUFmO0FBQ087O0FBQ0osTUFBR2xKLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDZixPQUFJUixTQUFTM0MsU0FBUzZDLE1BQVQsQ0FBZ0I7QUFDMUJDLFNBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLElBQWhCLEVBRVQ7QUFDREMsVUFBTTtBQUNGaUosb0JBQWV4SSxLQUFLeUksR0FBTCxFQURiO0FBRVlLLHVCQUFrQkQ7QUFGOUI7QUFETCxJQUZTLENBQWI7QUFRRTs7QUFDRCxTQUFPMUosTUFBUDtBQUNHLEVBM25CTTtBQTRuQlA0Six5QkFBdUIsVUFBU0MsVUFBVCxFQUFvQm5CLE1BQXBCLEVBQTJCO0FBRWpELE1BQUlsSSxVQUFVdEQsUUFBUXVELElBQVIsQ0FBYTtBQUFDLGFBQVNvSjtBQUFWLEdBQWIsRUFBb0NuSixLQUFwQyxFQUFkOztBQUNBLE1BQUdnSSxVQUFVLE1BQWIsRUFBb0I7QUFDekIsT0FBSWxJLFVBQVV0RCxRQUFRdUQsSUFBUixDQUFhO0FBQUMsbUJBQWNELFFBQVEsQ0FBUixFQUFXeUY7QUFBMUIsSUFBYixFQUFxRHZGLEtBQXJELEVBQWQ7O0FBQ0EsUUFBSSxJQUFJb0osSUFBRSxDQUFWLEVBQVlBLElBQUV0SixRQUFRdUosTUFBdEIsRUFBNkJELEdBQTdCLEVBQWlDO0FBQ2pDLFFBQUk5SixTQUFTOUMsUUFBUWdELE1BQVIsQ0FBZTtBQUMzQkMsVUFBS0ssUUFBUXNKLENBQVIsRUFBVzNKO0FBRFcsS0FBZixFQUVSO0FBQ0pDLFdBQU07QUFBQyx5QkFBbUI7QUFBcEI7QUFERixLQUZRLENBQWI7QUFLQztBQUdLLEdBWEQsTUFXSztBQUNMLE9BQUdJLFFBQVEsQ0FBUixDQUFILEVBQWM7QUFDcEIsUUFBSVIsU0FBUzlDLFFBQVFnRCxNQUFSLENBQWU7QUFDMUJDLFVBQUtLLFFBQVEsQ0FBUixFQUFXTDtBQURVLEtBQWYsRUFFVDtBQUNGQyxXQUFNO0FBQUMseUJBQW1Cc0k7QUFBcEI7QUFESixLQUZTLENBQWI7QUFLQztBQUNNOztBQUVILFNBQU8xSSxNQUFQO0FBQ0U7QUFycEJNLENBQWYsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbmltcG9ydCB7IEJhc2U2NCB9IGZyb20gJ21ldGVvci9vc3RyaW86YmFzZTY0JztcbmltcG9ydCB7IFNlc3Npb24gfSBmcm9tICdtZXRlb3Ivc2Vzc2lvbic7XG5cblJvdXRlci5yb3V0ZSgnL3Byb2ZpbGUnLCBmdW5jdGlvbiAoKSB7XG4gIGlmKFNlc3Npb24uZ2V0KFwidXNlcklkXCIpIT1cIlwiKXtcbiAgdGhpcy5yZW5kZXIoJ3Byb2ZpbGUnKTsgIFxufWVsc2V7XG4gIFJvdXRlci5nbygnLycpOyAgXG59XG59KTtcblxuUm91dGVyLnJvdXRlKCcvdmlld19wcm9maWxlLzp1c2VyX2lkJywgZnVuY3Rpb24gKCkge1xuICAgdmFyICBwYXJhbXMgPSB0aGlzLnBhcmFtczsgLy8geyBfaWQ6IFwiNVwiIH1cbiAgLy8gdmFyIGlkID0gcGFyYW1zLnVzZXJfaWQ7IC8vIFwiNVwiXG5cbiAgICB2YXIgdXNlcklkID0gcGFyYW1zLnVzZXJfaWQ7IC8vIFwiNVwiXG4gICAgdXNlcklkID0gQmFzZTY0LmRlY29kZSh1c2VySWQpOyBcbiAgICAgIC8vIGFsZXJ0KFwiZGVjcnlwdFwiICsgdXNlcklkKTtcbiAgLy8gU2Vzc2lvbi5zZXQoXCJtYWtlVXNlckFjdGl2ZVwiLFwidHJ1ZVwiKTtcbiAgLy8gU2Vzc2lvbi5zZXRQZXJzaXN0ZW50KFwic2hvd19jb25uZWN0aW9uXCIsaGVhZFswXS51c2VyX2lkKTtcbiAgU2Vzc2lvbi5zZXQoXCJzaG93X2Nvbm5lY3Rpb25cIix1c2VySWQpO1x0XG4gIC8vIGFsZXJ0KCdoaScpO1xuICB0aGlzLnJlbmRlcigndmlld19wcm9maWxlJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvJywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignbG9naW4nKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9zaWdudXAnLCBmdW5jdGlvbiAoKSB7XG4gICBpZihTZXNzaW9uLmdldChcInVzZXJJZFwiKSE9XCJcIil7XG4gdGhpcy5yZW5kZXIoJ3NpZ251cCcpO1xufWVsc2V7XG4gIFJvdXRlci5nbygnLycpOyAgXG59XG5cblxufSk7XG5cblJvdXRlci5yb3V0ZSgnL2Nvbm5lY3Rpb24nLCBmdW5jdGlvbiAoKSB7XG4gIHRoaXMucmVuZGVyKCdjb25uZWN0aW9uJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvTWVzc2FnaW5nJywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignbWVzc2FnaW5ncGFnZScpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL2dycGxpc3RpbmcnLCBmdW5jdGlvbiAoKSB7XG4gIHRoaXMucmVuZGVyKCdncnBsaXN0aW5nJyk7XG59KTtcblxuUm91dGVyLnJvdXRlKCcvZ3JvdXBfZGlzY3Vzc2lvbicsIGZ1bmN0aW9uICgpIHtcbiAgdGhpcy5yZW5kZXIoJ2dyb3VwX2Rpc2N1c3Npb24nKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9lbWFpbCcsIGZ1bmN0aW9uICgpIFxueyAgaWYoU2Vzc2lvbi5nZXQoXCJ1c2VySWRcIikhPVwiXCIpe1xuICB0aGlzLnJlbmRlcignZW1haWwnKTtcbn1lbHNle1xuICBSb3V0ZXIuZ28oJy8nKTsgIFxufVxuXG59KTtcblxuUm91dGVyLnJvdXRlKCcvYWN0aXZhdGVfZW1haWwvOmlkJywgZnVuY3Rpb24gKCkge1xuICB2YXIgIHBhcmFtcyA9IHRoaXMucGFyYW1zOyAvLyB7IF9pZDogXCI1XCIgfVxuICB2YXIgdXNlcklkID0gcGFyYW1zLmlkOyAvLyBcIjVcIlxuICAgIHVzZXJJZCA9IEJhc2U2NC5kZWNvZGUodXNlcklkKTsgXG4gICAgICAvLyBhbGVydChcImRlY3J5cHRcIiArIHVzZXJJZCk7XG4gIFNlc3Npb24uc2V0KFwibWFrZVVzZXJBY3RpdmVcIixcInRydWVcIik7XG4gIFNlc3Npb24uc2V0UGVyc2lzdGVudChcInVzZXJJZFwiLHVzZXJJZCk7XG4gIHRoaXMucmVuZGVyKCdlbWFpbCcpO1xuXG5cbn0pO1xuXG5cblxuUm91dGVyLnJvdXRlKCcvY3JlYXRlZ3JvdXAnLCBmdW5jdGlvbiAoKSB7XG4gIHRoaXMucmVuZGVyKCdjcmVhdGVncm91cCcpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL21lc3NhZ2luZ19wYWdlJywgZnVuY3Rpb24gKCkge1xuICB0aGlzLnJlbmRlcignbWVzc2FnaW5nX3BhZ2UnKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9ncm91cGRldGFpbC86Z3JwX2lkJywgZnVuY3Rpb24gKCkge1xuICB2YXIgIHBhcmFtcyA9IHRoaXMucGFyYW1zOyAvLyB7IF9pZDogXCI1XCIgfVxuICB2YXIgZW5jcnlwdGVkID0gcGFyYW1zLmdycF9pZDsgLy8gXCI1XCJcbiAgXG4vLyBkZWNyeXB0ZWQgPSBDcnlwdG9KUy5BRVMuZGVjcnlwdChlbmNyeXB0ZWQsICdQYXNzcGhyYXNlJyk7XG4vLyB2YXIgaWQgPSBkZWNyeXB0ZWQudG9TdHJpbmcoQ3J5cHRvSlMuZW5jLlV0ZjgpO1xuXG5TZXNzaW9uLnNldChcInNob3dfZ3JwX2lkXCIsZW5jcnlwdGVkKTsgIFxuIHRoaXMucmVuZGVyKCdncm91cGRldGFpbCcpO1xufSk7XG5cblJvdXRlci5yb3V0ZSgnL2VkaXRncm91cC86Z3JwX2lkJywgZnVuY3Rpb24gKCkge1xuICB2YXIgIHBhcmFtcyA9IHRoaXMucGFyYW1zOyAvLyB7IF9pZDogXCI1XCIgfVxuICB2YXIgZW5jcnlwdGVkID0gcGFyYW1zLmdycF9pZDsgLy8gXCI1XCJcbiAgXG4vLyBkZWNyeXB0ZWQgPSBDcnlwdG9KUy5BRVMuZGVjcnlwdChlbmNyeXB0ZWQsICdQYXNzcGhyYXNlJyk7XG4vLyB2YXIgaWQgPSBkZWNyeXB0ZWQudG9TdHJpbmcoQ3J5cHRvSlMuZW5jLlV0ZjgpO1xuXG5TZXNzaW9uLnNldChcInNob3dfZ3JwX2VkaXRfaWRcIixlbmNyeXB0ZWQpOyAgXG4gIHRoaXMucmVuZGVyKCdlZGl0Z3JvdXAnKTtcbn0pO1xuXG5Sb3V0ZXIucm91dGUoJy9sb2dvdXQnLCBmdW5jdGlvbiAoKSB7XG4gIHRoaXMucmVuZGVyKCdsb2dpbicpO1xufSk7XG5cbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbiBcbmV4cG9ydCBjb25zdCBVc2VySW5mbyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1c2VyX2luZm8nKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5leHBvcnQgY29uc3QgVXNlclNraWxsID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJfc2tpbGwnKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IFVzZXJQcm9mSnIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcl9wcm9manInKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IFVzZXJFZHUgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcl9lZHUnKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBVc2VyQXdhcmQgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcl9hd2FyZCcpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuZXhwb3J0IGNvbnN0IFVzZXJNZWRpY2FsID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJfbWVkaWNhbCcpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBGcmllbmRSZXF1ZXN0ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZyaWVuZCcpOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBNZXNzYWdlID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ21lc3NhZ2UnKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXG5leHBvcnQgY29uc3QgVXNlckdyb3VwID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VzZXJfZ3JvdXAnKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbmV4cG9ydCBjb25zdCBHcm91cFJlcXVlc3QgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBfcmVxdWVzdCcpOyAgICAgICAgICAgICAgICAgICAgICAgICAgXG5leHBvcnQgY29uc3QgQ2hhdHJvb20gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhdHJvb20nKTsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuXG5cbiIsImltcG9ydCB7IEZpbGVzQ29sbGVjdGlvbiB9IGZyb20gJ21ldGVvci9vc3RyaW86ZmlsZXMnO1xuXG5leHBvcnQgY29uc3QgSW1hZ2VzID0gbmV3IEZpbGVzQ29sbGVjdGlvbih7XG4gIGRlYnVnOiB0cnVlLFxuICBjb2xsZWN0aW9uTmFtZTogJ0ltYWdlcycsXG4gIGFsbG93Q2xpZW50Q29kZTogZmFsc2UsIC8vIERpc2FsbG93IHJlbW92ZSBmaWxlcyBmcm9tIENsaWVudFxuIFx0c3RvcmFnZVBhdGg6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGAke3Byb2Nlc3MuZW52LlBXRH0vdXBsb2Fkc2A7XG4gIH0sICAgb25CZWZvcmVVcGxvYWQ6IGZ1bmN0aW9uIChmaWxlKSB7XG4gICAgLy8gQWxsb3cgdXBsb2FkIGZpbGVzIHVuZGVyIDEwTUIsIGFuZCBvbmx5IGluIHBuZy9qcGcvanBlZyBmb3JtYXRzXG4gICAgaWYgKGZpbGUuc2l6ZSA8PSAxMDI0ICogMTAyNCAqIDEwICYmIC9wbmd8anBlP2cvaS50ZXN0KGZpbGUuZXh0ZW5zaW9uKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiAnUGxlYXNlIHVwbG9hZCBpbWFnZSwgd2l0aCBzaXplIGVxdWFsIG9yIGxlc3MgdGhhbiAxME1CJztcbiAgfVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IEltYWdlcztcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVXNlckluZm8gfSAgZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcbmltcG9ydCB7IFVzZXJTa2lsbCB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5cbmltcG9ydCB7IFVzZXJQcm9mSnIgfSBmcm9tICcuLy4uL2ltcG9ydC9jb2xsZWN0aW9ucy9pbnNlcnQuanMnO1xuaW1wb3J0IHsgVXNlckVkdSB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5cbmltcG9ydCB7IFVzZXJBd2FyZCB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5pbXBvcnQgeyBVc2VyTWVkaWNhbCB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5pbXBvcnQgeyBGcmllbmRSZXF1ZXN0IH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcblxuaW1wb3J0IHsgTWVzc2FnZSB9IGZyb20gJy4vLi4vaW1wb3J0L2NvbGxlY3Rpb25zL2luc2VydC5qcyc7XG5pbXBvcnQgeyBVc2VyR3JvdXAgfSBmcm9tICcuLy4uL2ltcG9ydC9jb2xsZWN0aW9ucy9pbnNlcnQuanMnO1xuaW1wb3J0IHsgRW1haWwgfSBmcm9tICdtZXRlb3IvZW1haWwnO1xuaW1wb3J0IHsgR3JvdXBSZXF1ZXN0IH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcbmltcG9ydCB7IENoYXRyb29tIH0gZnJvbSAnLi8uLi9pbXBvcnQvY29sbGVjdGlvbnMvaW5zZXJ0LmpzJztcblxuaW1wb3J0IHsgU2VydmljZUNvbmZpZ3VyYXRpb24gfSBmcm9tICdtZXRlb3Ivc2VydmljZS1jb25maWd1cmF0aW9uJztcblxuTWV0ZW9yLnN0YXJ0dXAoZnVuY3Rpb24gKCkge1xuICBVcGxvYWRTZXJ2ZXIuaW5pdCh7XG4gICAgdG1wRGlyOiBwcm9jZXNzLmVudi5QV0QgKyAnLy51cGxvYWRzL3RtcCcsXG4gICAgdXBsb2FkRGlyOiBwcm9jZXNzLmVudi5QV0QgKyAnL3VwbG9hZGVkLydcbiAgfSlcbn0pO1xuXG5cblxuXG4vLyAgICB2YXIgdDEgPSBQcmVzZW5jZS5jb25maWd1cmUoe1xuLy8gICBzdGF0ZTogZnVuY3Rpb24oKSB7XG4vLyAgICAgcmV0dXJuIHtcbi8vICAgICAgIG9ubGluZTogZmFsc2Vcbi8vICAgICB9XG4vLyAgICAgdXNlcklkOiBjb29sO1xuLy8gICB9XG4vLyB9KTtcblxuLy8gICAgIGlmKHQxID09IDApe1xuLy8gICAgIFx0YWxlcnQoJ2kgYW0gYWN0aXZlJyk7XG4vLyAgICAgXHRjb25zb2xlLmxvZygnYWN0aXZlJyk7XG4vLyAgICAgfVxuXG4vLyAgICAgZWxzZSBpZiggdDEgPT0gMSB8fCB0MSA9PSAyKXtcbi8vICAgICAgICBhbGVydCgnaSBhbSBpbmFjdGl2ZScpO1xuLy8gICAgICAgIGNvbnNvbGUubG9nKCdJbi1hY3RpdmUnKTtcbi8vICAgICAgICBTZXNzaW9uLnNldFBlcnNpc3RlbnQoXCJsb2dpbl9zdGF0dXNcIiwwKTsgICAgICAgICAgICAgIFxuLy8gICAgIH1cblxuLy8gICAgIGVsc2V7XG4vLyAgICAgXHRjb25zb2xlLmxvZygnSW4tYWN0aXZlJyk7XG4vLyAgICAgfVxuXG5cblNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLnJlbW92ZSh7XG4gIHNlcnZpY2U6IFwiZ29vZ2xlXCJcbn0pO1xuXG5TZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5pbnNlcnQoe1xuICBzZXJ2aWNlOiBcImdvb2dsZVwiLFxuICBjbGllbnRJZDogXCI0NDg5MzI2NDMwOTYtcXF0OXBxaTdjM2FnMHJjcTF2NmU5cTJhOHJmZTY1YXAuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb21cIixcbiAgc2VjcmV0OiBcIjBiVFppYnh3VWR1V19ORXFmNFcwTmdtYlwiLFxufSk7XG5cbi8vIGZpcnN0LCByZW1vdmUgY29uZmlndXJhdGlvbiBlbnRyeSBpbiBjYXNlIHNlcnZpY2UgaXMgYWxyZWFkeSBjb25maWd1cmVkXG5TZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5yZW1vdmUoe1xuICBzZXJ2aWNlOiBcImZhY2Vib29rXCJcbn0pO1xuXG5TZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5pbnNlcnQoe1xuICBzZXJ2aWNlOiBcImZhY2Vib29rXCIsXG4gIGFwcElkOiBcIjc4NDU2Njg0ODM5NzQ4N1wiLFxuICBzZWNyZXQ6IFwiNjc4NzEyNjk3ZWFlOGJkYzNjZmYyNTkzODEzNmUyYjlcIlxufSk7XG5cblNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLnJlbW92ZSh7XG4gIHNlcnZpY2U6IFwibGlua2VkaW5cIlxufSk7XG5cblNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLmluc2VydCh7XG4gIHNlcnZpY2U6IFwibGlua2VkaW5cIixcbiAgY2xpZW50SWQ6IFwiNzhlcWg0cWsweXg3eTdcIixcbiAgc2VjcmV0OiBcIml4UEFuU0JpQ3RCcTZXUEpcIlxufSk7XG4vLyAvLyBmaXJzdCwgcmVtb3ZlIGNvbmZpZ3VyYXRpb24gZW50cnkgaW4gY2FzZSBzZXJ2aWNlIGlzIGFscmVhZHkgY29uZmlndXJlZFxuLy8gQWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5yZW1vdmUoe1xuLy8gICBzZXJ2aWNlOiBcImZhY2Vib29rXCJcbi8vIH0pO1xuLy8gQWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5pbnNlcnQoe1xuLy8gICBzZXJ2aWNlOiBcImZhY2Vib29rXCIsXG4vLyAgIGFwcElkOiBcIjc4NDU2Njg0ODM5NzQ4N1wiLFxuLy8gICBzZWNyZXQ6IFwiNjc4NzEyNjk3ZWFlOGJkYzNjZmYyNTkzODEzNmUyYjlcIlxuLy8gfSk7XG5cbiBzbXRwID0ge1xuICAgIHVzZXJuYW1lOiAnYW5raXQudmF5dXpAZ21haWwuY29tJyxcbiAgICBwYXNzd29yZDogJ3Jza2x4anpoYnRoY293a28nLFxuICAgIHNlcnZlcjogJ3NtdHAuZ21haWwuY29tJyxcbiAgICBwb3J0OiA1ODdcbiAgfVxuICBwcm9jZXNzLmVudi5NQUlMX1VSTCA9ICdzbXRwOi8vJyArIGVuY29kZVVSSUNvbXBvbmVudChzbXRwLnVzZXJuYW1lKSArICc6JyArIGVuY29kZVVSSUNvbXBvbmVudChzbXRwLnBhc3N3b3JkKSArICdAJyArIGVuY29kZVVSSUNvbXBvbmVudChzbXRwLnNlcnZlcikgKyAnOicgKyBzbXRwLnBvcnQ7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgXG5sb2dvdXRfZ29vZ2xlOiBmdW5jdGlvbihuYW1lKXtcbnZhciByZXN1bHQgPSBNZXRlb3IudXNlcnMudXBkYXRlKHtcbiAgIF9pZDogbmFtZVxufSwge1xuICAgJHNldDoge1xuICAgICAgIFwic2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zXCI6IFtdXG4gICB9XG59LCB7XG4gICBtdWx0aTogdHJ1ZVxufSk7XG5yZXR1cm4gcmVzdWx0O1xufSxcblxuICBpbnNlcnRfYWRkcmVzczogZnVuY3Rpb24gKHVzZXJJZCxhZGRyZXNzKSB7XG4gIFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1wibG9jYXRpb25cIjogYWRkcmVzc31cblx0XHRcdH0pO1xuICBcdH1lbHNle1xuXHRcdFx0dmFyIHJlc3VsdCA9VXNlckluZm8uaW5zZXJ0KHtcblx0XHRcdFx0XHRsb2NhdGlvbjphZGRyZXNzLFxuXHRcdFx0ICAgICAgICB1c2VyX2lkOnVzZXJJZCxcblx0XHRcdCAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLy8gbm8gY29tbWEgbmVlZGVkIGhlcmVcblx0XHRcdCAgIH0pO1xuICBcdH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9LFxuXHQgIFx0XG4gIGluc2VydF9jb250YWN0X25vOiBmdW5jdGlvbiAodXNlcklkLGNvbnRhY3Rubykge1xuICBcdHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcbiAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHR2YXIgcmVzdWx0ID1cdFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcInBob25lXCI6IGNvbnRhY3Rub31cblx0XHRcdH0pO1xuICBcdH1lbHNle1xuXHRcdFx0dmFyIHJlc3VsdCA9VXNlckluZm8uaW5zZXJ0KHtcblx0XHRcdFx0XHRwaG9uZTpjb250YWN0bm8sXG5cdFx0XHQgICAgICAgIHVzZXJfaWQ6dXNlcklkLFxuXHRcdFx0ICAgICAgICBjcmVhdGVkQXQ6bmV3IERhdGUoKSAvLyBubyBjb21tYSBuZWVkZWQgaGVyZVxuXHRcdFx0ICAgfSk7XG4gIFx0fVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH0sXG4gICBpbnNlcnRfZGlzYWJpbGl0aWVzOiBmdW5jdGlvbiAodXNlcklkLGhlYXJpbmcsIHNwZWVjaCwgdmlzdWFsLCBwaHlzaWNhbCwgc3BlY2lhbF9ub3RlKSB7XG4gIFx0dmFyIG5ld1VzZXIgPSBVc2VyTWVkaWNhbC5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdHZhciByZXN1bHQgPVVzZXJNZWRpY2FsLnVwZGF0ZSh7XG5cdFx0XHQgIHVzZXJfaWQ6IHVzZXJJZCxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1xuXHRcdFx0ICBcdFwiaGVhcmluZ1wiOiBoZWFyaW5nLFxuXHRcdFx0ICBcdFwic3BlZWNoXCI6IHNwZWVjaCxcblx0XHRcdCAgXHRcInZpc3VhbFwiOiB2aXN1YWwsXG5cdFx0XHQgIFx0XCJwaHlzaWNhbFwiOiBwaHlzaWNhbCxcblx0XHRcdCAgXHRcInNwZWNpYWxfbm90ZVwiOiBzcGVjaWFsX25vdGUsXG5cdFx0XHQgIH1cblx0XHRcdH0pO1xuXG4gIFx0fWVsc2V7XG5cblx0XHR2YXIgcmVzdWx0ID1Vc2VyTWVkaWNhbC5pbnNlcnQoe1xuXHRcdFx0ICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG5cdFx0XHQgICAgICAgIGhlYXJpbmc6IGhlYXJpbmcsXG5cdFx0XHQgIFx0XHRzcGVlY2g6IHNwZWVjaCxcblx0XHRcdCAgXHRcdHZpc3VhbDogdmlzdWFsLFxuXHRcdFx0ICBcdFx0cGh5c2ljYWw6IHBoeXNpY2FsLFxuXHRcdFx0ICBcdFx0c3BlY2lhbF9ub3RlOiBzcGVjaWFsX25vdGUsXG5cdFx0XHQgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSAvLyBubyBjb21tYSBuZWVkZWQgaGVyZVxuXHRcdFx0ICAgfSk7XG5cblxuXHRcdHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcblx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdCAgJHNldDoge1wiZGlzYWJsaXRpZXNcIjogXCJ0cnVlXCJ9XG5cdFx0XHRcdFx0fSk7XG5cdFx0ICBcdH1cblxuXG5cbiAgXHR9XG5cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9LFxuICB1cGxvYWRfdXNlcl9pbWFnZTpmdW5jdGlvbih1c2VySWQscHJvZmlsZV9waWMpe1xuICB2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG4gIFx0aWYobmV3VXNlclswXSl7XG5cdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XCJwcm9maWxlX3BpY1wiOiBwcm9maWxlX3BpY31cblx0XHRcdH0pO1xuICBcdH1lbHNle1xuXG5cdFx0XHR2YXIgcmVzdWx0ID1Vc2VySW5mby5pbnNlcnQoe1xuXHRcdFx0XHRcdHByb2ZpbGVfcGljOnByb2ZpbGVfcGljLFxuXHRcdFx0ICAgICAgICB1c2VyX2lkOnVzZXJJZCxcblx0XHRcdCAgICAgICAgY3JlYXRlZEF0Om5ldyBEYXRlKCkgLy8gbm8gY29tbWEgbmVlZGVkIGhlcmVcblx0XHRcdCAgIH0pO1xuXG4gIFx0fVxuICBcdHJldHVybiByZXN1bHQ7XHRcbiAgfSwgXG5cbiAgdXBkYXRlX2hlYWRsaW5lOmZ1bmN0aW9uKHVzZXJJZCxoZWFkbGluZSl7XG4gIHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcbiAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHR2YXIgcmVzdWx0ID1cdFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHQgIF9pZDogbmV3VXNlclswXS5faWQsXG5cdFx0XHR9LCB7XG5cdFx0XHQgICRzZXQ6IHtcImhlYWRsaW5lXCI6IGhlYWRsaW5lfVxuXHRcdFx0fSk7XG4gIFx0fWVsc2V7XG5cdFx0XHR2YXIgcmVzdWx0ID1Vc2VySW5mby5pbnNlcnQoe1xuXHRcdFx0XHRcdGhlYWRsaW5lOmhlYWRsaW5lLFxuXHRcdFx0ICAgICAgICB1c2VyX2lkOnVzZXJJZCxcblx0XHRcdCAgICAgICAgbG9naW5fc3RhdHVzOiAxLFxuXHRcdFx0ICAgICAgICBjcmVhdGVkQXQ6bmV3IERhdGUoKSAvLyBubyBjb21tYSBuZWVkZWQgaGVyZVxuXHRcdFx0ICAgfSk7XG5cbiAgXHR9XG4gIFx0cmV0dXJuIHJlc3VsdDtcdFxuICB9LFxuXG4gIHVwZGF0ZV9zdW1tYXJ5OmZ1bmN0aW9uKHVzZXJJZCxzdW1tYXJ5KXtcbiAgdmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdHZhciByZXN1bHQgPSBVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XCJzdW1tYXJ5XCI6IHN1bW1hcnl9XG5cdFx0XHR9KTtcbiAgXHR9ZWxzZXtcblx0XHRcdHZhciByZXN1bHQgPVVzZXJJbmZvLmluc2VydCh7XG5cdFx0XHRcdFx0c3VtbWFyeTpzdW1tYXJ5LFxuXHRcdFx0ICAgICAgICB1c2VyX2lkOnVzZXJJZCxcblx0XHRcdCAgICAgICAgY3JlYXRlZEF0Om5ldyBEYXRlKCkgLy8gbm8gY29tbWEgbmVlZGVkIGhlcmVcblx0XHRcdCAgIH0pO1xuICBcdH1cbiAgXHRyZXR1cm4gcmVzdWx0O1x0XG4gIH0sXG5cbiAgY3JlYXRlX3VzZXI6ZnVuY3Rpb24odXNlcklELHNvdXJjZSxuYW1lLGVtYWlsKXtcblx0XHRcdHZhciByZXN1bHQgPVVzZXJJbmZvLmluc2VydCh7XG5cdFx0XHRcdFx0bmFtZTogbmFtZSxcblx0XHRcdCAgICAgICAgZW1haWw6IGVtYWlsLFxuXHRcdFx0ICAgICAgICB1c2VyX2lkOiB1c2VySUQsXG5cdFx0XHQgICAgICAgIHNvdXJjZTogc291cmNlLFxuXHRcdFx0ICAgICAgICBlbWFpbF9zdGF0dXM6IDAsXG5cdFx0XHQgICAgICAgIGNyZWF0ZWRBdDpuZXcgRGF0ZSgpIC8vIG5vIGNvbW1hIG5lZWRlZCBoZXJlXG5cdFx0XHQgICB9KTtcblxuICBcdHJldHVybiByZXN1bHQ7XHRcbiAgfSxcblxuICAgICAgICBjb25fcmVxX2luc2VydDogZnVuY3Rpb24oc2VudF90byxzZW50X2J5LHJlcUlEKXtcbiAgXHRcdHZhciByZXN1bHQgPSBGcmllbmRSZXF1ZXN0Lmluc2VydCh7XG4gIFx0XHRcdHJlcV9pZDogcmVxSUQsXG4gIFx0XHRcdHNlbnRfdG86IHNlbnRfdG8sXG4gIFx0XHRcdHNlbnRfYnk6IHNlbnRfYnksXG4gIFx0XHRcdHJlcV9zdGF0dXM6IDAsXG4gIFx0XHRcdHJlcXVlc3RlZEF0OiBuZXcgRGF0ZSgpLFxuICBcdFx0XHR1cGRhdGVkQXQ6IG5ldyBEYXRlKClcbiAgXHRcdCAgfSk7XG4gIFx0XHQgIHJldHVybiByZXN1bHQ7XG4gIFx0ICAgIH0sXG5cbiAgXHQgICAgY29uX3JlcV91cGRhdGU6IGZ1bmN0aW9uKHNlbnRfYnksc2VudF90byxyZXF1ZXN0X3R5cGUpe1xuICBcdFx0dmFyIHJlc3VsdCA9IEZyaWVuZFJlcXVlc3QudXBkYXRlKHtcblx0XHRcdCAgc2VudF9ieTogc2VudF9ieSxcblx0XHRcdCAgc2VudF90bzogc2VudF90byxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1wicmVxX3N0YXR1c1wiOiByZXF1ZXN0X3R5cGUsXCJ1cGRhdGVkQXRcIjogbmV3IERhdGUoKX1cblx0XHRcdH0pO1xuXHRcdCAgcmV0dXJuIHJlc3VsdDtcblx0XHRcdH0sXG4gICAgICAgIFxuXHQgICAgcGVyc19pbmZvX3VwZGF0ZTogZnVuY3Rpb24obmFtZSxnZW5kZXIsbWFyaXRhbF9zdGF0dXMscGhvbmUsZGF0ZXBpY2tlcixhdXRvY29tcGxldGUsdXNlcl9pZClcblx0ICAgIHtcbiAgXHRcdHZhciByZXN1bHQgPSBVc2VySW5mby51cGRhdGUoeyd1c2VyX2lkJzogdXNlcl9pZH0seyRzZXQ6IHsnbmFtZSc6IG5hbWUsJ2dlbmRlcic6IGdlbmRlcixcbiAgICAgICAgICAnbWFyaXRhbF9zdGF0dXMnOiBtYXJpdGFsX3N0YXR1cywncGhvbmUnOiBwaG9uZSwnZG9iJzogZGF0ZXBpY2tlcixcbiAgICAgICAgICAnbG9jYXRpb24nOiBhdXRvY29tcGxldGV9fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuICAgICAgXG5cdCAgICBpbnNlcnRfZWR1Y2F0aW9uOiBmdW5jdGlvbih1c2VyX2lkLGNvdXJzZSxib2FyZCxzY2hvb2wsc2NvcmUsZWR1X3N0YXJ0X21vbnRoLGVkdV9zdGFydF95ZWFyLGVkdV9lbmRfbW9udGgsZWR1X2VuZF95ZWFyLGVkdV9sb2NhdGlvbilcblx0ICAgIHtcbiAgXHRcdHZhciByZXN1bHQgPSBVc2VyRWR1Lmluc2VydCh7J3VzZXJfaWQnOiB1c2VyX2lkLCdjb3Vyc2UnOiBjb3Vyc2UsJ2JvYXJkJzogYm9hcmQsXG4gICAgICAgICAgJ3NjaG9vbCc6IHNjaG9vbCwnc2NvcmUnOiBzY29yZSwnZWR1X3N0YXJ0X21vbnRoJzogZWR1X3N0YXJ0X21vbnRoLFxuICAgICAgICAgICdlZHVfc3RhcnRfeWVhcic6IGVkdV9zdGFydF95ZWFyLCdlZHVfZW5kX21vbnRoJzogZWR1X2VuZF9tb250aCwnZWR1X2VuZF95ZWFyJzogZWR1X2VuZF95ZWFyLCdlZHVfbG9jYXRpb24nOiBlZHVfbG9jYXRpb24gfSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuICAgICAgXG5cdCAgICBpbnNlcnRfcHJvZmpyOiBmdW5jdGlvbihjb21wYW55X25hbWUsam9iX3RpdGxlLHN0YXJ0X21vbnRoLHN0YXJ0X3llYXIsZW5kX21vbnRoLGVuZF95ZWFyLEpvYl9sb2NhdGlvbixza2lsbF91c2VkLGtleV9yZXNwb25zaWJpbGl0aWVzLGpvYl90eXBlLHVzZXJfaWQpXG5cdCAgICB7XG4gIFx0XHR2YXIgcmVzdWx0ID0gVXNlclByb2ZKci5pbnNlcnQoe1xuICAgICAgICAgdXNlcl9pZDogdXNlcl9pZCxcbiAgICAgICAgIGNvbXBhbnk6IGNvbXBhbnlfbmFtZSxcbiAgICAgICAgIHRpdGxlOiBqb2JfdGl0bGUsXG4gICAgICAgICBzdGFydF9tb250aDogc3RhcnRfbW9udGgsICAgXG4gICAgICAgICBzdGFydF95ZWFyOiBzdGFydF95ZWFyLCAgIFxuICAgICAgICAgZW5kX21vbnRoOiBlbmRfbW9udGgsICAgXG4gICAgICAgICBlbmRfeWVhcjogZW5kX3llYXIsIFxuICAgICAgICAgbG9jYXRpb246IEpvYl9sb2NhdGlvbixcbiAgICAgICAgIHNraWxsOiBza2lsbF91c2VkLFxuICAgICAgICAga2V5X3Jlc3BvbnNpYmlsaXRpZXM6IGtleV9yZXNwb25zaWJpbGl0aWVzLFxuICAgICAgICAgam9iX3R5cGU6IGpvYl90eXBlLFxuICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLCAgXG4gICAgICAgIH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSxcbiAgICAgIFxuXHQgIGluc2VydF9hd2Q6IGZ1bmN0aW9uKHVzZXJJZCxhd2RfdHlwZSAsZGVzY3JpcHRpb24sYXdkX21vbnRoLGF3ZF95ZWFyLGF3ZF9sb2NhdGlvbilcblx0ICAgIHtcbiAgXHRcdHZhciByZXN1bHQgPSBVc2VyQXdhcmQuaW5zZXJ0KHtcbiAgICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcbiAgICAgICAgIHR5cGU6IGF3ZF90eXBlLFxuICAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLFxuICAgICAgICAgYXdkX21vbnRoOiBhd2RfbW9udGgsICAgXG4gICAgICAgICBhd2RfeWVhcjogYXdkX3llYXIsICAgXG4gICAgICAgICBsb2NhdGlvbjogYXdkX2xvY2F0aW9uLFxuICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLCAgXG4gICAgICAgIH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSxcbiAgICAgIFxuXHQgIHVwZGF0ZV9hd2Q6IGZ1bmN0aW9uKHVzZXJJZCxlZGl0X2lkLGF3ZF90eXBlICxkZXNjcmlwdGlvbixhd2RfbW9udGgsYXdkX3llYXIsYXdkX2xvY2F0aW9uKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyQXdhcmQudXBkYXRlKHtcblx0XHRcdCAgX2lkOiBlZGl0X2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdFx0XHQgIFx0ICAgICBcInR5cGVcIjogYXdkX3R5cGUsXG5cdFx0XHQgICAgICAgICBcImRlc2NyaXB0aW9uXCI6IGRlc2NyaXB0aW9uLFxuXHRcdFx0ICAgICAgICAgXCJhd2RfbW9udGhcIjogYXdkX21vbnRoLCAgIFxuXHRcdFx0ICAgICAgICAgXCJhd2RfeWVhclwiOiBhd2RfeWVhciwgICBcblx0XHRcdCAgICAgICAgIFwibG9jYXRpb25cIjogYXdkX2xvY2F0aW9uLFxuXHRcdFx0ICAgICAgICAgXCJjcmVhdGVkQXRcIjogbmV3IERhdGUoKSwgIFx0XG5cdFx0XHQgIH1cblx0XHRcdH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSxcbiAgICAgIFxuXHQgIFx0aW5zZXJ0X3NraWxsOiBmdW5jdGlvbih1c2VySWQsYXdkX2V4cGVydCxsYXN0X3VzZWQsc2tpbGxfbmFtZSlcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gVXNlclNraWxsLmluc2VydCh7XG4gICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgICBhd2RfZXhwZXJ0OiBhd2RfZXhwZXJ0LFxuICAgICAgICAgbGFzdF91c2VkOiBsYXN0X3VzZWQsXG4gICAgICAgICBza2lsbF9uYW1lOiBza2lsbF9uYW1lLCBcbiAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSwgIFxuICAgICAgICB9KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LFxuICAgICAgXG5cdCAgXHR1cGRhdGVfc2tpbGw6IGZ1bmN0aW9uKGVkaXRfaWQsYXdkX2V4cGVydCxsYXN0X3VzZWQsc2tpbGxfbmFtZSlcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gVXNlclNraWxsLnVwZGF0ZSh7XG5cdFx0XHQgIF9pZDogZWRpdF9pZCxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1xuXHQgICAgICAgICBhd2RfZXhwZXJ0OiBhd2RfZXhwZXJ0LFxuXHQgICAgICAgICBsYXN0X3VzZWQ6IGxhc3RfdXNlZCxcblx0ICAgICAgICAgc2tpbGxfbmFtZTogc2tpbGxfbmFtZSwgXG5cdCAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSwgICBcdFxuXHRcdFx0ICB9XG5cdFx0XHR9KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LFxuXHRcdHVwZGF0ZV9wcm9manI6IGZ1bmN0aW9uKGVkaXRfaWQsY29tcGFueV9uYW1lLGpvYl90aXRsZSxzdGFydF9tb250aCxzdGFydF95ZWFyLGVuZF9tb250aCxlbmRfeWVhcixKb2JfbG9jYXRpb24sXG4gICAgICAgICAgc2tpbGxfdXNlZCxrZXlfcmVzcG9uc2liaWxpdGllcyxqb2JfdHlwZSlcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gVXNlclByb2ZKci51cGRhdGUoe1xuICAgICAgICAgICAgX2lkOiBlZGl0X2lkXG4gICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgY29tcGFueTogY29tcGFueV9uYW1lLFxuICAgICAgICAgdGl0bGU6IGpvYl90aXRsZSxcbiAgICAgICAgIHN0YXJ0X21vbnRoOiBzdGFydF9tb250aCwgICBcbiAgICAgICAgIHN0YXJ0X3llYXI6IHN0YXJ0X3llYXIsICAgXG4gICAgICAgICAgIFxuICAgICAgICAgZW5kX21vbnRoOiBlbmRfbW9udGgsICAgXG4gICAgICAgICBlbmRfeWVhcjogZW5kX3llYXIsIFxuICAgICAgICAgbG9jYXRpb246IEpvYl9sb2NhdGlvbixcbiAgICAgICAgIHNraWxsOiBza2lsbF91c2VkLFxuICAgICAgICAgam9iX3R5cGU6IGpvYl90eXBlLFxuICAgICAgICAga2V5X3Jlc3BvbnNpYmlsaXRpZXM6IGtleV9yZXNwb25zaWJpbGl0aWVzLFxuICAgICAgICAgdXBkYXRlZEF0OiBuZXcgRGF0ZSgpICxcbiAgICAgICAgIH19KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LFxuXG5cdFx0dXBkYXRlX3Byb2Zqcl8yOiBmdW5jdGlvbihlZGl0X2lkLGNvbXBhbnlfbmFtZSxqb2JfdGl0bGUsc3RhcnRfbW9udGgsZW5kX21vbnRoLEpvYl9sb2NhdGlvbixcbiAgICAgICAgICBza2lsbF91c2VkLGtleV9yZXNwb25zaWJpbGl0aWVzLGpvYl90eXBlKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyUHJvZkpyLnVwZGF0ZSh7XG4gICAgICAgICAgICBfaWQ6IGVkaXRfaWRcbiAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICBjb21wYW55OiBjb21wYW55X25hbWUsXG4gICAgICAgICB0aXRsZTogam9iX3RpdGxlLFxuICAgICAgICAgc3RhcnRfbW9udGg6IHN0YXJ0X21vbnRoLCAgIFxuICAgICAgICAgc3RhcnRfeWVhcjogc3RhcnRfeWVhciwgICBcbiAgICAgICAgICAgXG4gICAgICAgICBsb2NhdGlvbjogSm9iX2xvY2F0aW9uLFxuICAgICAgICAgc2tpbGw6IHNraWxsX3VzZWQsXG4gICAgICAgICBqb2JfdHlwZTogam9iX3R5cGUsXG4gICAgICAgICBrZXlfcmVzcG9uc2liaWxpdGllczoga2V5X3Jlc3BvbnNpYmlsaXRpZXMsXG4gICAgICAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkgLFxuICAgICAgICAgfX0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG5cblxuXHRcdHVwZGF0ZV9lZHVjYXRpb246IGZ1bmN0aW9uKGVkaXRfaWQsY291cnNlLGJvYXJkLHNjaG9vbCxzY29yZSxlZHVfc3RhcnRfbW9udGgsZWR1X3N0YXJ0X3llYXIsZWR1X2VuZF9tb250aCxlZHVfZW5kX3llYXIsZWR1X2xvY2F0aW9uKVxuXHQgICAge1xuXHRcdFxuXHRcdHZhciByZXN1bHQgPSBVc2VyRWR1LnVwZGF0ZSh7XG4gICAgICAgICAgICBfaWQ6IGVkaXRfaWRcbiAgICAgICAgXG4gICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgJHNldDogeydjb3Vyc2UnOiBjb3Vyc2UsJ2JvYXJkJzogYm9hcmQsXG4gICAgICAgICAgJ3NjaG9vbCc6IHNjaG9vbCwnc2NvcmUnOiBzY29yZSwnZWR1X3N0YXJ0X21vbnRoJzogZWR1X3N0YXJ0X21vbnRoLFxuICAgICAgICAgICdlZHVfc3RhcnRfeWVhcic6IGVkdV9zdGFydF95ZWFyLCdlZHVfZW5kX21vbnRoJzogZWR1X2VuZF9tb250aCwnZWR1X2VuZF95ZWFyJzogZWR1X2VuZF95ZWFyLCdlZHVfbG9jYXRpb24nOiBlZHVfbG9jYXRpb24gfVxuICAgICB9KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LFxuICAgICAgICB1cGxvYWRfY292ZXJfaW1hZ2U6IGZ1bmN0aW9uKHVzZXJfaWQsaW1hZ2VQYXRoKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0ICB1c2VyX2lkOiB1c2VyX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdFx0XHQgIFx0ICAgICBcImNvdmVyX2ltYWdlXCI6IGltYWdlUGF0aCxcblx0XHRcdCAgICAgICAgIFwibGFzdFVwZGF0ZUF0XCI6IG5ldyBEYXRlKClcblx0XHRcdCAgfVxuXHRcdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuXG5cdFx0dXBsb2FkX3Byb2ZpbGVfaW1hZ2U6IGZ1bmN0aW9uKHVzZXJfaWQsaW1hZ2VQYXRoKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0ICB1c2VyX2lkOiB1c2VyX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdFx0XHQgIFx0ICAgICBcInByb2ZpbGVfcGljXCI6IGltYWdlUGF0aCxcblx0XHRcdCAgICAgICAgIFwibGFzdFVwZGF0ZUF0XCI6IG5ldyBEYXRlKClcblx0XHRcdCAgfVxuXHRcdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuXG4gICAgICAgIGluc2VydF9tZXNzYWdlOiBmdW5jdGlvbihzZW50X2J5LHNlbnRfdG8sbXNnX3RleHQsbXNnX2lkLGNoYXRyb29tX2lkLG1zZ19pbWdfaWQpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IE1lc3NhZ2UuaW5zZXJ0KHtcdFxuXHRcdCBtc2dfaWQ6IG1zZ19pZCxcbiAgICAgICAgIHNlbnRfYnk6IHNlbnRfYnksXG4gICAgICAgICBzZW50X3RvOiBzZW50X3RvLFxuICAgICAgICAgY2hhdHJvb21faWQ6Y2hhdHJvb21faWQsXG4gICAgICAgICBtc2dfdGV4dDogbXNnX3RleHQsXG4gICAgICAgICBpbWFnZV9hdHRhY2g6IG1zZ19pbWdfaWQsXG4gICAgICAgICBzZW50QXQ6IG5ldyBEYXRlKCksICBcbiAgICAgICAgfSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdFx0fSwgXG5cbiAgICAgICAgXG4gICAgICAgIGluc2VydF9tZXNzYWdlX1dpdGhfaW1nOiBmdW5jdGlvbihzZW50X2J5LHNlbnRfdG8sbXNnX2ltZ19pZCxtc2dfaWQpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IE1lc3NhZ2UuaW5zZXJ0KHtcblx0XHQgbXNnX2lkOiBtc2dfaWQsXG4gICAgICAgICBzZW50X2J5OiBzZW50X2J5LFxuICAgICAgICAgc2VudF90bzogc2VudF90byxcbiAgICAgICAgIG1zZ190ZXh0OiAwLFxuICAgICAgICAgaW1hZ2VfYXR0YWNoOiBtc2dfaW1nX2lkLFxuICAgICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLCAgXG4gICAgICAgIH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sIFxuXG5cdFx0aW5zZXJ0X21lc3NhZ2VfV2l0aF9hdHRhY2htZW50OiBmdW5jdGlvbihtc2dfaWQsc2VudF90byxzZW50X2J5LGF0dGFjaF9uYW1lLGF0dGFjaF9wYXRoLGZvcm1hdClcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gTWVzc2FnZS5pbnNlcnQoe1xuXHRcdCBtc2dfaWQ6IG1zZ19pZCxcbiAgICAgICAgIHNlbnRfYnk6IHNlbnRfYnksXG4gICAgICAgICBzZW50X3RvOiBzZW50X3RvLFxuICAgICAgICAgbXNnX3RleHQ6IDAsXG4gICAgICAgICBpbWFnZV9hdHRhY2g6IDAsXG4gICAgICAgICBhdHRhY2htZW50X25hbWU6IGF0dGFjaF9uYW1lLFxuICAgICAgICAgYXR0YWNobWVudF9wYXRoOiBhdHRhY2hfcGF0aCxcbiAgICAgICAgIGZvcm1hdDogZm9ybWF0LFxuICAgICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLCAgXG4gICAgICAgIH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sIFxuXG5cdFx0aW5zZXJ0X0dyb3VwX2RldGFpbHM6IGZ1bmN0aW9uKHVzZXJfaWQsZ3JwX2ltYWdlLGdycF90aXRsZSxncnBfdHlwZSxncnBfZGlzY3JpcHRpb24sZ3JwX3Zpc2liaWxpdHksZ3JwX2lkKVxuXHQgICAge1xuXHRcdHZhciByZXN1bHQgPSBVc2VyR3JvdXAuaW5zZXJ0KHtcblx0XHQgZ3JwX2lkOiBncnBfaWQsXG5cdFx0IGdycF90aXRsZTogZ3JwX3RpdGxlLFxuXHRcdCBhZG1pbjogdXNlcl9pZCxcbiAgICAgICAgIGdycF90eXBlOiBncnBfdHlwZSxcbiAgICAgICAgIGdycF9kaXNjcmlwdGlvbjogZ3JwX2Rpc2NyaXB0aW9uLFxuICAgICAgICAgZ3JwX3Zpc2liaWxpdHk6IGdycF92aXNpYmlsaXR5LFxuICAgICAgICAgZ3JwX2ltYWdlOiBncnBfaW1hZ2UsXG4gICAgICAgICBhY3Rpdml0eV9zdGF0dXM6IDEsXG4gICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkgXG4gICAgICAgIH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHRcdH0sXG5cblx0XHR1cGRhdGVfR3JvdXBfZGV0YWlsczogZnVuY3Rpb24odXNlcl9pZCxncnBfaW1hZ2UsZ3JwX3RpdGxlLGdycF90eXBlLGdycF9kaXNjcmlwdGlvbixcblx0XHRcdGdycF92aXNpYmlsaXR5LGdycF9pZCxhY3Rpdml0eV9zdGF0dXMpXG5cdCAgICB7XG5cdFx0dmFyIHJlc3VsdCA9IFVzZXJHcm91cC51cGRhdGUoe1xuXHRcdFx0ICBncnBfaWQ6IGdycF9pZCxcblx0XHRcdH0sIHtcblx0XHRcdCAgJHNldDoge1xuXHRcdCAgICAgICAgICAgICBncnBfdGl0bGU6IGdycF90aXRsZSxcblx0XHRcdFx0XHQgYWRtaW46IHVzZXJfaWQsXG5cdFx0XHQgICAgICAgICBncnBfdHlwZTogZ3JwX3R5cGUsXG5cdFx0XHQgICAgICAgICBncnBfZGlzY3JpcHRpb246IGdycF9kaXNjcmlwdGlvbixcblx0XHRcdCAgICAgICAgIGdycF92aXNpYmlsaXR5OiBncnBfdmlzaWJpbGl0eSxcblx0XHRcdCAgICAgICAgIGdycF9pbWFnZTogZ3JwX2ltYWdlLFxuXHRcdFx0ICAgICAgICAgYWN0aXZpdHlfc3RhdHVzOiBhY3Rpdml0eV9zdGF0dXMsXG5cdFx0XHQgICAgICAgICBVcGRhdGVkQXQ6IG5ldyBEYXRlKCksIFxuXHRcdFx0ICB9XG5cdFx0XHR9KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LFxuICAgXG4gICBcdCBcdHNlbmRFbWFpbDogZnVuY3Rpb24gKHVzZXJJZCwgZW1haWwpIHtcbiAgICAgICAgICAgIEVtYWlsLnNlbmQoZW1haWwpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHVwZGF0ZV9Hcm91cF9hY3Rpdml0eTogZnVuY3Rpb24oZ3JwX2lkLGFjdGl2aXR5X3N0YXR1cylcblx0ICAgIHtcblx0XHR2YXIgcmVzdWx0ID0gVXNlckdyb3VwLnVwZGF0ZSh7XG5cdFx0XHQgIGdycF9pZDogZ3JwX2lkLFxuXHRcdFx0fSwge1xuXHRcdFx0ICAkc2V0OiB7XG5cdFx0XHQgIFx0ICAgICBcImFjdGl2aXR5X3N0YXR1c1wiOiBhY3Rpdml0eV9zdGF0dXMsXG5cdFx0XHQgICAgICAgICBcImxhc3RVcGRhdGVBdFwiOiBuZXcgRGF0ZSgpXG5cdFx0XHQgIH1cblx0XHRcdH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSwgICAgICBcblx0XHR1cGRhdGVfZW1haWxfc3RhdHVzOmZ1bmN0aW9uKHVzZXJJZCxlbWFpbF9zdGF0dXMpe1xuICAgICAgICBcdFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuXHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdFx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0XHRcdH0sIHtcblx0XHRcdFx0XHRcdCAgJHNldDoge1wiZW1haWxfc3RhdHVzXCI6IDF9XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSwgICAgICBcblx0XHRzZXRfZGVmYXVsdF9jb3ZlcjpmdW5jdGlvbih1c2VySWQsc2V0X2RlZmF1bHQpe1xuICAgICAgICBcdFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuXHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdFx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0XHRcdH0sIHtcblx0XHRcdFx0XHRcdCAgJHNldDoge1wiY292ZXJfaW1hZ2VcIjogc2V0X2RlZmF1bHR9XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSwgICAgICBcblx0XHRzZXRfZGVmYXVsdF9wcm9maWxlX3BpYzpmdW5jdGlvbih1c2VySWQsc2V0X2RlZmF1bHQpe1xuICAgICAgICBcdFx0dmFyIG5ld1VzZXIgPSBVc2VySW5mby5maW5kKHtcInVzZXJfaWRcIjp1c2VySWR9KS5mZXRjaCgpO1xuXHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdHZhciByZXN1bHQgPVx0VXNlckluZm8udXBkYXRlKHtcblx0XHRcdFx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0XHRcdH0sIHtcblx0XHRcdFx0XHRcdCAgJHNldDoge1wicHJvZmlsZV9waWNcIjogc2V0X2RlZmF1bHR9XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcblxuXHRcdHVwZGF0ZV9sb2dpbl9zdGF0dXM6ZnVuY3Rpb24obG9naW5fc3RhdHVzLHVzZXJJZCl7XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XCJsb2dpbl9zdGF0dXNcIjogbG9naW5fc3RhdHVzfVxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHQgIFx0fVxuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG5cblx0XHR1cGRhdGVfcGFzc2lvbjpmdW5jdGlvbih1c2VySWQscGFzc2lvbil7XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IFVzZXJJbmZvLmZpbmQoe1widXNlcl9pZFwiOnVzZXJJZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0aWYobmV3VXNlclswXSl7XG5cdFx0XHRcdFx0dmFyIHJlc3VsdCA9XHRVc2VySW5mby51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XCJwYXNzaW9uXCI6IHBhc3Npb259XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcbiAgICAgICAgXG4gICAgICAgIHJlbW92ZV9za2lsbDpmdW5jdGlvbihza2lsbF9pZCl7XG4gICAgICAgIFx0ICAgIHZhciByZXN1bHQgPVx0VXNlclNraWxsLnJlbW92ZSh7X2lkOiBza2lsbF9pZCB9KTtcblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuICAgICAgICByZW1vdmVfYXdhcmQ6ZnVuY3Rpb24oYXdkX2lkKXtcbiAgICAgICAgXHQgICAgdmFyIHJlc3VsdCA9XHRVc2VyQXdhcmQucmVtb3ZlKHtfaWQ6IGF3ZF9pZCB9KTtcblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuICAgICAgICByZW1vdmVfcHJvZmpyOmZ1bmN0aW9uKHByb2Zqcl9pZCl7XG4gICAgICAgIFx0ICAgIHZhciByZXN1bHQgPVx0VXNlclByb2ZKci5yZW1vdmUoe19pZDogcHJvZmpyX2lkIH0pO1xuXHRcdFx0ICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZV9lZHVjYXRpb246ZnVuY3Rpb24oZWR1X2lkKXtcbiAgICAgICAgXHQgICAgdmFyIHJlc3VsdCA9XHRVc2VyRWR1LnJlbW92ZSh7X2lkOiBlZHVfaWQgfSk7XG5cdFx0XHQgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcblxuICAgICAgICByZW1vdmVfZ3JvdXBfcmVxdWVzdDpmdW5jdGlvbihzZW50X2J5LGdycF9pZCl7XG4gICAgICAgIFx0ICAgIHZhciByZXN1bHQgPVx0R3JvdXBSZXF1ZXN0LnJlbW92ZSh7c2VudF9ieTogc2VudF9ieSwgZ3JwX2lkOiBncnBfaWR9KTtcblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuXG4gICAgICAgIGluc2VydF9ncm91cF9yZXF1ZXN0OmZ1bmN0aW9uKHJlcV9pZCxzZW50X2J5LGdycF9pZCxzdGF0dXMpe1xuICAgICAgICBcdFx0dmFyIHJlc3VsdCA9IEdyb3VwUmVxdWVzdC5pbnNlcnQoe1xuXHRcdFx0ICAgICAgICAgcmVxX2lkOiByZXFfaWQsXG5cdFx0XHQgICAgICAgICBzZW50X2J5OiBzZW50X2J5LFxuXHRcdFx0ICAgICAgICAgZ3JwX2lkOiBncnBfaWQsXG5cdFx0XHQgICAgICAgICBzdGF0dXM6IHN0YXR1cyxcblx0XHRcdCAgICAgICAgIHNlbnRBdDogbmV3IERhdGUoKSwgIFxuXHRcdFx0ICAgICAgICB9KTtcblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuXG4gICAgICAgIFVwZGF0ZV9DaGF0cm9vbTpmdW5jdGlvbihjaGF0cm9vbV9pZCx1c2VyMSx1c2VyMixsYXN0X21zZyxsYXN0X21zZ19pZCxsYXN0X21zZ19zZW50X2J5LGNvbm5lY3Rfc3RhdHVzLFxuY3VycmVudGx5X3R5cGluZyl7XG4gICAgICAgIFx0XHR2YXIgbmV3VXNlciA9IENoYXRyb29tLmZpbmQoe2NoYXRyb29tX2lkOiBjaGF0cm9vbV9pZH0pLmZldGNoKCk7XG5cdFx0XHQgIFx0dmFyIHRvdGFsX21lc3NhZ2VzID0gTWVzc2FnZS5maW5kKHtcImNoYXRyb29tX2lkXCI6Y2hhdHJvb21faWR9KS5jb3VudCgpO1xuXHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdHZhciByZXN1bHQgPSBDaGF0cm9vbS51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XG5cdFx0XHRcdFx0XHQgIFx0XHRcdFx0dG90YWxfbWVzc2FnZXM6dG90YWxfbWVzc2FnZXMrMSxcblx0XHRcdFx0XHRcdCAgICAgICAgICAgICAgICBsYXN0X21zZzogbGFzdF9tc2csXG5cdFx0XHRcdFx0XHQgICAgICAgICAgICAgICAgbGFzdF9tc2dfaWQ6bGFzdF9tc2dfaWQsXG5cdFx0XHRcdFx0XHQgICAgICAgICAgICAgICAgbGFzdF9tc2dfdGltZTogRGF0ZS5ub3coKSxcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGxhc3RfbXNnX3NlbnRfYnk6IGxhc3RfbXNnX3NlbnRfYnksIFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0Y29ubmVjdF9zdGF0dXM6IGNvbm5lY3Rfc3RhdHVzLCBcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGN1cnJlbnRseV90eXBpbmc6IGN1cnJlbnRseV90eXBpbmdcblxuXHRcdFx0XHRcdFx0ICB9XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgIFx0ZWxzZXtcblx0XHRcdCAgXHRcdHZhciByZXN1bHQgPVx0Q2hhdHJvb20uaW5zZXJ0KHtcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGNoYXRyb29tX2lkOiBjaGF0cm9vbV9pZCwgXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHR1c2VyMTogICAgICAgIHVzZXIxICwgXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHR1c2VyMjogICAgICAgIHVzZXIyICwgXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHRsYXN0X21zZ19pZDogbGFzdF9tc2dfaWQsXG5cdFx0XHRcdCAgICAgICAgXHRcdFx0XHRsYXN0X21zZzogbGFzdF9tc2csIFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0bGFzdF9tc2dfdGltZTogRGF0ZS5ub3coKSxcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGxhc3RfbXNnX3NlbnRfYnk6IGxhc3RfbXNnX3NlbnRfYnksIFxuXHRcdFx0XHQgICAgICAgIFx0XHRcdFx0Y29ubmVjdF9zdGF0dXM6IGNvbm5lY3Rfc3RhdHVzLCBcblx0XHRcdFx0ICAgICAgICBcdFx0XHRcdGN1cnJlbnRseV90eXBpbmc6IGN1cnJlbnRseV90eXBpbmcgXG5cdFx0XHRcdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuXG5cbiAgICAgICAgVXBkYXRlX2N1cnJlbnRseV90eXBpbmc6ZnVuY3Rpb24oY2hhdHJvb21faWQsY3VycmVudGx5X3R5cGluZyl7ICAgICAgICBcdFxuICAgICAgICBcdFx0dmFyIG5ld1VzZXIgPSBDaGF0cm9vbS5maW5kKHtjaGF0cm9vbV9pZDogY2hhdHJvb21faWR9KS5mZXRjaCgpO1xuXHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdHZhciByZXN1bHQgPSBDaGF0cm9vbS51cGRhdGUoe1xuXHRcdFx0XHRcdFx0ICBfaWQ6IG5ld1VzZXJbMF0uX2lkLFxuXHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0ICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgXHRcdFx0XHRjdXJyZW50bHlfdHlwaW5nOiBjdXJyZW50bHlfdHlwaW5nXG4gICAgICAgICAgICAgICAgICAgICAgIFx0XHQgIH1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0ICBcdH1cblx0XHRcdCAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LFxuICAgICAgICBjaGFuZ2VfdXNlcl9vbmxpbmVfc3RhdHVzOmZ1bmN0aW9uKHVzZXJJZCxzdGF0dXMpe1xuICAgICAgICBcdHZhciBuZXdVc2VyID0gVXNlckluZm8uZmluZCh7XCJ1c2VyX2lkXCI6dXNlcklkfSkuZmV0Y2goKTtcblx0XHRcdFx0ICBcdGlmKG5ld1VzZXJbMF0pe1xuXHRcdFx0XHRcdFx0dmFyIHJlc3VsdCA9IFVzZXJJbmZvLnVwZGF0ZSh7XG5cdFx0XHRcdFx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdFx0XHQgICRzZXQ6IHtcIm9ubGluZV9zdGF0dXNcIjogc3RhdHVzfVxuXHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0ICBcdH1cblx0XHRcdFx0ICBcdHJldHVybiByZXN1bHQ7XHRcbiAgICAgICAgfSxcbiAgICAgICAgdXBkYXRlX2NoYXRyb29tX2NvdW50OmZ1bmN0aW9uKGNoYXRyb29tX2lkLGNvdW50KXtcbiAgICAgICAgXHR2YXIgbmV3VXNlciA9IENoYXRyb29tLmZpbmQoe2NoYXRyb29tX2lkOiBjaGF0cm9vbV9pZH0pLmZldGNoKCk7XG4gICAgICAgIFx0XHR2YXIgdXBkYXRlZENvdW50PTA7XG4gICAgICAgIFx0aWYobmV3VXNlclswXS51bnJlYWRfbXNnX2NvdW50KXtcblx0XHRcdFx0dXBkYXRlZENvdW50ICA9IG5ld1VzZXJbMF0udW5yZWFkX21zZ19jb3VudCsxO1xuICAgICAgICBcdH1lbHNle1xuXHRcdFx0XHR1cGRhdGVkQ291bnQgID0xOyBcbiAgICAgICAgXHR9XG4gICAgICAgIFx0aWYoY291bnQgPT0gMCl7XG5cdFx0XHR1cGRhdGVkQ291bnQgPSAwO1xuICAgICAgICBcdH1cblx0XHRcdCAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHRcdFx0XHR2YXIgcmVzdWx0ID0gQ2hhdHJvb20udXBkYXRlKHtcblx0XHRcdFx0XHRcdCAgX2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0XHRcdH0sIHtcblx0XHRcdFx0XHRcdCAgJHNldDoge1xuXHRcdFx0XHRcdFx0ICBcdFx0XHQgbGFzdF9tc2dfdGltZTogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgICAgICAgICAgICBcdFx0XHRcdHVucmVhZF9tc2dfY291bnQ6IHVwZGF0ZWRDb3VudFxuICAgICAgICAgICAgICAgICAgICAgICBcdFx0ICB9XG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdCAgXHR9XG5cdFx0XHQgIFx0cmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcbiAgICAgICAgdXBkYXRlX2xhc3RfbXNnX3N0YXR1czpmdW5jdGlvbihtZXNzYWdlX2lkLHN0YXR1cyl7XG5cbiAgICAgICAgXHR2YXIgbmV3VXNlciA9IE1lc3NhZ2UuZmluZCh7XCJtc2dfaWRcIjptZXNzYWdlX2lkfSkuZmV0Y2goKTtcbiAgICAgICAgXHRpZihzdGF0dXMgPT0gXCJyZWFkXCIpe1xuXHRcdFx0XHR2YXIgbmV3VXNlciA9IE1lc3NhZ2UuZmluZCh7XCJjaGF0cm9vbV9pZFwiOm5ld1VzZXJbMF0uY2hhdHJvb21faWR9KS5mZXRjaCgpO1xuXHRcdFx0XHRmb3IodmFyIGk9MDtpPG5ld1VzZXIubGVuZ3RoO2krKyl7XG5cdFx0XHRcdHZhciByZXN1bHQgPSBNZXNzYWdlLnVwZGF0ZSh7XG5cdFx0XHRcdFx0X2lkOiBuZXdVc2VyW2ldLl9pZCxcblx0XHRcdFx0IFx0fSwge1xuXHRcdFx0XHRcdCRzZXQ6IHtcImRlbGl2ZXJ5X3N0YXR1c1wiOiBcInJlYWRcIn1cblx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcbiAgICAgICAgXHR9ZWxzZXtcbiAgICAgICAgXHRpZihuZXdVc2VyWzBdKXtcblx0XHRcdHZhciByZXN1bHQgPSBNZXNzYWdlLnVwZGF0ZSh7XG5cdFx0XHRcdFx0X2lkOiBuZXdVc2VyWzBdLl9pZCxcblx0XHRcdFx0fSwge1xuXHRcdFx0XHRcdCRzZXQ6IHtcImRlbGl2ZXJ5X3N0YXR1c1wiOiBzdGF0dXN9XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVx0XG4gICAgICAgIFx0fVxuXHRcdFx0XG5cdFx0XHRcdCAgXHRyZXR1cm4gcmVzdWx0O1x0XG4gICAgICAgIH0sXG5cblxuXG59KTtcblxuXG5cblxuXG4iXX0=
